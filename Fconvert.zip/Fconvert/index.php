<?php
require_once __DIR__ . '/includes/bootstrap.php';
$page_title = 'Fconvert | Modern File Conversion Platform';
$page_description = 'Fconvert helps users convert documents, images, and videos with a professional, mobile-first experience.';
$active_page = 'home';
$hero_badge = '76k+ users trust Fconvert';
$hero_title = 'Convert files with confidence.';
$hero_subtitle = 'Professional file conversion pages for documents, images, and video formats.';
include __DIR__ . '/includes/header.php';
?>
<section class="hero">
  <div class="container hero-grid">
    <div class="hero-card">
      <div class="pill-row">
        <span class="pill">Secure and clean design</span>
        <span class="pill">Mobile-first layout</span>
        <span class="pill">Easy-to-expand structure</span>
      </div>
      <div class="badge-users">★ 76k+ users trust Fconvert</div>
      <h1>Convert files without stress, with a polished experience that feels premium.</h1>
      <p>Fconvert is built for users who need quick format changes across documents, pictures, and videos. It explains why each converter matters, helps visitors move from one tool to another, and keeps the whole experience welcoming and organized. On phones, the layout stays clear and easy to use. On larger screens, it feels like a modern product site.</p>
      <div class="hero-actions">
        <a class="cta-btn" href="#tools">Explore converters</a>
        <a class="secondary-btn" href="https://wa.me/2347012265612" target="_blank" rel="noopener">WhatsApp contact</a>
      </div>
    </div>
    <aside class="glass-card stats-card">
      <div class="stat-grid">
        <div class="stat">
          <strong>8+</strong>
          <span>ready-made converter pages included in this build</span>
        </div>
        <div class="stat">
          <strong>100%</strong>
          <span>responsive layout designed for mobile screens</span>
        </div>
        <div class="stat">
          <strong>24/7</strong>
          <span>clear access to useful file-format workflows</span>
        </div>
        <div class="stat">
          <strong>1 tap</strong>
          <span>easy navigation to each converter page</span>
        </div>
      </div>
      <div class="note-box">
        People need different formats for editing, sharing, printing, publishing, and compatibility. That is why the homepage explains the purpose of every major converter category in a friendly, professional way.
      </div>
    </aside>
  </div>
</section>

<section class="section" id="tools">
  <div class="container">
    <div class="section-title">
      <div>
        <h2>Popular converters</h2>
        <p>Each page below is built to feel like a complete product landing page, not a rushed utility screen. You can extend this list with more format pairs later.</p>
      </div>
    </div>
    <div class="tool-grid">
      
    <a class="tool-card" href="pdf-to-docx.php">
      <div class="tool-icon">⇄</div>
      <h3>PDF to DOCX</h3>
      <p>Turn locked-in PDF pages into a clean Word file you can edit, reformat, and reuse.</p>
      <span class="mini-link">Open converter →</span>
    </a>
    

    <a class="tool-card" href="docx-to-pdf.php">
      <div class="tool-icon">⇄</div>
      <h3>DOCX to PDF</h3>
      <p>Create polished PDFs from your Word documents for sharing, printing, and archiving.</p>
      <span class="mini-link">Open converter →</span>
    </a>
    

    <a class="tool-card" href="/jpeg-to-jpg.php">
      <div class="tool-icon">⇄</div>
      <h3>JPEG to JPG</h3>
      <p>Convert image files between the commonly used JPEG and JPG extensions without stress.</p>
      <span class="mini-link">Open converter →</span>
    </a>
    

    <a class="tool-card" href="/jpg-to-jpeg.php">
      <div class="tool-icon">⇄</div>
      <h3>JPG to JPEG</h3>
      <p>Change JPG file naming to JPEG when a system, editor, or workflow prefers the longer extension.</p>
      <span class="mini-link">Open converter →</span>
    </a>
    

    <a class="tool-card" href="/doc-to-pdf.php">
      <div class="tool-icon">⇄</div>
      <h3>DOC to PDF</h3>
      <p>Move older DOC files into PDF format to make sharing simpler and more reliable.</p>
      <span class="mini-link">Open converter →</span>
    </a>
    

    <a class="tool-card" href="mp4-to-avi.php">
      <div class="tool-icon">⇄</div>
      <h3>MP4 to AVI</h3>
      <p>Switch MP4 videos to AVI when your device, player, or workflow needs the older video container.</p>
      <span class="mini-link">Open converter →</span>
    </a>
    

    <a class="tool-card" href="/png-to-webp.php">
      <div class="tool-icon">⇄</div>
      <h3>PNG to WebP</h3>
      <p>Convert PNG graphics into WebP to help websites load faster and feel smoother.</p>
      <span class="mini-link">Open converter →</span>
    </a>
    

    <a class="tool-card" href="/webp-to-png.php">
      <div class="tool-icon">⇄</div>
      <h3>WebP to PNG</h3>
      <p>Restore WebP images to PNG format for editing, design handoff, or broader compatibility.</p>
      <span class="mini-link">Open converter →</span>
    </a>
    
    </div>
  </div>
</section>

<section class="section">
  <div class="container content-grid">
    <article class="panel">
      <h2>Why these converters are needed</h2>
      <p>File formats exist for different purposes. A PDF is great for sharing and printing, while a DOCX is easier to edit. JPEG and JPG are often used interchangeably for photos. Video formats also matter because some players, editors, or platforms prefer one container over another.</p>
      <p>When users can move between formats easily, they save time, reduce frustration, and keep their work moving. That is the experience Fconvert is meant to present: simple tools, clear explanations, and a professional interface that looks trustworthy from the first visit.</p>
    </article>
    <aside class="panel">
      <h3>Platform highlights</h3>
      <ul class="list">
        <li>Modern dark-themed UI with soft gradients and strong spacing.</li>
        <li>Modal signup popup for first-time visitors.</li>
        <li>Email saves to a server-side text file.</li>
        <li>Links to all converter pages from the homepage.</li>
        <li>Footer contact with WhatsApp support number.</li>
      </ul>
    </aside>
  </div>
</section>

<section class="section">
  <div class="container panel">
    <h2>More than a converter list</h2>
    <p>Many users only need a fast tool, but a good conversion website should also feel reassuring. Fconvert uses organized sections, helpful copy, and clear actions so the experience feels complete. It is suitable for a home page, converter pages, and future expansion into more file tools.</p>
  </div>
</section>

<?php include __DIR__ . '/includes/popup.php'; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
