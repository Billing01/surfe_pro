  </main>

  <div class="container" style="margin-bottom:18px;">
    <div class="panel" style="padding:18px;text-align:center;">
      <ins class="surfe-be" data-sid="421283"></ins>
      <ins class="surfe-be" data-sid="421284"></ins>
    </div>
  </div>
  <footer class="footer">
    <div class="container footer-grid">
      <div>
        <strong style="color:var(--text);font-size:18px;">Fconvert</strong>
        <div style="margin-top:8px;max-width:600px;line-height:1.7;">
          Modern converters for documents, images, and video files, designed to feel professional on every screen.
        </div>
      </div>
      <div>
        <div>Need support or partnership inquiries?</div>
        <div style="margin-top:8px;"><a href="https://wa.me/2347012265612" target="_blank" rel="noopener">+2347012265612 (WhatsApp)</a></div>
      </div>
    </div>
  </footer>

  <script src="/assets/js/main.js" defer></script>
  <script>
    (adsurfebe = window.adsurfebe || []).push({});
    (adsurfebe = window.adsurfebe || []).push({});
  </script>
</body>
</html>
