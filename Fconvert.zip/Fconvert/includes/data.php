<?php
return [
  {
    "slug": "pdf-to-docx",
    "title": "PDF to DOCX",
    "headline": "Convert PDF files into editable Word documents",
    "subtitle": "Perfect for reports, invoices, research papers, and scanned documents that need editing.",
    "from": "PDF",
    "to": "DOCX",
    "description": "Turn locked-in PDF pages into a clean Word file you can edit, reformat, and reuse.",
    "benefits": [
      "Edit text instead of copying and pasting from a PDF.",
      "Reuse tables, paragraphs, and layouts in Microsoft Word.",
      "Ideal for office work, school documents, and content updates."
    ]
  },
  {
    "slug": "docx-to-pdf",
    "title": "DOCX to PDF",
    "headline": "Lock Word documents into portable PDFs",
    "subtitle": "Keep your formatting intact when sharing resumes, proposals, and official files.",
    "from": "DOCX",
    "to": "PDF",
    "description": "Create polished PDFs from your Word documents for sharing, printing, and archiving.",
    "benefits": [
      "Preserve layout across devices and operating systems.",
      "Share files that are easy to open anywhere.",
      "Great for assignments, business proposals, and contracts."
    ]
  },
  {
    "slug": "jpeg-to-jpg",
    "title": "JPEG to JPG",
    "headline": "Rename and optimize image extensions the clean way",
    "subtitle": "Useful when you need the standard JPG extension for websites, apps, or uploads.",
    "from": "JPEG",
    "to": "JPG",
    "description": "Convert image files between the commonly used JPEG and JPG extensions without stress.",
    "benefits": [
      "Standardize file names for easier management.",
      "Use the extension your platform expects.",
      "Helpful for uploads, galleries, and media workflows."
    ]
  },
  {
    "slug": "jpg-to-jpeg",
    "title": "JPG to JPEG",
    "headline": "Switch JPG files to JPEG format naming",
    "subtitle": "A simple way to keep your image library consistent across tools and teams.",
    "from": "JPG",
    "to": "JPEG",
    "description": "Change JPG file naming to JPEG when a system, editor, or workflow prefers the longer extension.",
    "benefits": [
      "Keep naming consistent across different tools.",
      "Avoid confusion in bulk image folders.",
      "Works well for photo libraries and design teams."
    ]
  },
  {
    "slug": "doc-to-pdf",
    "title": "DOC to PDF",
    "headline": "Convert older Word DOC files into safe PDFs",
    "subtitle": "A practical tool for legacy Office files, coursework, and business documents.",
    "from": "DOC",
    "to": "PDF",
    "description": "Move older DOC files into PDF format to make sharing simpler and more reliable.",
    "benefits": [
      "Great for older Word documents from classic versions.",
      "Protect the layout when sending files to clients.",
      "Useful before printing or uploading to portals."
    ]
  },
  {
    "slug": "mp4-to-avi",
    "title": "MP4 to AVI",
    "headline": "Convert popular video files into AVI format",
    "subtitle": "Useful for compatibility with certain editors, players, and legacy devices.",
    "from": "MP4",
    "to": "AVI",
    "description": "Switch MP4 videos to AVI when your device, player, or workflow needs the older video container.",
    "benefits": [
      "Better compatibility with some older players and editors.",
      "Handy for video libraries with mixed requirements.",
      "Simple format switching for media workflows."
    ]
  },
  {
    "slug": "png-to-webp",
    "title": "PNG to WebP",
    "headline": "Modernize your images for faster web delivery",
    "subtitle": "A smart option for websites that need lighter files and strong image quality.",
    "from": "PNG",
    "to": "WEBP",
    "description": "Convert PNG graphics into WebP to help websites load faster and feel smoother.",
    "benefits": [
      "Reduce file size for quicker page loads.",
      "Excellent for websites and online stores.",
      "Keep visual quality while improving performance."
    ]
  },
  {
    "slug": "webp-to-png",
    "title": "WebP to PNG",
    "headline": "Turn WebP images back into PNG files",
    "subtitle": "Handy when you need transparent, editor-friendly image files.",
    "from": "WEBP",
    "to": "PNG",
    "description": "Restore WebP images to PNG format for editing, design handoff, or broader compatibility.",
    "benefits": [
      "Useful for design workflows and transparency support.",
      "Compatible with most graphics tools.",
      "Great for logos, UI assets, and screenshots."
    ]
  }
];
