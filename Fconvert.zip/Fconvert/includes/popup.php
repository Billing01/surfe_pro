<?php if (!empty($show_popup)): ?>
<div class="modal show" data-popup-modal>
  <div class="modal-card">
    <form method="post" action="">
      <button class="modal-close" type="submit" name="popup_action" value="cancel" aria-label="Close popup" data-close-popup>×</button>
      <h3>Welcome to Fconvert</h3>
      <p>Please enter your email to receive updates when we add new tools and new converter pages.</p>
      <div class="field">
        <label for="email">Email address</label>
        <input type="email" id="email" name="email" placeholder="you@example.com" required>
      </div>
      <input type="hidden" name="redirect_to" value="<?= htmlspecialchars($_SERVER['REQUEST_URI'] ?? '/index.php') ?>">
      <div class="form-actions">
        <button class="cta-btn" type="submit" name="popup_action" value="subscribe">Notify me</button>
        <button class="secondary-btn" type="submit" name="popup_action" value="cancel">Not now</button>
      </div>
      <div class="small-text" style="margin-top:12px;">No spam. Just product updates, new tools, and important platform news.</div>
    </form>
  </div>
</div>
<?php endif; ?>
