Fconvert

Included pages:
- index.php
- pdf-to-docx.php
- docx-to-pdf.php
- jpeg-to-jpg.php
- jpg-to-jpeg.php
- doc-to-pdf.php
- mp4-to-avi.php
- png-to-webp.php
- webp-to-png.php

Notes:
- The site includes a first-visit popup that saves email leads to storage/emails.txt.
- The conversion pages are polished front-end templates ready to connect to a real backend conversion engine.
- Asset paths are written as root-relative URLs for deployment at site root.
