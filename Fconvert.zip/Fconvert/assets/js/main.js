(function () {
  const modal = document.querySelector('[data-popup-modal]');
  if (!modal) return;

  const closeButtons = modal.querySelectorAll('[data-close-popup]');
  closeButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      modal.classList.remove('show');
      document.body.style.overflow = '';
    });
  });

  if (modal.classList.contains('show')) {
    document.body.style.overflow = 'hidden';
  }

  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.classList.contains('show')) {
      modal.classList.remove('show');
      document.body.style.overflow = '';
    }
  });
})();
