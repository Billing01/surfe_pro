<?php
$slug = 'pdf-to-txt';
require __DIR__ . '/includes/converter-template.php';
