<?php
$slug = 'mp3-to-wav';
require __DIR__ . '/includes/converter-template.php';
