<?php
$pages = fconvert_nav_pages();
?>
<main class="main-content">
    <section class="hero home-hero">
        <div class="hero-copy">
            <span class="badge">
                <span class="dot"></span>
                Smart file conversion, made beautiful
            </span>
            <h1>Convert your files with a platform that feels premium on every screen.</h1>
            <p>FConvert brings together the most common format changes people need every day: documents to PDFs, PDFs back to editable Word files, image extension changes, and video or audio conversions that keep work moving. The goal is simple: make file conversion feel quick, welcoming, and clear enough that users know exactly why the tool exists.</p>
            <p>In real life, file formats matter because apps do not always speak the same language. A report might need to become a PDF before delivery. A PDF might need to become DOCX before editing. A PNG might need to become JPG to reduce size. A video might need to be turned into AVI for a specific editor. FConvert gives those situations a polished home, with a layout that is clean on mobile and easy to trust at a glance.</p>
            <div class="hero-actions">
                <a class="btn btn-primary" href="#tools">Explore tools</a>
                <a class="btn btn-ghost" href="#why-converters">Why converters matter</a>
            </div>
            <div class="tag-row">
                <span>Mobile-first</span>
                <span>Fast loading</span>
                <span>Document, image, audio &amp; video tools</span>
            </div>
        </div>
        <div class="hero-panel">
            <div class="hero-visual">
                <div class="floating-card">
                    <span>76k+ users</span>
                    <strong>Trusted conversion flow</strong>
                </div>
                <div class="floating-card alt">
                    <span>Modern UX</span>
                    <strong>Designed for phones first</strong>
                </div>
                <div class="floating-card small">
                    <span>Safe, tidy, practical</span>
                </div>
            </div>
            <div class="stats-grid">
                <div class="stat-card">
                    <strong>12+</strong>
                    <span>converter pages</span>
                </div>
                <div class="stat-card">
                    <strong>24/7</strong>
                    <span>browser access</span>
                </div>
                <div class="stat-card">
                    <strong>3</strong>
                    <span>core categories</span>
                </div>
                <div class="stat-card">
                    <strong>One tap</strong>
                    <span>friendly workflow</span>
                </div>
            </div>
        </div>
    </section>

    <section class="card section" id="why-converters">
        <span class="eyebrow">Why format tools matter</span>
        <h2>People need converters for a lot of practical reasons</h2>
        <div class="grid three-up">
            <article class="mini-card">
                <h3>Compatibility</h3>
                <p>Some platforms only accept certain formats. Converters bridge that gap so files work where they are supposed to work.</p>
            </article>
            <article class="mini-card">
                <h3>Editability</h3>
                <p>A file may be readable but hard to edit. Changing the format can return it to a more useful working state.</p>
            </article>
            <article class="mini-card">
                <h3>Presentation</h3>
                <p>PDFs, standardized images, and optimized video containers help work look polished when shared or archived.</p>
            </article>
        </div>
    </section>

    <section class="card section">
        <span class="eyebrow">How FConvert helps</span>
        <h2>A clean path from upload to download</h2>
        <div class="grid two-up">
            <article class="content-card">
                <h3>Simple structure</h3>
                <p>Each page explains what the format is for, why users need it, and how the conversion fits into a real workflow. That makes the site feel guided, not confusing.</p>
            </article>
            <article class="content-card">
                <h3>Responsive design</h3>
                <p>The interface is built with mobile spacing, large tap targets, rounded cards, and readable text so the experience stays comfortable on smaller screens.</p>
            </article>
            <article class="content-card">
                <h3>Consistent branding</h3>
                <p>Every page uses the same polished visual language, which makes the platform feel more professional and easier to navigate.</p>
            </article>
            <article class="content-card">
                <h3>Useful content</h3>
                <p>Converters include tips, FAQs, and short guidance so the page carries value beyond the upload button alone.</p>
            </article>
        </div>
    </section>

    <section class="card section" id="tools">
        <div class="section-head">
            <div>
                <span class="eyebrow">Converter pages</span>
                <h2>All the tools on one beautiful platform</h2>
            </div>
            <p class="section-note">These dedicated pages cover the most useful document, image, audio, and video conversions people ask for most often.</p>
        </div>
        <div class="tool-grid">
            <?php foreach ($pages as $slug => $meta): ?>
                <article class="tool-card">
                    <div class="tool-icon"><?= fconvert_e($meta['icon']) ?></div>
                    <div class="tool-head">
                        <span><?= fconvert_e($meta['from']) ?> → <?= fconvert_e($meta['to']) ?></span>
                        <h3><?= fconvert_e($meta['title']) ?></h3>
                    </div>
                    <p><?= fconvert_e($meta['summary']) ?></p>
                    <a class="tool-link" href="<?= fconvert_e(fconvert_url($meta['file'])) ?>">Open converter</a>
                </article>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="card section">
        <span class="eyebrow">Who it is for</span>
        <h2>Built for real people doing real work</h2>
        <div class="grid two-up">
            <article class="content-card"><h3>Students and teachers</h3><p>Turn assignments, notes, and handouts into formats that are easier to edit or submit.</p></article>
            <article class="content-card"><h3>Offices and businesses</h3><p>Prepare client files, proposals, and reports in polished formats that are easier to share.</p></article>
            <article class="content-card"><h3>Creators and designers</h3><p>Handle image formats and video containers with a cleaner, more dependable workflow.</p></article>
            <article class="content-card"><h3>Everyday users</h3><p>Keep file handling simple when a format just needs to change fast.</p></article>
        </div>
    </section>

    <section class="card section">
        <span class="eyebrow">FAQ</span>
        <h2>Common questions about file conversion</h2>
        <div class="faq-grid">
            <article class="faq-card">
                <strong>Why do file formats matter?</strong>
                <p>Different apps, devices, and platforms prefer different formats. Converters help files open, edit, and display correctly where they need to go.</p>
            </article>
            <article class="faq-card">
                <strong>Is mobile use supported?</strong>
                <p>Yes. The layout is built to stay readable and easy to tap on phones and tablets, with cards and spacing that adapt cleanly.</p>
            </article>
            <article class="faq-card">
                <strong>What kinds of files are covered?</strong>
                <p>Documents, images, audio, and video are included, with the most practical conversions placed into dedicated pages.</p>
            </article>
            <article class="faq-card">
                <strong>Is the site consistent?</strong>
                <p>Every page uses the same modern UI style so visitors always know they are still within FConvert.</p>
            </article>
        </div>
    </section>
</main>
