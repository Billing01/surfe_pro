<?php
require_once __DIR__ . '/data.php';

function fconvert_site_name(): string {
    return 'FConvert';
}

function fconvert_base_url(): string {
    $script = $_SERVER['SCRIPT_NAME'] ?? '';
    return rtrim(str_replace('\\', '/', dirname($script)), '/');
}

function fconvert_url(string $file): string {
    $base = fconvert_base_url();
    return ($base === '' || $base === '.') ? $file : $base . '/' . $file;
}

function fconvert_e(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function fconvert_ensure_dir(string $path): void {
    if (!is_dir($path)) {
        mkdir($path, 0775, true);
    }
}

function fconvert_storage_paths(): array {
    $root = dirname(__DIR__);
    $upload = $root . '/storage/uploads';
    $converted = $root . '/storage/converted';
    $emails = $root . '/storage/emails.txt';
    fconvert_ensure_dir($upload);
    fconvert_ensure_dir($converted);
    if (!file_exists($emails)) {
        file_put_contents($emails, "");
    }
    return [$upload, $converted, $emails];
}

function fconvert_cleanup_old_files(string $dir, int $maxAgeSeconds = 86400): void {
    foreach (glob($dir . '/*') ?: [] as $file) {
        if (is_file($file) && (time() - filemtime($file)) > $maxAgeSeconds) {
            @unlink($file);
        }
    }
}

function fconvert_safe_name(string $name): string {
    $name = preg_replace('/\s+/', '-', $name);
    $name = preg_replace('/[^A-Za-z0-9._-]+/', '-', $name);
    $name = trim($name, '-_.');
    return $name !== '' ? $name : 'file';
}

function fconvert_format_bytes(int $bytes): string {
    $units = ['B', 'KB', 'MB', 'GB'];
    $i = 0;
    $size = (float) $bytes;
    while ($size >= 1024 && $i < count($units) - 1) {
        $size /= 1024;
        $i++;
    }
    return rtrim(rtrim(number_format($size, 2), '0'), '.') . ' ' . $units[$i];
}

function fconvert_run(string $command, ?string &$output = null, ?int &$exitCode = null): bool {
    $desc = [
        1 => ['pipe', 'w'],
        2 => ['pipe', 'w'],
    ];
    $process = proc_open($command, $desc, $pipes);
    if (!is_resource($process)) {
        $exitCode = 1;
        $output = 'Unable to start process.';
        return false;
    }
    $stdout = stream_get_contents($pipes[1]);
    $stderr = stream_get_contents($pipes[2]);
    fclose($pipes[1]);
    fclose($pipes[2]);
    $exitCode = proc_close($process);
    $output = trim($stdout . "\n" . $stderr);
    return $exitCode === 0;
}

function fconvert_result_file(string $path, string $downloadName): string {
    $safe = rawurlencode(basename($path));
    $query = rawurlencode($downloadName);
    return fconvert_url('download.php') . '?file=' . $safe . '&name=' . $query;
}

function fconvert_copy_uploaded_file(array $file, string $dir, string $prefix): array {
    if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'message' => 'Please choose a file before starting the conversion.'];
    }
    if (!is_uploaded_file($file['tmp_name'])) {
        return ['ok' => false, 'message' => 'The uploaded file could not be verified.'];
    }

    $original = fconvert_safe_name(pathinfo($file['name'], PATHINFO_FILENAME));
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $token = $prefix . '-' . bin2hex(random_bytes(6)) . '-' . $original;
    $target = rtrim($dir, '/') . '/' . $token . ($ext ? '.' . $ext : '');

    if (!move_uploaded_file($file['tmp_name'], $target)) {
        return ['ok' => false, 'message' => 'The file could not be saved on the server.'];
    }

    return ['ok' => true, 'path' => $target, 'ext' => $ext, 'original' => $original, 'token' => $token];
}

function fconvert_detect_mime(string $path): string {
    if (!function_exists('mime_content_type')) {
        return '';
    }
    return (string) @mime_content_type($path);
}

function fconvert_convert(array $page, array $file): array {
    [$uploadDir, $convertedDir] = fconvert_storage_paths();
    fconvert_cleanup_old_files($uploadDir, 86400);
    fconvert_cleanup_old_files($convertedDir, 86400);

    $copy = fconvert_copy_uploaded_file($file, $uploadDir, $page['slug']);
    if (!$copy['ok']) {
        return $copy;
    }

    $input = $copy['path'];
    $base = $copy['token'];
    $target = '';
    $downloadName = '';
    $slug = $page['slug'];

    try {
        switch ($slug) {
            case 'jpeg-to-jpg':
            case 'jpg-to-jpeg':
                if (!function_exists('imagecreatefromjpeg')) {
                    return ['ok' => false, 'message' => 'The PHP GD extension is required for image conversions.'];
                }
                $img = @imagecreatefromjpeg($input);
                if (!$img) {
                    return ['ok' => false, 'message' => 'The image could not be read.'];
                }
                $targetExt = $slug === 'jpeg-to-jpg' ? 'jpg' : 'jpeg';
                $target = $convertedDir . '/' . $base . '.' . $targetExt;
                imageinterlace($img, true);
                imagejpeg($img, $target, 95);
                imagedestroy($img);
                $downloadName = $copy['original'] . '.' . $targetExt;
                break;

            case 'png-to-jpg':
                if (!function_exists('imagecreatefrompng')) {
                    return ['ok' => false, 'message' => 'The PHP GD extension is required for image conversions.'];
                }
                $src = @imagecreatefrompng($input);
                if (!$src) {
                    return ['ok' => false, 'message' => 'The PNG image could not be read.'];
                }
                $w = imagesx($src);
                $h = imagesy($src);
                $canvas = imagecreatetruecolor($w, $h);
                $white = imagecolorallocate($canvas, 255, 255, 255);
                imagefilledrectangle($canvas, 0, 0, $w, $h, $white);
                imagecopy($canvas, $src, 0, 0, 0, 0, $w, $h);
                $target = $convertedDir . '/' . $base . '.jpg';
                imagejpeg($canvas, $target, 92);
                imagedestroy($src);
                imagedestroy($canvas);
                $downloadName = $copy['original'] . '.jpg';
                break;

            case 'jpg-to-png':
                if (!function_exists('imagecreatefromjpeg')) {
                    return ['ok' => false, 'message' => 'The PHP GD extension is required for image conversions.'];
                }
                $src = @imagecreatefromjpeg($input);
                if (!$src) {
                    return ['ok' => false, 'message' => 'The JPG image could not be read.'];
                }
                $w = imagesx($src);
                $h = imagesy($src);
                $canvas = imagecreatetruecolor($w, $h);
                imagecopy($canvas, $src, 0, 0, 0, 0, $w, $h);
                $target = $convertedDir . '/' . $base . '.png';
                imagepng($canvas, $target, 6);
                imagedestroy($src);
                imagedestroy($canvas);
                $downloadName = $copy['original'] . '.png';
                break;

            case 'webp-to-png':
                if (!function_exists('imagecreatefromwebp')) {
                    return ['ok' => false, 'message' => 'Your server does not support WebP in GD.'];
                }
                $src = @imagecreatefromwebp($input);
                if (!$src) {
                    return ['ok' => false, 'message' => 'The WebP image could not be read.'];
                }
                $target = $convertedDir . '/' . $base . '.png';
                imagepng($src, $target, 6);
                imagedestroy($src);
                $downloadName = $copy['original'] . '.png';
                break;

            case 'png-to-webp':
                if (!function_exists('imagecreatefrompng') || !function_exists('imagewebp')) {
                    return ['ok' => false, 'message' => 'Your server does not support WebP image creation in GD.'];
                }
                $src = @imagecreatefrompng($input);
                if (!$src) {
                    return ['ok' => false, 'message' => 'The PNG image could not be read.'];
                }
                $w = imagesx($src);
                $h = imagesy($src);
                $canvas = imagecreatetruecolor($w, $h);
                imagealphablending($canvas, false);
                imagesavealpha($canvas, true);
                $transparent = imagecolorallocatealpha($canvas, 0, 0, 0, 127);
                imagefilledrectangle($canvas, 0, 0, $w, $h, $transparent);
                imagecopy($canvas, $src, 0, 0, 0, 0, $w, $h);
                $target = $convertedDir . '/' . $base . '.webp';
                imagewebp($canvas, $target, 85);
                imagedestroy($src);
                imagedestroy($canvas);
                $downloadName = $copy['original'] . '.webp';
                break;

            case 'webp-to-jpg':
                if (!function_exists('imagecreatefromwebp')) {
                    return ['ok' => false, 'message' => 'Your server does not support WebP in GD.'];
                }
                $src = @imagecreatefromwebp($input);
                if (!$src) {
                    return ['ok' => false, 'message' => 'The WebP image could not be read.'];
                }
                $w = imagesx($src);
                $h = imagesy($src);
                $canvas = imagecreatetruecolor($w, $h);
                $white = imagecolorallocate($canvas, 255, 255, 255);
                imagefilledrectangle($canvas, 0, 0, $w, $h, $white);
                imagecopy($canvas, $src, 0, 0, 0, 0, $w, $h);
                $target = $convertedDir . '/' . $base . '.jpg';
                imagejpeg($canvas, $target, 92);
                imagedestroy($src);
                imagedestroy($canvas);
                $downloadName = $copy['original'] . '.jpg';
                break;

            case 'docx-to-pdf':
            case 'doc-to-pdf':
            case 'txt-to-pdf':
                $cmd = 'libreoffice --headless --convert-to pdf --outdir ' . escapeshellarg($convertedDir) . ' ' . escapeshellarg($input);
                $out = '';
                $code = 0;
                if (!fconvert_run($cmd, $out, $code)) {
                    return ['ok' => false, 'message' => 'Document conversion failed: ' . ($out ?: 'LibreOffice could not finish the job.')];
                }
                $expected = $convertedDir . '/' . pathinfo($input, PATHINFO_FILENAME) . '.pdf';
                if (!file_exists($expected)) {
                    $matches = glob($convertedDir . '/' . pathinfo($input, PATHINFO_FILENAME) . '*.pdf');
                    $expected = $matches[0] ?? '';
                }
                if (!$expected || !file_exists($expected)) {
                    return ['ok' => false, 'message' => 'PDF output was not created.'];
                }
                $target = $expected;
                $downloadName = $copy['original'] . '.pdf';
                break;

            case 'pdf-to-docx':
                $txt = $convertedDir . '/' . $base . '.txt';
                $docx = $convertedDir . '/' . $base . '.docx';
                $pdftotext = 'pdftotext ' . escapeshellarg($input) . ' ' . escapeshellarg($txt);
                $out1 = '';
                $code1 = 0;
                if (!fconvert_run($pdftotext, $out1, $code1)) {
                    return ['ok' => false, 'message' => 'PDF text extraction failed: ' . ($out1 ?: 'pdftotext could not read the file.')];
                }
                $pandoc = 'pandoc ' . escapeshellarg($txt) . ' -o ' . escapeshellarg($docx);
                $out2 = '';
                $code2 = 0;
                if (!fconvert_run($pandoc, $out2, $code2)) {
                    return ['ok' => false, 'message' => 'DOCX generation failed: ' . ($out2 ?: 'pandoc could not create the file.')];
                }
                @unlink($txt);
                if (!file_exists($docx)) {
                    return ['ok' => false, 'message' => 'The DOCX file was not created.'];
                }
                $target = $docx;
                $downloadName = $copy['original'] . '.docx';
                break;

            case 'pdf-to-txt':
                $txt = $convertedDir . '/' . $base . '.txt';
                $cmd = 'pdftotext ' . escapeshellarg($input) . ' ' . escapeshellarg($txt);
                $out = '';
                $code = 0;
                if (!fconvert_run($cmd, $out, $code)) {
                    return ['ok' => false, 'message' => 'PDF text extraction failed: ' . ($out ?: 'pdftotext could not read the file.')];
                }
                if (!file_exists($txt)) {
                    return ['ok' => false, 'message' => 'The TXT file was not created.'];
                }
                $target = $txt;
                $downloadName = $copy['original'] . '.txt';
                break;

            case 'mp4-to-avi':
                $target = $convertedDir . '/' . $base . '.avi';
                $cmd = 'ffmpeg -y -i ' . escapeshellarg($input) . ' -c:v mpeg4 -q:v 5 -c:a libmp3lame -q:a 4 ' . escapeshellarg($target);
                $out = '';
                $code = 0;
                if (!fconvert_run($cmd, $out, $code)) {
                    return ['ok' => false, 'message' => 'Video conversion failed: ' . ($out ?: 'ffmpeg could not complete the conversion.')];
                }
                if (!file_exists($target)) {
                    return ['ok' => false, 'message' => 'The AVI file was not created.'];
                }
                $downloadName = $copy['original'] . '.avi';
                break;

            case 'avi-to-mp4':
                $target = $convertedDir . '/' . $base . '.mp4';
                $cmd = 'ffmpeg -y -i ' . escapeshellarg($input) . ' -c:v libx264 -preset veryfast -crf 23 -c:a aac -b:a 128k ' . escapeshellarg($target);
                $out = '';
                $code = 0;
                if (!fconvert_run($cmd, $out, $code)) {
                    return ['ok' => false, 'message' => 'Video conversion failed: ' . ($out ?: 'ffmpeg could not complete the conversion.')];
                }
                if (!file_exists($target)) {
                    return ['ok' => false, 'message' => 'The MP4 file was not created.'];
                }
                $downloadName = $copy['original'] . '.mp4';
                break;

            case 'mp3-to-wav':
                $target = $convertedDir . '/' . $base . '.wav';
                $cmd = 'ffmpeg -y -i ' . escapeshellarg($input) . ' ' . escapeshellarg($target);
                $out = '';
                $code = 0;
                if (!fconvert_run($cmd, $out, $code)) {
                    return ['ok' => false, 'message' => 'Audio conversion failed: ' . ($out ?: 'ffmpeg could not complete the conversion.')];
                }
                if (!file_exists($target)) {
                    return ['ok' => false, 'message' => 'The WAV file was not created.'];
                }
                $downloadName = $copy['original'] . '.wav';
                break;

            case 'wav-to-mp3':
                $target = $convertedDir . '/' . $base . '.mp3';
                $cmd = 'ffmpeg -y -i ' . escapeshellarg($input) . ' -codec:a libmp3lame -q:a 4 ' . escapeshellarg($target);
                $out = '';
                $code = 0;
                if (!fconvert_run($cmd, $out, $code)) {
                    return ['ok' => false, 'message' => 'Audio conversion failed: ' . ($out ?: 'ffmpeg could not complete the conversion.')];
                }
                if (!file_exists($target)) {
                    return ['ok' => false, 'message' => 'The MP3 file was not created.'];
                }
                $downloadName = $copy['original'] . '.mp3';
                break;

            default:
                return ['ok' => false, 'message' => 'This converter is not configured yet.'];
        }
    } catch (Throwable $e) {
        return ['ok' => false, 'message' => 'Something went wrong: ' . $e->getMessage()];
    }

    return [
        'ok' => true,
        'message' => 'Conversion completed successfully.',
        'download_path' => $target,
        'download_url' => fconvert_result_file($target, $downloadName),
        'download_name' => $downloadName,
        'input_name' => $copy['original'] . '.' . $copy['ext'],
        'size' => file_exists($target) ? filesize($target) : 0,
    ];
}
