<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
require_once __DIR__ . '/functions.php';
$pages = fconvert_nav_pages();
$current = $current ?? '';
$siteName = fconvert_site_name();
$showSignup = empty($_SESSION['msg']) && empty($_COOKIE['msg']);
$siteTitle = $pageTitle ?? ($siteName . ' File Converter');
$siteDescription = $pageDescription ?? 'A modern file conversion platform for documents, images, audio, and video.';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= fconvert_e($siteTitle) ?></title>
    <meta name="description" content="<?= fconvert_e($siteDescription) ?>">
    <meta name="theme-color" content="#0f172a">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Manrope:wght@500;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= fconvert_e(fconvert_url('assets/css/style.css')) ?>">
    <script defer src="<?= fconvert_e(fconvert_url('assets/js/main.js')) ?>"></script>
</head>
<body data-show-signup="<?= $showSignup ? '1' : '0' ?>">
<div class="page">
    <header class="site-header">
        <a class="brand" href="<?= fconvert_e(fconvert_url('index.php')) ?>" aria-label="FConvert home">
            <span class="brand-icon">FC</span>
            <span class="brand-copy">
                <strong>FConvert</strong>
                <small>Beautiful file conversion for modern users</small>
            </span>
        </a>

        <button class="nav-toggle" type="button" aria-controls="site-nav" aria-expanded="false">
            <span></span><span></span><span></span>
        </button>

        <nav id="site-nav" class="site-nav">
            <a href="<?= fconvert_e(fconvert_url('index.php')) ?>" class="<?= $current === 'home' ? 'active' : '' ?>">Home</a>
            <?php foreach ($pages as $slug => $meta): ?>
                <a href="<?= fconvert_e(fconvert_url($meta['file'])) ?>" class="<?= $current === $slug ? 'active' : '' ?>"><?= fconvert_e($meta['title']) ?></a>
            <?php endforeach; ?>
        </nav>
    </header>
    <div class="header-strip">
        <span class="strip-pill">76k+ users</span>
        <span class="strip-text">Fast, mobile-first converters built for daily document, image, audio, and video work.</span>
    </div>
