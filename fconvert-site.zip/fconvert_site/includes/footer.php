    <footer class="site-footer">
        <div>
            <strong>FConvert</strong>
            <p>Simple, polished file conversion for students, creators, offices, and everyday users.</p>
        </div>
        <div>
            <span>WhatsApp contact</span>
            <a href="https://wa.me/2347012265612" target="_blank" rel="noopener noreferrer">+2347012265612</a>
        </div>
    </footer>
</div>

<div class="signup-modal<?= $showSignup ? ' is-open' : '' ?>" id="signupModal" aria-hidden="<?= $showSignup ? 'false' : 'true' ?>">
    <div class="signup-backdrop" data-close-signup></div>
    <div class="signup-dialog" role="dialog" aria-modal="true" aria-labelledby="signupTitle">
        <button class="signup-close" type="button" aria-label="Close popup" data-close-signup>×</button>
        <div class="signup-badge">Welcome</div>
        <h2 id="signupTitle">Welcome to FConvert, please enter your email to receive updates when we add new tools.</h2>
        <p>Be the first to know when new converters, smarter workflows, and fresh platform improvements are released.</p>
        <form class="signup-form" id="signupForm" action="<?= fconvert_e(fconvert_url('subscribe.php')) ?>" method="post">
            <input type="email" name="email" inputmode="email" autocomplete="email" placeholder="Enter your email address" required>
            <button type="submit">Subscribe</button>
        </form>
        <button class="skip-link" type="button" data-close-signup>Skip for now</button>
        <noscript>
            <p class="note">JavaScript is disabled. Use the form above to submit your email or skip the popup.</p>
        </noscript>
    </div>
</div>
</body>
</html>
