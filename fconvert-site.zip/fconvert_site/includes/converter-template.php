<?php
require_once __DIR__ . '/functions.php';
$pages = fconvert_nav_pages();
$page = $pages[$slug] ?? null;
if (!$page) {
    http_response_code(404);
    echo 'Converter not found.';
    exit;
}

$pageTitle = 'FConvert — ' . $page['title'];
$pageDescription = $page['summary'];
$result = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $result = fconvert_convert($page, $_FILES['source_file'] ?? []);
}

$current = $slug;
require __DIR__ . '/header.php';
?>
<main class="main-content">
    <section class="hero hero-converter">
        <div class="hero-copy">
            <span class="badge">
                <span class="dot"></span>
                <?= fconvert_e($page['badge']) ?>
            </span>
            <h1><?= fconvert_e($page['title']) ?></h1>
            <p><?= fconvert_e($page['hero']) ?></p>
            <p><?= fconvert_e($page['summary']) ?></p>
            <div class="hero-actions">
                <a class="btn btn-primary" href="#converterForm"><?= fconvert_e($page['cta']) ?></a>
                <a class="btn btn-ghost" href="<?= fconvert_e(fconvert_url('index.php')) ?>">Back to home</a>
            </div>
            <div class="format-row">
                <span><?= fconvert_e($page['from']) ?></span>
                <i>→</i>
                <span><?= fconvert_e($page['to']) ?></span>
                <i>•</i>
                <span><?= fconvert_e($page['icon']) ?></span>
            </div>
        </div>

        <div class="hero-panel">
            <div class="stats-grid">
                <div class="stat-card">
                    <strong>76k+</strong>
                    <span>users and growing</span>
                </div>
                <div class="stat-card">
                    <strong><?= fconvert_e($page['from']) ?></strong>
                    <span>source format</span>
                </div>
                <div class="stat-card">
                    <strong><?= fconvert_e($page['to']) ?></strong>
                    <span>destination format</span>
                </div>
                <div class="stat-card">
                    <strong>Mobile</strong>
                    <span>friendly experience</span>
                </div>
            </div>
            <div class="info-panel">
                <h3>Why this conversion matters</h3>
                <p><?= fconvert_e($page['processing']) ?></p>
            </div>
        </div>
    </section>

    <section class="card section" id="converterForm">
        <div class="section-head">
            <div>
                <span class="eyebrow">Upload and convert</span>
                <h2>Get your <?= fconvert_e(strtolower($page['to'])) ?> file in a few steps</h2>
            </div>
            <p class="section-note">Use the form below to upload a file and generate a converted copy. The page is laid out for clarity on mobile and desktop alike.</p>
        </div>

        <?php if ($result): ?>
            <div class="result-box <?= !empty($result['ok']) ? 'success' : 'error' ?>">
                <strong><?= !empty($result['ok']) ? 'Conversion successful' : 'Conversion failed' ?></strong>
                <p><?= fconvert_e($result['message']) ?></p>
                <?php if (!empty($result['ok']) && !empty($result['download_url'])): ?>
                    <a class="btn btn-primary" href="<?= fconvert_e($result['download_url']) ?>">Download converted file</a>
                    <div class="meta-line">
                        <span>Output: <?= fconvert_e($result['download_name'] ?? '') ?></span>
                        <?php if (!empty($result['size'])): ?>
                            <span>Size: <?= fconvert_e(fconvert_format_bytes((int)$result['size'])) ?></span>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <form class="upload-form" method="post" enctype="multipart/form-data">
            <label class="upload-zone">
                <input type="file" name="source_file" required>
                <span class="upload-icon">⬆</span>
                <span class="upload-title">Tap to choose your <?= fconvert_e(strtolower($page['from'])) ?> file</span>
                <span class="upload-subtitle">Accepted formats: <?= fconvert_e(implode(', ', $page['supported'])) ?></span>
            </label>
            <button class="btn btn-primary" type="submit"><?= fconvert_e($page['cta']) ?></button>
        </form>
    </section>

    <section class="grid two-up section">
        <article class="card">
            <span class="eyebrow">Why people use it</span>
            <h2>Practical reasons this converter stays useful</h2>
            <ul class="bullets">
                <?php foreach ($page['reasons'] as $item): ?>
                    <li><?= fconvert_e($item) ?></li>
                <?php endforeach; ?>
            </ul>
        </article>
        <article class="card">
            <span class="eyebrow">Common use cases</span>
            <h2>Where this tool helps in real life</h2>
            <ul class="bullets">
                <?php foreach ($page['use_cases'] as $item): ?>
                    <li><?= fconvert_e($item) ?></li>
                <?php endforeach; ?>
            </ul>
        </article>
    </section>

    <section class="card section">
        <span class="eyebrow">Helpful tips</span>
        <h2>Small details that improve results</h2>
        <div class="tips-grid">
            <?php foreach ($page['tips'] as $tip): ?>
                <div class="tip-card">
                    <strong>Tip</strong>
                    <p><?= fconvert_e($tip) ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="story section">
        <div class="story-card">
            <h2>About this conversion page</h2>
            <p><?= fconvert_e($page['summary']) ?></p>
            <p><?= fconvert_e($page['processing']) ?></p>
            <p>FConvert keeps the same polished interface across every tool so the site feels trustworthy, easy to navigate, and genuinely useful on smaller screens. The design uses clear spacing, readable typography, rounded cards, and simple actions that make conversion tasks feel quick instead of heavy.</p>
        </div>
    </section>

    <section class="ad-stack section">
        <script src="//static.surfe.pro/js/net.js"></script>
        <ins class="surfe-be" data-sid="421283"></ins>
        <ins class="surfe-be" data-sid="421284"></ins>
        <script>
        (adsurfebe = window.adsurfebe || []).push({});
        (adsurfebe = window.adsurfebe || []).push({});
        </script>
    </section>

    <section class="card section">
        <span class="eyebrow">FAQ</span>
        <h2>Frequently asked questions</h2>
        <div class="faq-grid">
            <?php foreach ($page['faq'] as $faq): ?>
                <div class="faq-card">
                    <strong>Question</strong>
                    <p><?= fconvert_e($faq) ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
</main>
<?php require __DIR__ . '/footer.php'; ?>
