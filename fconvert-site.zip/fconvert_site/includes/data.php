<?php
function fconvert_page(
    string $slug,
    string $file,
    string $title,
    string $from,
    string $to,
    string $badge,
    string $hero,
    string $summary,
    string $processing,
    array $useCases,
    array $tips,
    array $faq,
    array $reasons,
    array $supported,
    string $icon
): array {
    return [
        'slug' => $slug,
        'file' => $file,
        'title' => $title,
        'from' => $from,
        'to' => $to,
        'badge' => $badge,
        'hero' => $hero,
        'summary' => $summary,
        'processing' => $processing,
        'use_cases' => $useCases,
        'tips' => $tips,
        'faq' => $faq,
        'reasons' => $reasons,
        'supported' => $supported,
        'icon' => $icon,
        'cta' => 'Start conversion',
        'accent' => 'linear-gradient(135deg, rgba(104, 132, 255, .22), rgba(98, 218, 255, .18))',
    ];
}

function fconvert_pages(): array {
    return [
        'pdf-to-docx' => fconvert_page(
            'pdf-to-docx',
            'pdf-to-docx.php',
            'PDF to DOCX Converter',
            'PDF',
            'DOCX',
            'Editable documents from static PDFs',
            'Transform locked PDFs into editable Word documents with a workflow that feels simple, modern, and dependable on any device.',
            'PDF to DOCX is one of the most useful conversion paths for students, office teams, and anyone who receives documents that need to be edited instead of only viewed. RHOD turns that task into a smooth upload-and-download experience, so you can reopen contracts, notes, handbooks, and reports in an editable Word-friendly format.',
            'This converter extracts readable content from the PDF, rebuilds it into a document, and gives you a file you can open in compatible word processors. Layouts that are clean and text-based usually convert best, while image-only scans may need a quick tidy-up afterward.',
            [
                'Editing reports without retyping everything',
                'Reusing notes, policies, and handouts',
                'Making PDF content workable inside Word'
            ],
            [
                'Use the original PDF for the best output.',
                'Text-based PDFs usually convert more accurately than scanned pages.',
                'After conversion, quickly review headings and tables for layout polish.'
            ],
            [
                'Can scanned PDFs be converted? Yes, but image-only pages may need extra cleanup.',
                'Will the output be editable? Yes, DOCX is built for editing in Word-compatible apps.',
                'Why use this page instead of copy-paste? It preserves much more structure and saves time.'
            ],
            [
                'Recover editable text quickly.',
                'Prepare files for office review.',
                'Reuse PDF content in documents.'
            ],
            ['PDF', 'DOCX'],
            '📄'
        ),
        'docx-to-pdf' => fconvert_page(
            'docx-to-pdf',
            'docx-to-pdf.php',
            'DOCX to PDF Converter',
            'DOCX',
            'PDF',
            'Polished PDFs from Word documents',
            'Convert Word documents into clean PDFs that are easy to share, print, archive, and present across devices.',
            'DOCX to PDF is ideal whenever a document is ready to leave the editing stage and needs a more consistent, professional appearance. RHOD helps convert proposals, application letters, manuals, and business documents into PDF files that preserve structure and travel well across platforms.',
            'The conversion path uses office-friendly rendering so your document can be shared without worrying about fonts shifting across devices. It is especially valuable for final copies, printed submissions, and files that need a more fixed layout.',
            [
                'Sending a final report to a client',
                'Submitting school work with consistent layout',
                'Archiving a Word document in a stable format'
            ],
            [
                'Check page breaks before converting.',
                'Use standard fonts for the safest output.',
                'Keep images optimized if the PDF must stay compact.'
            ],
            [
                'Why choose PDF for delivery? It looks consistent on almost any device.',
                'Can I print the output directly? Yes, PDFs are ideal for printing.',
                'Does the original DOCX remain safe? Yes, only a converted copy is generated.'
            ],
            [
                'Publish final documents neatly.',
                'Keep formatting stable.',
                'Share professional files.'
            ],
            ['DOCX', 'PDF'],
            '🗂️'
        ),
        'doc-to-pdf' => fconvert_page(
            'doc-to-pdf',
            'doc-to-pdf.php',
            'DOC to PDF Converter',
            'DOC',
            'PDF',
            'Older Word files made share-ready',
            'Turn legacy DOC files into readable PDFs without making users wrestle with compatibility issues or outdated software.',
            'DOC files still appear in schools, offices, and shared archives. They often open fine in modern tools, but they are not always the best format to send around. RHOD lets you modernize the file into PDF so the layout becomes easier to preserve and distribute.',
            'This converter is perfect when an old Word file needs to be made more universal. The resulting PDF is simple to attach, print, and view from almost any browser or phone.',
            [
                'Modernizing older document archives',
                'Making a legacy file easier to share',
                'Locking in a stable final copy'
            ],
            [
                'Use DOC files that contain standard text and images.',
                'If the file uses unusual fonts, verify the PDF once it is generated.',
                'PDF is ideal when you want layout consistency.'
            ],
            [
                'Why not keep DOC? Not every device or app handles old DOC files well.',
                'Is DOC the same as DOCX? No, DOC is the older Word format.',
                'Can I print the result? Yes, the PDF is print friendly.'
            ],
            [
                'Upgrade legacy documents.',
                'Share files more easily.',
                'Prepare archive-ready copies.'
            ],
            ['DOC', 'PDF'],
            '📘'
        ),
        'jpeg-to-jpg' => fconvert_page(
            'jpeg-to-jpg',
            'jpeg-to-jpg.php',
            'JPEG to JPG Converter',
            'JPEG',
            'JPG',
            'A simple extension swap that matters',
            'Rename and convert JPEG images to JPG quickly so your files stay consistent across apps, editors, and uploads.',
            'JPEG and JPG are technically the same image family, but many workflows still prefer one extension over the other. RHOD gives you a polished page that helps standardize your images for website uploads, archives, and folders that follow a specific naming convention.',
            'This converter is lightweight but practical. It is especially useful for content managers, designers, and everyday users who want image names to match the extension style used elsewhere in a project.',
            [
                'Standardizing image libraries',
                'Matching website upload requirements',
                'Cleaning up image naming consistency'
            ],
            [
                'The content remains the same; only the extension changes.',
                'Use it when a platform expects .jpg instead of .jpeg.',
                'Keep originals if you need both naming styles.'
            ],
            [
                'Is JPEG different from JPG? The formats are effectively the same.',
                'Why bother converting? Some apps or folders prefer one extension.',
                'Will quality change? No visual change is intended.'
            ],
            [
                'Keep image names consistent.',
                'Satisfy upload rules.',
                'Simplify file organization.'
            ],
            ['JPEG', 'JPG'],
            '🖼️'
        ),
        'jpg-to-jpeg' => fconvert_page(
            'jpg-to-jpeg',
            'jpg-to-jpeg.php',
            'JPG to JPEG Converter',
            'JPG',
            'JPEG',
            'The same image, standardized naming',
            'Switch JPG files to JPEG naming in a neat, browser-friendly workflow that is easy to understand on phones and desktops.',
            'Many people keep folders mixed with JPG and JPEG endings. While the image data is the same, a consistent extension can help teams organize uploads, documentation, and asset libraries with less friction. This page gives that task a professional home.',
            'Use it when the destination system or project convention prefers the longer JPEG extension. The actual image stays the same; the conversion mainly standardizes the filename ending.',
            [
                'Matching folder naming rules',
                'Making image libraries feel tidy',
                'Preparing assets for shared systems'
            ],
            [
                'This is most useful for file naming consistency.',
                'Keep your original image if you want both endings.',
                'Great for teams that enforce a house style.'
            ],
            [
                'Will the image look different? No, the image content stays the same.',
                'Why change the extension only? Some tools and teams prefer JPEG naming.',
                'Is this safe for uploads? Yes, it is a normal file-handling task.'
            ],
            [
                'Organize image folders.',
                'Match naming conventions.',
                'Avoid extension mismatches.'
            ],
            ['JPG', 'JPEG'],
            '🖼️'
        ),
        'png-to-jpg' => fconvert_page(
            'png-to-jpg',
            'png-to-jpg.php',
            'PNG to JPG Converter',
            'PNG',
            'JPG',
            'Smaller images for wider compatibility',
            'Convert PNG files into JPG when you need a lighter image that is easier to upload, share, or display in common workflows.',
            'PNG is excellent for sharp graphics and transparency, but JPG is often preferred when you want broad compatibility and smaller file sizes. RHOD makes that transition feel simple, which is helpful for content creators, marketers, bloggers, and everyday users.',
            'The converter renders the PNG against a solid background and saves it as JPG. It is a practical option when transparency is not required and you want an efficient file for the web or for quick sharing.',
            [
                'Reducing image file size',
                'Uploading to JPG-only platforms',
                'Preparing images for web publishing'
            ],
            [
                'PNG files with transparency will be flattened.',
                'Use JPG when transparency is not needed.',
                'For logos, keep the PNG original too.'
            ],
            [
                'Will transparency be preserved? No, JPG does not support transparency.',
                'Why convert PNG to JPG? Often for smaller, more compatible files.',
                'Does quality stay perfect? JPG is compressed, so tiny changes can occur.'
            ],
            [
                'Optimize web images.',
                'Reduce upload friction.',
                'Share lighter visuals.'
            ],
            ['PNG', 'JPG'],
            '🟣'
        ),
        'jpg-to-png' => fconvert_page(
            'jpg-to-png',
            'jpg-to-png.php',
            'JPG to PNG Converter',
            'JPG',
            'PNG',
            'Sharper assets with optional workflow flexibility',
            'Convert JPG images into PNG files when you need a format that works better for editing, design assets, and transparent workflows.',
            'PNG is useful for graphics, screenshots, and images that need a flexible editing path. Even though a JPG cannot magically regain lost quality, converting to PNG can still help standardize an asset library or prepare an image for further editing in design tools.',
            'This converter is popular when people want a more design-friendly format for later work, especially with screenshots, product visuals, and assets that move into templates or presentation software.',
            [
                'Preparing graphics for design tools',
                'Standardizing screenshots and visuals',
                'Keeping an image in a flexible format'
            ],
            [
                'PNG will not restore detail lost in JPG compression.',
                'Use it when you need a PNG file for tooling or workflows.',
                'Screenshots often look clean in PNG.'
            ],
            [
                'Does conversion improve image quality? Not beyond the original JPG.',
                'Why use PNG? It is widely supported for editing and design tasks.',
                'Can I use it for screenshots? Yes, PNG is often preferred.'
            ],
            [
                'Switch to design-friendly files.',
                'Organize image assets.',
                'Keep workflow flexibility.'
            ],
            ['JPG', 'PNG'],
            '🧩'
        ),
        'webp-to-png' => fconvert_page(
            'webp-to-png',
            'webp-to-png.php',
            'WebP to PNG Converter',
            'WebP',
            'PNG',
            'Modern web images made more flexible',
            'Move WebP images into PNG when you need a format that is easier to reuse in design tools and older software.',
            'WebP is efficient for the web, but some apps and workflows still work better with PNG. This converter gives you a clear path for bringing modern web graphics into a format with broader editing support and better compatibility in older environments.',
            'It is a practical choice when you need an asset for presentations, design systems, or software that still expects PNG-based uploads.',
            [
                'Using images in older applications',
                'Moving web graphics into design workflows',
                'Preparing files for broader compatibility'
            ],
            [
                'WebP is efficient, but not every app supports it equally.',
                'PNG is a good fallback for many workflows.',
                'Use the original WebP when you want the smallest file.'
            ],
            [
                'Will PNG be larger? Often yes, because PNG is less compressed.',
                'Can transparent WebP stay transparent? Usually yes, if supported by the image library.',
                'Why convert at all? Compatibility and workflow reasons.'
            ],
            [
                'Improve compatibility.',
                'Reuse web graphics elsewhere.',
                'Keep design work moving.'
            ],
            ['WebP', 'PNG'],
            '🌐'
        ),
        'png-to-webp' => fconvert_page(
            'png-to-webp',
            'png-to-webp.php',
            'PNG to WebP Converter',
            'PNG',
            'WebP',
            'Smaller modern web-ready images',
            'Convert PNG graphics into WebP to reduce file size and make uploads feel faster on web-focused projects.',
            'WebP helps websites load more efficiently while keeping images looking sharp. RHOD makes this conversion easy for creators who need responsive pages, lighter assets, and better performance without losing the convenience of a browser-based workflow.',
            'This page is ideal for web designers, bloggers, and site owners who want a modern format for product photos, illustrations, and gallery content.',
            [
                'Improving page load performance',
                'Preparing assets for modern websites',
                'Reducing media weight without extra tools'
            ],
            [
                'Great for websites and online galleries.',
                'Keep PNG if you need advanced editing later.',
                'WebP is supported by most modern browsers.'
            ],
            [
                'Why use WebP? It often gives smaller files for web delivery.',
                'Will the image still look good? Usually yes, especially for photos.',
                'Can I keep transparency? WebP supports transparency in many cases.'
            ],
            [
                'Optimize site performance.',
                'Modernize image delivery.',
                'Save bandwidth and space.'
            ],
            ['PNG', 'WebP'],
            '🚀'
        ),
        'mp4-to-avi' => fconvert_page(
            'mp4-to-avi',
            'mp4-to-avi.php',
            'MP4 to AVI Converter',
            'MP4',
            'AVI',
            'Video compatibility for older tools',
            'Convert MP4 videos into AVI when you need a format that works better with certain editors, devices, or legacy systems.',
            'MP4 is the default for many modern uses, but AVI still matters in some workflows. RHOD presents the conversion in a clean, reassuring way so users can adapt a video file for older software or specialized playback needs without confusion.',
            'This is especially useful in office setups, media labs, and environments where an AVI container is preferred over MP4 for compatibility reasons.',
            [
                'Meeting older software requirements',
                'Using a video in legacy playback systems',
                'Creating compatibility-focused copies'
            ],
            [
                'AVI files can become larger than MP4.',
                'Use a short test clip first for important projects.',
                'Keep the MP4 original in case you need it later.'
            ],
            [
                'Why convert MP4 to AVI? Compatibility with older systems.',
                'Will the file be larger? Often yes, depending on settings.',
                'Can every video convert perfectly? Results depend on codecs and source quality.'
            ],
            [
                'Improve playback compatibility.',
                'Support older tools.',
                'Handle specialized workflows.'
            ],
            ['MP4', 'AVI'],
            '🎬'
        ),
        'avi-to-mp4' => fconvert_page(
            'avi-to-mp4',
            'avi-to-mp4.php',
            'AVI to MP4 Converter',
            'AVI',
            'MP4',
            'Make video easier to share',
            'Turn AVI files into MP4 for broader compatibility, smoother sharing, and a more web-friendly video format.',
            'AVI files can be useful, but MP4 is usually the more convenient option for browsers, phones, and modern media players. RHOD makes the change easy so your video can be shared, uploaded, and viewed in more places.',
            'This converter is one of the most practical video tools on the platform because MP4 is such a universal delivery format for online and offline use.',
            [
                'Preparing clips for sharing online',
                'Making videos easier to play on mobile',
                'Standardizing old footage into MP4'
            ],
            [
                'MP4 is usually lighter and more compatible.',
                'Great for uploads, previews, and phone playback.',
                'Keep the AVI source as your master copy when possible.'
            ],
            [
                'Why choose MP4? It is broadly supported across devices and platforms.',
                'Can I upload the result to websites? Usually yes, MP4 is widely accepted.',
                'Does the quality stay the same? It depends on the source and encoder settings.'
            ],
            [
                'Share video more easily.',
                'Improve mobile compatibility.',
                'Use a modern format.'
            ],
            ['AVI', 'MP4'],
            '📱'
        ),
        'mp3-to-wav' => fconvert_page(
            'mp3-to-wav',
            'mp3-to-wav.php',
            'MP3 to WAV Converter',
            'MP3',
            'WAV',
            'Audio for editing and production',
            'Convert MP3 audio into WAV when you need a less compressed format for editing, mastering, or production work.',
            'MP3 is excellent for distribution, but WAV is widely used inside audio software because it preserves more of the working signal and behaves well in production workflows. RHOD gives that process a clean, modern page for creators and editors.',
            'This converter is especially useful for podcasters, musicians, and video editors who need audio in a format that is easier to process further in editing software.',
            [
                'Preparing audio for editing software',
                'Working on podcast or music production',
                'Using audio in systems that prefer WAV'
            ],
            [
                'WAV files are often much larger than MP3.',
                'Use it when you plan to edit or process the sound further.',
                'Keep the MP3 if you only need normal playback.'
            ],
            [
                'Why convert MP3 to WAV? Better for editing and production workflows.',
                'Will file size increase? Yes, often significantly.',
                'Is WAV always better? Not for storage or casual sharing.'
            ],
            [
                'Support audio editing.',
                'Work in production tools.',
                'Keep a clean format for sessions.'
            ],
            ['MP3', 'WAV'],
            '🎧'
        ),
        'wav-to-mp3' => fconvert_page(
            'wav-to-mp3',
            'wav-to-mp3.php',
            'WAV to MP3 Converter',
            'WAV',
            'MP3',
            'Smaller audio for everyday sharing',
            'Convert WAV files into MP3 to make audio lighter, easier to send, and more practical for everyday listening.',
            'WAV is excellent for quality and editing, but MP3 is often the better delivery format when you want a smaller file for phones, emails, websites, and messaging apps. RHOD turns that shift into a fast, user-friendly page.',
            'This converter helps shrink large recordings into a format that travels better while still sounding good for many normal listening situations.',
            [
                'Sharing voice notes and recordings',
                'Reducing the size of audio files',
                'Publishing audio for general listeners'
            ],
            [
                'MP3 is usually much smaller than WAV.',
                'Great for distribution and everyday listening.',
                'Keep the WAV source if you need studio-quality editing later.'
            ],
            [
                'Why convert to MP3? Smaller files are easier to share.',
                'Does MP3 lose some quality? Yes, it is a compressed format.',
                'Is MP3 good for web use? Yes, for most normal audio delivery tasks.'
            ],
            [
                'Make audio easier to send.',
                'Reduce storage use.',
                'Share files conveniently.'
            ],
            ['WAV', 'MP3'],
            '🔊'
        ),
    ];
}

function fconvert_nav_pages(): array {
    return fconvert_pages();
}
