<?php
$slug = 'wav-to-mp3';
require __DIR__ . '/includes/converter-template.php';
