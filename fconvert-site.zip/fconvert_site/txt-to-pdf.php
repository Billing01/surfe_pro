<?php
$slug = 'txt-to-pdf';
require __DIR__ . '/includes/converter-template.php';
