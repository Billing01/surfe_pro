<?php
$base = dirname(__FILE__);
$file = isset($_GET['file']) ? basename($_GET['file']) : '';
$name = isset($_GET['name']) ? preg_replace('/[^A-Za-z0-9._-]+/', '-', $_GET['name']) : 'download';

$path = $base . '/storage/converted/' . $file;
if (!is_file($path)) {
    http_response_code(404);
    echo 'File not found.';
    exit;
}

header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . str_replace('"', '', $name) . '"');
header('Content-Length: ' . filesize($path));
readfile($path);
exit;
