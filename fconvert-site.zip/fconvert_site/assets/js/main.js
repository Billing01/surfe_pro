document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.site-nav');
  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      nav.classList.toggle('open');
    });
  }

  const modal = document.getElementById('signupModal');
  const body = document.body;
  const showSignup = body?.dataset?.showSignup === '1';

  function closeModal() {
    if (!modal) return;
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden', 'true');
    body?.classList.remove('modal-open');
  }

  async function postSignup(data) {
    const res = await fetch(modal.querySelector('form').action, {
      method: 'POST',
      headers: { 'Accept': 'application/json' },
      body: data
    });
    return await res.json();
  }

  if (showSignup && modal) {
    body?.classList.add('modal-open');
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
  }

  document.querySelectorAll('[data-close-signup]').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (!modal || !modal.classList.contains('is-open')) {
        closeModal();
        return;
      }
      try {
        const formData = new FormData();
        formData.append('action', 'skip');
        await postSignup(formData);
      } catch (e) {
        // still close; server may be unavailable
      } finally {
        closeModal();
      }
    });
  });

  const form = document.getElementById('signupForm');
  if (form) {
    form.addEventListener('submit', async (ev) => {
      ev.preventDefault();
      const btn = form.querySelector('button[type="submit"]');
      const originalText = btn ? btn.textContent : '';
      if (btn) {
        btn.disabled = true;
        btn.textContent = 'Sending...';
      }
      try {
        const data = new FormData(form);
        const res = await postSignup(data);
        if (res && res.ok) {
          closeModal();
        } else {
          alert(res?.message || 'Please enter a valid email address.');
        }
      } catch (e) {
        alert('Unable to send your email right now.');
      } finally {
        if (btn) {
          btn.disabled = false;
          btn.textContent = originalText || 'Subscribe';
        }
      }
    });
  }
});
