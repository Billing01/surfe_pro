<?php
require_once __DIR__ . '/includes/functions.php';
$pageTitle = 'FConvert — Modern File Conversion Platform';
$pageDescription = 'FConvert helps users convert documents, images, audio, and video files with a beautiful mobile-first interface.';
$current = 'home';
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/home-content.php';
require __DIR__ . '/includes/footer.php';
