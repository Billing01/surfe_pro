<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
require_once __DIR__ . '/includes/functions.php';
[$uploadDir, $convertedDir, $emailsFile] = fconvert_storage_paths();

function fconvert_set_seen(): void {
    $_SESSION['msg'] = 1;
    setcookie('msg', '1', time() + 31536000, '/', '', false, true);
}

$action = $_POST['action'] ?? '';
$email = trim((string)($_POST['email'] ?? ''));

$response = ['ok' => false, 'message' => ''];

if ($action === 'skip') {
    fconvert_set_seen();
    $response = ['ok' => true, 'message' => 'Skipped'];
} else {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $response = ['ok' => false, 'message' => 'Please enter a valid email address.'];
    } else {
        $line = strtolower($email) . PHP_EOL;
        file_put_contents($emailsFile, $line, FILE_APPEND | LOCK_EX);
        fconvert_set_seen();
        $response = ['ok' => true, 'message' => 'Subscribed'];
    }
}

if (isset($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json')) {
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

if ($response['ok']) {
    header('Location: ' . fconvert_url('index.php') . '?signup=1');
    exit;
}

header('Location: ' . fconvert_url('index.php') . '?signup=error');
exit;
