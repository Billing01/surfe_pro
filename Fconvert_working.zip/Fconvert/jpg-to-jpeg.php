<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/converter-engine.php';
$slug = 'jpg-to-jpeg';
include __DIR__ . '/includes/converter-page.php';
