<?php
$slug = $slug ?? '';
$tool = fconvert_get_tool($slug);
if (!$tool) {
    http_response_code(404);
    exit('Converter not found');
}

$page_title = 'Fconvert | ' . $tool['title'];
$page_description = $tool['description'];
$active_page = $tool['slug'];
$hero_badge = '76k+ users trust Fconvert';
$hero_title = $tool['headline'];
$hero_subtitle = $tool['subtitle'];

$result = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['convert_submit'])) {
    $result = fconvert_handle_conversion($tool, $_FILES['source_file'] ?? null);
}

include __DIR__ . '/header.php';
?>
<section class="converter-hero">
  <div class="container">
    <div class="converter-banner">
      <div>
        <div class="badge-users">★ 76k+ users</div>
        <h1><?= htmlspecialchars($tool['title']) ?></h1>
        <p><?= htmlspecialchars($tool['description']) ?> This page gives visitors a polished conversion experience with a strong explanation of why the format switch matters, plus a real upload form below.</p>
      </div>
      <div class="converter-chip">
        <strong><?= htmlspecialchars($tool['from']) ?> → <?= htmlspecialchars($tool['to']) ?></strong>
        <span>Fast format switching</span>
      </div>
    </div>
  </div>
</section>

<section class="section">
  <div class="container content-grid">
    <article class="panel">
      <h2>Why this converter matters</h2>
      <p>Different users need different formats for editing, printing, sending, viewing, and publishing. A document may be easier to revise in Word, while a PDF is better for final sharing. Images may need a different extension for compatibility, and video containers can affect playback on certain devices.</p>
      <p>Fconvert exists to make those transitions simpler. Each page is designed to feel welcoming, clear, and trustworthy, while still giving you a practical upload-and-convert workflow underneath.</p>
      <ul class="list">
        <?php foreach ($tool['benefits'] as $benefit): ?>
        <li><?= htmlspecialchars($benefit) ?></li>
        <?php endforeach; ?>
      </ul>
    </article>

    <aside class="panel">
      <h3>Common use cases</h3>
      <div class="faq">
        <div class="faq-item">
          <h4>School and office documents</h4>
          <p>Prepare files in the format your lecturer, client, or colleague expects.</p>
        </div>
        <div class="faq-item">
          <h4>Image and media workflows</h4>
          <p>Match the output format to the platform, app, or publishing target.</p>
        </div>
        <div class="faq-item">
          <h4>Web publishing</h4>
          <p>Use lighter and more compatible formats where performance matters.</p>
        </div>
      </div>
    </aside>
  </div>
</section>

<section class="section">
  <div class="container upload-grid">
    <div class="upload-card">
      <h3>Upload your file</h3>
      <p>This is the real conversion entry point. Select a file and Fconvert will process it server-side and return a downloadable result.</p>
      <form method="post" enctype="multipart/form-data">
        <div class="field">
          <label for="source_file">Choose a file</label>
          <input type="file" id="source_file" name="source_file" accept="<?= htmlspecialchars(fconvert_accept_for_slug($tool['slug'])) ?>" required>
        </div>
        <input type="hidden" name="convert_submit" value="1">
        <div class="form-actions">
          <button class="cta-btn" type="submit">Convert now</button>
          <a class="secondary-btn" href="<?= htmlspecialchars(fconvert_url('index.php')) ?>">Back to home</a>
        </div>
      </form>
      <div class="note-box" style="margin-top:16px;">
        Supported output: <strong style="color:var(--text)"><?= htmlspecialchars($tool['to']) ?></strong>. The conversion will use the server tools available for this format pair, such as LibreOffice, FFmpeg, or ImageMagick depending on the selected page.
      </div>

      <?php if (is_array($result)): ?>
        <?php if (!empty($result['ok'])): ?>
          <div class="flash success">
            <?= htmlspecialchars($result['message']) ?><br>
            <strong>Output:</strong> <?= htmlspecialchars($result['output_name'] ?? '') ?><br>
            <a class="cta-btn" style="margin-top:12px;" href="<?= htmlspecialchars($result['url']) ?>" download>Download converted file</a>
          </div>
        <?php else: ?>
          <div class="flash error"><?= htmlspecialchars($result['message'] ?? 'Conversion failed.') ?></div>
        <?php endif; ?>
      <?php endif; ?>
    </div>

    <div class="upload-card">
      <h3>What users get here</h3>
      <p>A polished explanation of the conversion flow, a direct upload action, and a clear download result once the server finishes processing the file.</p>
      <ul class="list">
        <li>Easy-to-read page content for first-time visitors.</li>
        <li>Strong calls to action without clutter.</li>
        <li>Server-side conversion instead of a fake placeholder.</li>
      </ul>
      <div class="note-box">
        Popular format conversions help users move faster between offices, devices, clients, and publishing tools. That is why every converter page includes enough content to feel complete and credible.
      </div>
    </div>
  </div>
</section>

<section class="section">
  <div class="container content-grid">
    <div class="panel">
      <h3>Frequently asked questions</h3>
      <div class="faq">
        <div class="faq-item">
          <h4>Why are file converters useful?</h4>
          <p>Because different apps and platforms prefer different formats. Conversion saves time and avoids compatibility problems.</p>
        </div>
        <div class="faq-item">
          <h4>Is this page mobile friendly?</h4>
          <p>Yes. The layout automatically stacks neatly on smaller screens and keeps important actions easy to tap.</p>
        </div>
        <div class="faq-item">
          <h4>Can more converter pages be added?</h4>
          <p>Yes. The structure is reusable, so you can add more tools without redesigning the site.</p>
        </div>
      </div>
    </div>
    <div class="panel">
      <h3>Need another converter?</h3>
      <p>Each page in Fconvert is styled to look like a real product landing page, not just a plain utility screen. That gives your visitors a more confident and professional experience.</p>
      <div class="form-actions">
        <a class="cta-btn" href="<?= htmlspecialchars(fconvert_url('index.php')) ?>">Back to home</a>
        <a class="secondary-btn" href="https://wa.me/2347012265612" target="_blank" rel="noopener">Contact support</a>
      </div>
    </div>
  </div>
</section>

<?php include __DIR__ . '/popup.php'; ?>
<?php include __DIR__ . '/footer.php'; ?>
