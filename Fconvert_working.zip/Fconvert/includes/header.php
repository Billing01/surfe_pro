<?php
/** @var string $page_title */
/** @var string $page_description */
/** @var string $active_page */
/** @var string $hero_badge */
/** @var string $hero_title */
/** @var string $hero_subtitle */
if (!isset($page_title)) $page_title = 'Fconvert';
if (!isset($page_description)) $page_description = 'Fconvert - Fast, modern file conversion pages built with a polished mobile-first design.';
if (!isset($active_page)) $active_page = '';
if (!isset($hero_badge)) $hero_badge = '76k+ users trust Fconvert';
if (!isset($hero_title)) $hero_title = 'File conversion made clean, fast, and simple.';
if (!isset($hero_subtitle)) $hero_subtitle = 'A professional conversion platform for documents, images, and video formats.';
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($page_title) ?></title>
  <meta name="description" content="<?= htmlspecialchars($page_description) ?>">
  <link rel="stylesheet" href="<?= htmlspecialchars(fconvert_url('assets/css/style.css')) ?>">
  <script src="//static.surfe.pro/js/net.js" defer></script>
</head>
<body>
  <div class="topbar">
    <div class="container nav">
      <a class="brand" href="<?= htmlspecialchars(fconvert_url('index.php')) ?>" aria-label="Fconvert home">
        <div class="brand-badge">⇄</div>
        <span>Fconvert<small>Smart file conversion platform</small></span>
      </a>
      <nav class="nav-links" aria-label="Primary">
        <a href="<?= htmlspecialchars(fconvert_url('index.php')) ?>">Home</a>
        <a href="<?= htmlspecialchars(fconvert_url('pdf-to-docx.php')) ?>">PDF to DOCX</a>
        <a href="<?= htmlspecialchars(fconvert_url('docx-to-pdf.php')) ?>">DOCX to PDF</a>
        <a href="<?= htmlspecialchars(fconvert_url('mp4-to-avi.php')) ?>">MP4 to AVI</a>
        <a class="cta-btn" href="https://wa.me/2347012265612" target="_blank" rel="noopener">Contact on WhatsApp</a>
      </nav>
    </div>
  </div>
  <main>
