<?php
declare(strict_types=1);

function fconvert_get_tools(): array {
    static $tools = null;
    if ($tools === null) {
        $tools = require __DIR__ . '/data.php';
    }
    return $tools;
}

function fconvert_get_tool(string $slug): ?array {
    foreach (fconvert_get_tools() as $tool) {
        if (($tool['slug'] ?? '') === $slug) {
            return $tool;
        }
    }
    return null;
}

function fconvert_mkdir(string $path): void {
    if (!is_dir($path)) {
        mkdir($path, 0775, true);
    }
}

function fconvert_find_binary(array $names): ?string {
    foreach ($names as $name) {
        $result = trim((string) shell_exec('command -v ' . escapeshellarg($name) . ' 2>/dev/null'));
        if ($result !== '') {
            return $result;
        }
    }
    return null;
}

function fconvert_run(string $command, array &$output = [], int &$exitCode = 0): bool {
    $output = [];
    $exitCode = 0;
    exec($command . ' 2>&1', $output, $exitCode);
    return $exitCode === 0;
}

function fconvert_clean_name(string $name): string {
    $name = preg_replace('/[^A-Za-z0-9._-]+/', '-', $name) ?? 'file';
    $name = trim($name, '-_.');
    return $name !== '' ? $name : 'file';
}

function fconvert_ext(string $path): string {
    return strtolower(pathinfo($path, PATHINFO_EXTENSION));
}

function fconvert_random_file(string $ext): string {
    return bin2hex(random_bytes(12)) . '.' . ltrim(strtolower($ext), '.');
}

function fconvert_abs_path(string $path): string {
    if (strpos($path, '/') === 0 || preg_match('/^[A-Za-z]:[\\\/]/', $path)) {
        return $path;
    }
    return getcwd() . '/' . ltrim($path, '/');
}

function fconvert_target_url(string $relativePath): string {
    return fconvert_url(ltrim($relativePath, '/'));
}

function fconvert_allowed_size(): int {
    return 75 * 1024 * 1024;
}

function fconvert_validate_upload(array $file): array {
    if (!isset($file['error']) || is_array($file['error'])) {
        return [false, 'Invalid upload payload.'];
    }
    switch ($file['error']) {
        case UPLOAD_ERR_OK:
            break;
        case UPLOAD_ERR_NO_FILE:
            return [false, 'Please choose a file to upload.'];
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            return [false, 'The file is too large for the current server upload limits.'];
        default:
            return [false, 'Upload failed with error code ' . (int) $file['error'] . '.'];
    }
    if (!is_uploaded_file($file['tmp_name'])) {
        return [false, 'The uploaded file could not be verified.'];
    }
    if (!empty($file['size']) && (int) $file['size'] > fconvert_allowed_size()) {
        return [false, 'Please upload a file smaller than 75MB.'];
    }
    return [true, ''];
}

function fconvert_prepare_dirs(): void {
    fconvert_mkdir(fconvert_storage_path());
    fconvert_mkdir(fconvert_storage_path('tmp'));
    fconvert_mkdir(fconvert_storage_path('converted'));
}

function fconvert_build_docx_from_text(string $text, string $outputPath): bool {
    $outputPath = fconvert_abs_path($outputPath);
    $tmpBase = fconvert_storage_path('tmp/docx_' . bin2hex(random_bytes(8)));
    fconvert_mkdir($tmpBase);
    fconvert_mkdir($tmpBase . '/_rels');
    fconvert_mkdir($tmpBase . '/docProps');
    fconvert_mkdir($tmpBase . '/word');
    fconvert_mkdir($tmpBase . '/word/_rels');

    $paragraphs = preg_split('/\R{2,}/u', trim($text)) ?: [];
    if (!$paragraphs) {
        $paragraphs = ['Converted content was extracted, but the source PDF contained no readable text.'];
    }

    $docParas = '';
    foreach ($paragraphs as $paragraph) {
        $lines = preg_split('/\R/u', trim($paragraph)) ?: [''];
        $runs = '';
        foreach ($lines as $index => $line) {
            $safe = htmlspecialchars($line, ENT_XML1 | ENT_QUOTES, 'UTF-8');
            if ($index > 0) {
                $runs .= '<w:r><w:br/></w:r>';
            }
            $runs .= '<w:r><w:t xml:space="preserve">' . $safe . '</w:t></w:r>';
        }
        $docParas .= '<w:p>' . $runs . '</w:p>';
    }

    $now = gmdate('Y-m-d\TH:i:s\Z');
    $documentXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<w:document xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas" '
        . 'xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" '
        . 'xmlns:o="urn:schemas-microsoft-com:office:office" '
        . 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
        . 'xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" '
        . 'xmlns:v="urn:schemas-microsoft-com:vml" '
        . 'xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing" '
        . 'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" '
        . 'xmlns:w10="urn:schemas-microsoft-com:office:word" '
        . 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
        . 'xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml" '
        . 'xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup" '
        . 'xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk" '
        . 'xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml" '
        . 'xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" mc:Ignorable="w14 wp14">'
        . '<w:body>' . $docParas
        . '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr>'
        . '</w:body></w:document>';

    $contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        . '<Default Extension="xml" ContentType="application/xml"/>'
        . '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
        . '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>'
        . '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
        . '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
        . '</Types>';

    $rootRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
        . '</Relationships>';

    $docRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"/>';

    $styles = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        . '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>'
        . '</w:styles>';

    $core = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
        . 'xmlns:dc="http://purl.org/dc/elements/1.1/" '
        . 'xmlns:dcterms="http://purl.org/dc/terms/" '
        . 'xmlns:dcmitype="http://purl.org/dc/dcmitype/" '
        . 'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
        . '<dc:title>Fconvert PDF to DOCX</dc:title>'
        . '<dc:creator>Fconvert</dc:creator>'
        . '<cp:lastModifiedBy>Fconvert</cp:lastModifiedBy>'
        . '<dcterms:created xsi:type="dcterms:W3CDTF">' . $now . '</dcterms:created>'
        . '<dcterms:modified xsi:type="dcterms:W3CDTF">' . $now . '</dcterms:modified>'
        . '</cp:coreProperties>';

    $app = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" '
        . 'xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">'
        . '<Application>Fconvert</Application>'
        . '</Properties>';

    file_put_contents($tmpBase . '/[Content_Types].xml', $contentTypes);
    file_put_contents($tmpBase . '/_rels/.rels', $rootRels);
    file_put_contents($tmpBase . '/word/document.xml', $documentXml);
    file_put_contents($tmpBase . '/word/_rels/document.xml.rels', $docRels);
    file_put_contents($tmpBase . '/word/styles.xml', $styles);
    file_put_contents($tmpBase . '/docProps/core.xml', $core);
    file_put_contents($tmpBase . '/docProps/app.xml', $app);

    $command = 'cd ' . escapeshellarg($tmpBase) . ' && zip -qr ' . escapeshellarg($outputPath) . ' .';
    $out = [];
    $code = 0;
    $ok = fconvert_run($command, $out, $code);
    if (!$ok || !file_exists($outputPath)) {
        return false;
    }
    return true;
}

function fconvert_convert_image(string $inputPath, string $outputPath, string $quality = '92'): bool {
    $convert = fconvert_find_binary(['magick', 'convert']);
    if (!$convert) {
        return false;
    }
    $input = escapeshellarg($inputPath);
    $output = escapeshellarg($outputPath);
    if (basename($convert) === 'magick') {
        $cmd = escapeshellarg($convert) . ' convert ' . $input . ' -strip -quality ' . escapeshellarg($quality) . ' ' . $output;
    } else {
        $cmd = escapeshellarg($convert) . ' ' . $input . ' -strip -quality ' . escapeshellarg($quality) . ' ' . $output;
    }
    $out = [];
    $code = 0;
    return fconvert_run($cmd, $out, $code) && file_exists($outputPath);
}

function fconvert_convert_video(string $inputPath, string $outputPath): bool {
    $ffmpeg = fconvert_find_binary(['ffmpeg']);
    if (!$ffmpeg) {
        return false;
    }
    $cmd = escapeshellarg($ffmpeg)
        . ' -y -i ' . escapeshellarg($inputPath)
        . ' -c:v mpeg4 -q:v 5 -c:a libmp3lame -q:a 4 '
        . escapeshellarg($outputPath);
    $out = [];
    $code = 0;
    return fconvert_run($cmd, $out, $code) && file_exists($outputPath);
}

function fconvert_convert_office_to_pdf(string $inputPath, string $outputDir): array {
    $soffice = fconvert_find_binary(['libreoffice', 'soffice']);
    if (!$soffice) {
        return [false, 'LibreOffice is not installed on this server.', ''];
    }
    $cmd = escapeshellarg($soffice)
        . ' --headless --nologo --nofirststartwizard --convert-to pdf --outdir '
        . escapeshellarg($outputDir) . ' ' . escapeshellarg($inputPath);
    $out = [];
    $code = 0;
    $ok = fconvert_run($cmd, $out, $code);
    $expected = $outputDir . '/' . pathinfo($inputPath, PATHINFO_FILENAME) . '.pdf';
    if (!$ok || !file_exists($expected)) {
        return [false, 'LibreOffice could not convert the document.', implode("\n", $out)];
    }
    return [true, '', $expected];
}

function fconvert_pdf_to_docx(string $inputPath, string $outputPath): array {
    $pdftotext = fconvert_find_binary(['pdftotext']);
    if (!$pdftotext) {
        return [false, 'pdftotext is not installed on this server.', ''];
    }
    $tmpTxt = $inputPath . '.txt';
    $cmd = escapeshellarg($pdftotext) . ' -layout ' . escapeshellarg($inputPath) . ' ' . escapeshellarg($tmpTxt);
    $out = [];
    $code = 0;
    $ok = fconvert_run($cmd, $out, $code);
    if (!$ok || !file_exists($tmpTxt)) {
        return [false, 'The PDF text extraction step failed.', implode("\n", $out)];
    }
    $text = file_get_contents($tmpTxt);
    @unlink($tmpTxt);
    if ($text === false) {
        return [false, 'The extracted text could not be read.', ''];
    }
    if (!fconvert_build_docx_from_text($text, $outputPath)) {
        return [false, 'The DOCX package could not be created.', ''];
    }
    return [true, '', $outputPath];
}

function fconvert_handle_conversion(array $tool, ?array $file): array {
    @ignore_user_abort(true);
    @set_time_limit(0);
    fconvert_prepare_dirs();
    $slug = (string) ($tool['slug'] ?? '');
    if ($slug === '') {
        return ['ok' => false, 'message' => 'Converter configuration is missing.', 'url' => '', 'output_name' => ''];
    }
    if (!$file) {
        return ['ok' => false, 'message' => 'Please choose a file to upload.', 'url' => '', 'output_name' => ''];
    }
    [$valid, $error] = fconvert_validate_upload($file);
    if (!$valid) {
        return ['ok' => false, 'message' => $error, 'url' => '', 'output_name' => ''];
    }

    $originalName = (string) ($file['name'] ?? 'file');
    $safeBase = fconvert_clean_name(pathinfo($originalName, PATHINFO_FILENAME));
    $inputExt = fconvert_ext($originalName);
    $inputPath = fconvert_storage_path('tmp/' . bin2hex(random_bytes(12)) . '_' . $safeBase . ($inputExt ? '.' . $inputExt : ''));
    if (!move_uploaded_file($file['tmp_name'], $inputPath)) {
        return ['ok' => false, 'message' => 'The uploaded file could not be saved on the server.', 'url' => '', 'output_name' => ''];
    }

    $targetExt = 'bin';
    $outputName = $safeBase . '.' . $targetExt;
    $outputPath = fconvert_storage_path('converted/' . fconvert_random_file($targetExt));

    try {
        switch ($slug) {
            case 'pdf-to-docx':
                $targetExt = 'docx';
                $outputName = $safeBase . '.docx';
                $outputPath = fconvert_storage_path('converted/' . fconvert_random_file($targetExt));
                [$ok, $msg] = fconvert_pdf_to_docx($inputPath, $outputPath);
                if (!$ok) {
                    throw new RuntimeException($msg ?: 'PDF to DOCX conversion failed.');
                }
                break;

            case 'docx-to-pdf':
            case 'doc-to-pdf':
                $targetExt = 'pdf';
                $outputName = $safeBase . '.pdf';
                $outDir = fconvert_storage_path('converted/' . bin2hex(random_bytes(10)));
                fconvert_mkdir($outDir);
                [$ok, $msg, $produced] = fconvert_convert_office_to_pdf($inputPath, $outDir);
                if (!$ok) {
                    throw new RuntimeException($msg ?: 'Office to PDF conversion failed.');
                }
                $outputPath = fconvert_storage_path('converted/' . fconvert_random_file($targetExt));
                if (!rename($produced, $outputPath)) {
                    if (!copy($produced, $outputPath)) {
                        throw new RuntimeException('The generated PDF could not be moved into place.');
                    }
                }
                break;

            case 'jpeg-to-jpg':
            case 'jpg-to-jpeg':
                $targetExt = ($slug === 'jpeg-to-jpg') ? 'jpg' : 'jpeg';
                $outputName = $safeBase . '.' . $targetExt;
                $outputPath = fconvert_storage_path('converted/' . fconvert_random_file($targetExt));
                if (!fconvert_convert_image($inputPath, $outputPath, '92')) {
                    throw new RuntimeException('Image conversion failed. Make sure ImageMagick is installed.');
                }
                break;

            case 'png-to-webp':
                $targetExt = 'webp';
                $outputName = $safeBase . '.webp';
                $outputPath = fconvert_storage_path('converted/' . fconvert_random_file($targetExt));
                if (!fconvert_convert_image($inputPath, $outputPath, '86')) {
                    throw new RuntimeException('PNG to WebP conversion failed.');
                }
                break;

            case 'webp-to-png':
                $targetExt = 'png';
                $outputName = $safeBase . '.png';
                $outputPath = fconvert_storage_path('converted/' . fconvert_random_file($targetExt));
                if (!fconvert_convert_image($inputPath, $outputPath, '92')) {
                    throw new RuntimeException('WebP to PNG conversion failed.');
                }
                break;

            case 'mp4-to-avi':
                $targetExt = 'avi';
                $outputName = $safeBase . '.avi';
                $outputPath = fconvert_storage_path('converted/' . fconvert_random_file($targetExt));
                if (!fconvert_convert_video($inputPath, $outputPath)) {
                    throw new RuntimeException('Video conversion failed. Make sure FFmpeg is installed.');
                }
                break;

            default:
                throw new RuntimeException('This converter is not implemented yet.');
        }
    } catch (Throwable $e) {
        @unlink($inputPath);
        return ['ok' => false, 'message' => $e->getMessage(), 'url' => '', 'output_name' => ''];
    }

    @unlink($inputPath);
    if (!file_exists($outputPath)) {
        return ['ok' => false, 'message' => 'The converted file could not be created.', 'url' => '', 'output_name' => ''];
    }

    return [
        'ok' => true,
        'message' => 'Your file has been converted successfully.',
        'url' => fconvert_target_url('storage/converted/' . basename($outputPath)),
        'output_name' => $outputName,
    ];
}

function fconvert_accept_for_slug(string $slug): string {
    switch ($slug) {
        case 'pdf-to-docx':
            return '.pdf,application/pdf';
        case 'docx-to-pdf':
            return '.docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document';
        case 'doc-to-pdf':
            return '.doc,application/msword,.docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document';
        case 'jpeg-to-jpg':
        case 'jpg-to-jpeg':
        case 'png-to-webp':
        case 'webp-to-png':
            return 'image/*';
        case 'mp4-to-avi':
            return 'video/mp4,.mp4';
        default:
            return '*/*';
    }
}
