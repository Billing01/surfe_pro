<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/converter-engine.php';
$slug = 'docx-to-pdf';
include __DIR__ . '/includes/converter-page.php';
