<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/converter-engine.php';
$slug = 'pdf-to-docx';
include __DIR__ . '/includes/converter-page.php';
