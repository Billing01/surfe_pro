<?php
require_once __DIR__ . '/includes/functions.php';
$pages = rhod_pages();
$pageTitle = 'RHOD — Professional File Converter Platform';
$pageDescription = 'RHOD helps users convert documents, images, and video files with a modern and welcoming interface.';
require __DIR__ . '/includes/header.php';
?>
<main>
    <section class="hero">
        <div>
            <span class="badge">Fast, clean, and professional file conversion</span>
            <h1>Convert your files the smart way with RHOD.</h1>
            <p>RHOD is built for people who need practical file conversions without a messy interface. Whether you are editing a PDF, standardizing image extensions, preparing a document for sharing, or switching video containers for compatibility, this platform brings those tasks together in one welcoming place.</p>
            <p>Modern work happens across phones, laptops, office suites, and content tools that all prefer different formats. That is why file converters matter. A document may need to become a PDF before it can be shared. A PDF may need to become a DOCX before it can be edited. A PNG may need to become a JPG for a lighter upload. A video may need to be converted so it can play in a specific editor. RHOD gives those everyday needs a polished home.</p>
            <div class="hero-actions">
                <a class="btn primary" href="#converters">Explore converters</a>
                <a class="btn secondary" href="#why-rhod">Why converters matter</a>
            </div>
            <div class="kpi">
                <span>Trusted workflow</span>
                <span>Mobile friendly</span>
                <span>Document, image &amp; video tools</span>
            </div>
        </div>
        <div class="hero-side">
            <div class="stat-grid">
                <div class="stat">
                    <strong>76k+</strong>
                    <span>users benefiting from simple conversion flows</span>
                </div>
                <div class="stat">
                    <strong>8+</strong>
                    <span>converter pages available and growing</span>
                </div>
                <div class="stat">
                    <strong>3</strong>
                    <span>content pillars: documents, images, video</span>
                </div>
                <div class="stat">
                    <strong>24/7</strong>
                    <span>always accessible from any browser</span>
                </div>
            </div>
            <div class="callout">
                <strong>Built for everyday work</strong>
                <div class="note">Use RHOD when you need a dependable place to clean up file formats, keep work organized, and move faster with less friction.</div>
            </div>
        </div>
    </section>

    <section class="panel section" id="why-rhod">
        <h2>Why format converters matter</h2>
        <div class="grid cols-3" style="margin-top:16px">
            <div class="feature-card">
                <h3>Compatibility</h3>
                <p>Different apps prefer different formats. A good converter helps files open correctly in the tool, device, or platform your audience actually uses.</p>
            </div>
            <div class="feature-card">
                <h3>Editability</h3>
                <p>Sometimes a file is perfectly readable but hard to edit. Converters make it easier to return to a working format, make changes, and continue your task.</p>
            </div>
            <div class="feature-card">
                <h3>Professional delivery</h3>
                <p>PDFs, standardized images, and compatible video containers help documents, visuals, and media look more polished when shared or archived.</p>
            </div>
        </div>
    </section>

    <section class="panel section">
        <h2>How RHOD helps</h2>
        <div class="grid cols-2" style="margin-top:16px">
            <div class="content-card">
                <h3>Simple upload flow</h3>
                <p>Select a file, choose the converter page that matches your task, and start the process from a clean page that explains what the format is used for and why it matters.</p>
            </div>
            <div class="content-card">
                <h3>Practical conversion support</h3>
                <p>RHOD focuses on the file types people ask for most often: documents, image extensions, web-friendly graphics, and video container changes that are useful in the real world.</p>
            </div>
            <div class="content-card">
                <h3>Welcoming content</h3>
                <p>Each page includes helpful explanations, tips, and use cases so users understand the value of the converter instead of being dropped into a cold upload box.</p>
            </div>
            <div class="content-card">
                <h3>Responsive layout</h3>
                <p>The design is built to feel polished on mobile and desktop, with cards, spacing, and typography that make the platform easy to read and pleasant to use.</p>
            </div>
        </div>
    </section>

    <section class="panel section" id="converters">
        <h2>Converter pages</h2>
        <p class="note">Every page below is designed as a standalone conversion landing page with its own explanation, upload form, and polished presentation.</p>
        <div class="converter-list" style="margin-top:16px">
            <?php foreach ($pages as $slug => $meta): ?>
                <article class="converter-card">
                    <div class="pair"><?= rhod_e($meta['from']) ?> → <?= rhod_e($meta['to']) ?></div>
                    <h3><?= rhod_e($meta['title']) ?></h3>
                    <p><?= rhod_e($meta['summary']) ?></p>
                    <a class="link" href="<?= rhod_e(rhod_url($meta['file'])) ?>">Open converter page →</a>
                </article>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="panel section">
        <h2>What makes RHOD different</h2>
        <div class="grid cols-3" style="margin-top:16px">
            <div class="mini-card">
                <h3>Clear purpose</h3>
                <p>Each page explains why the conversion exists and who benefits most from it, so the site feels intentional and easy to understand.</p>
            </div>
            <div class="mini-card">
                <h3>Helpful guidance</h3>
                <p>Users see tips about quality, compatibility, and best practices before they start converting files.</p>
            </div>
            <div class="mini-card">
                <h3>Consistent branding</h3>
                <p>RHOD keeps the same visual identity across every page, which creates trust and makes the platform feel complete.</p>
            </div>
        </div>
    </section>

    <section class="panel section">
        <h2>Who it is for</h2>
        <div class="grid cols-2" style="margin-top:16px">
            <div class="content-card">
                <h3>Students and teachers</h3>
                <p>Useful for turning study notes, handouts, and submissions into the right format for editing or sharing.</p>
            </div>
            <div class="content-card">
                <h3>Businesses and offices</h3>
                <p>Ideal for converting proposals, invoices, reports, and presentations into polished formats that are easier to distribute.</p>
            </div>
            <div class="content-card">
                <h3>Creators and designers</h3>
                <p>Great for image extension changes and compatibility adjustments when moving between tools and platforms.</p>
            </div>
            <div class="content-card">
                <h3>Everyday users</h3>
                <p>Perfect for anyone who simply wants files to open, look, and behave properly without frustration.</p>
            </div>
        </div>
    </section>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
