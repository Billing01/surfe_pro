<?php
require_once __DIR__ . '/functions.php';
$pages = rhod_nav_pages();
$page = $pages[$slug] ?? null;
if (!$page) {
    http_response_code(404);
    echo 'Converter not found.';
    exit;
}
$pageTitle = 'RHOD — ' . $page['title'];
$pageDescription = $page['summary'];
$result = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $result = rhod_convert($page, $_FILES['source_file'] ?? []);
}
$current = $slug;
require __DIR__ . '/header.php';
?>
<main>
    <section class="hero" style="grid-template-columns:1.05fr .95fr">
        <div>
            <span class="users-pill">76k+ users already trust RHOD for fast conversions</span>
            <span class="badge"><?= rhod_e($page['badge']) ?></span>
            <h1><?= rhod_e($page['title']) ?></h1>
            <p><?= rhod_e($page['hero']) ?></p>
            <p><?= rhod_e($page['summary']) ?></p>
            <div class="hero-actions">
                <a class="btn primary" href="#converter-form"><?= rhod_e($page['cta']) ?></a>
                <a class="btn secondary" href="<?= rhod_e(rhod_url('index.php')) ?>">Back to home</a>
            </div>
            <div class="kpi">
                <?php foreach ($page['supported'] as $label): ?>
                    <span><?= rhod_e($label) ?></span>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="hero-side">
            <div class="stat-grid">
                <div class="stat"><strong><?= rhod_e($page['from']) ?></strong><span>source format</span></div>
                <div class="stat"><strong><?= rhod_e($page['to']) ?></strong><span>target format</span></div>
                <div class="stat"><strong>Clean</strong><span>professional interface</span></div>
                <div class="stat"><strong>Fast</strong><span>simple conversion flow</span></div>
            </div>
            <div class="callout">
                <strong>Why this conversion matters</strong>
                <div class="note"><?= rhod_e($page['processing']) ?></div>
            </div>
        </div>
    </section>

    <section class="panel section" id="converter-form">
        <div class="form-wrap">
            <div class="form-box content-card">
                <h2 style="margin-top:0">Upload your <?= rhod_e(strtolower($page['from'])) ?> file</h2>
                <p class="note">Choose a file and RHOD will convert it into the target format. The interface is kept simple so users can focus on the task instead of the page layout.</p>

                <?php if ($result): ?>
                    <div class="alert <?= !empty($result['ok']) ? 'success' : 'error' ?>">
                        <?= rhod_e($result['message']) ?>
                        <?php if (!empty($result['ok']) && !empty($result['download_url'])): ?>
                            <div style="margin-top:12px">
                                <a class="btn primary" href="<?= rhod_e($result['download_url']) ?>">Download converted file</a>
                            </div>
                            <div class="note" style="margin-top:10px">
                                Output file: <?= rhod_e($result['download_name'] ?? '') ?><?php if (!empty($result['size'])): ?> · Size: <?= rhod_e(rhod_format_bytes((int)$result['size'])) ?><?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <form method="post" enctype="multipart/form-data">
                    <input type="file" name="source_file" required>
                    <button class="btn primary" type="submit"><?= rhod_e($page['cta']) ?></button>
                </form>
                <p class="note">Accepted formats: <?= rhod_e(implode(', ', $page['supported'])) ?>. For best results, upload a clean original file.</p>
            </div>

            <div class="grid" style="gap:16px">
                <div class="content-card">
                    <h3>Why people use this converter</h3>
                    <ul class="list">
                        <?php foreach ($page['reasons'] as $item): ?>
                            <li><?= rhod_e($item) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="content-card">
                    <h3>Common use cases</h3>
                    <ul class="list">
                        <?php foreach ($page['use_cases'] as $item): ?>
                            <li><?= rhod_e($item) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <section class="panel section">
        <h2>Helpful guidance</h2>
        <div class="grid cols-3" style="margin-top:16px">
            <?php foreach ($page['tips'] as $tip): ?>
                <div class="mini-card">
                    <h3>Tip</h3>
                    <p><?= rhod_e($tip) ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="panel section">
        <div class="content-card">
            <h3>Why users choose RHOD</h3>
            <p><?= rhod_e($page['long_intro'][0]) ?></p>
            <p><?= rhod_e($page['long_intro'][1]) ?></p>
            <p><?= rhod_e($page['long_intro'][2]) ?></p>
        </div>
    </section>

    <section class="ad-stack section">
        <script src="//static.surfe.pro/js/net.js"></script>

        <ins class="surfe-be" data-sid="421283"></ins>
        <ins class="surfe-be" data-sid="421284"></ins>

        <script>
        (adsurfebe = window.adsurfebe || []).push({});
        (adsurfebe = window.adsurfebe || []).push({});
        </script>
    </section>

    <section class="panel section">
        <h2>Frequently asked questions</h2>
        <div class="grid cols-2" style="margin-top:16px">
            <?php foreach ($page['faq'] as $faq): ?>
                <div class="content-card">
                    <h3>Question</h3>
                    <p><?= rhod_e($faq) ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
</main>
<?php require __DIR__ . '/footer.php'; ?>
