<?php
require_once __DIR__ . '/functions.php';
$pages = rhod_nav_pages();
$current = $current ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= rhod_e($pageTitle ?? 'RHOD File Converter') ?></title>
    <meta name="description" content="<?= rhod_e($pageDescription ?? 'RHOD is a clean PHP file conversion platform for documents, images, and video.') ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= rhod_e(rhod_url('assets/css/style.css')) ?>">
</head>
<body>
<div class="site-shell">
    <header class="topbar">
        <a class="brand" href="<?= rhod_e(rhod_url('index.php')) ?>">
            <span class="brand-mark">R</span>
            <span>
                <strong>RHOD</strong>
                <small>Professional file conversion platform</small>
            </span>
        </a>
        <nav class="nav">
            <a href="<?= rhod_e(rhod_url('index.php')) ?>">Home</a>
            <?php foreach ($pages as $slug => $meta): ?>
                <a class="<?= $current === $slug ? 'active' : '' ?>" href="<?= rhod_e(rhod_url($meta['file'])) ?>"><?= rhod_e($meta['title']) ?></a>
            <?php endforeach; ?>
        </nav>
    </header>
