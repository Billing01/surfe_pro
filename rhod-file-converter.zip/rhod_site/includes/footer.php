    <footer class="footer">
        <div>
            <strong>RHOD</strong>
            <p>Reliable conversion tools for documents, images, and video.</p>
        </div>
        <div>
            <span>Contact on WhatsApp</span>
            <a href="https://wa.me/2347012265612" target="_blank" rel="noopener noreferrer">+2347012265612</a>
        </div>
    </footer>
</div>
</body>
</html>
