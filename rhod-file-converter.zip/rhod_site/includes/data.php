<?php
function rhod_pages(): array {
    return [
        'pdf-to-docx' => [
            'slug' => 'pdf-to-docx',
            'file' => 'pdf-to-docx.php',
            'title' => 'PDF to DOCX Converter',
            'hero' => 'Turn static PDFs into editable Word documents with a clean workflow built for study, business, and office tasks.',
            'badge' => 'Document Recovery Made Simple',
            'cta' => 'Convert PDF to DOCX',
            'from' => 'PDF',
            'to' => 'DOCX',
            'summary' => 'Upload a PDF and get a DOCX file back in a few steps. RHOD is designed to help users work faster when they need to edit contracts, notes, reports, or scanned documents that started life as PDF files.',
            'long_intro' => [
                'PDF files are excellent for sharing and preserving layout, but they are not always ideal when you need to edit text, restructure a page, or pull out content for reuse. That is where PDF to DOCX conversion becomes valuable.',
                'RHOD makes that process feel friendly and organized. You can upload a file, start the conversion, and receive an editable document that is easier to revise, annotate, and repurpose for presentations, reports, classwork, or client work.',
                'This page also explains how the workflow works, what kind of files convert best, and why many professionals keep PDF to Word conversion close at hand every day.'
            ],
            'reasons' => [
                'Edit content instead of typing it again from scratch.',
                'Reuse paragraphs, tables, and reference material in a Word document.',
                'Save time when working with business documents, school notes, and archived reports.'
            ],
            'use_cases' => [
                'Updating proposals and contracts',
                'Reworking lecture notes and handouts',
                'Turning archived PDFs into editable drafts'
            ],
            'tips' => [
                'Clear PDFs with selectable text usually convert better than image-only scans.',
                'Complex layouts may need a quick cleanup after conversion.',
                'For best results, upload the original PDF instead of a compressed copy.'
            ],
            'faq' => [
                'Can scanned PDFs convert perfectly? Image-only PDFs may need extra cleanup after conversion.',
                'Will the DOCX stay editable? Yes, the output is designed for editing in Word-compatible apps.',
                'Is the process secure? Files are handled on the server and can be removed after use.'
            ],
            'supported' => ['PDF', 'DOCX'],
            'processing' => 'This converter uses text extraction plus document generation so users can regain editable text from PDF content.',
        ],
        'docx-to-pdf' => [
            'slug' => 'docx-to-pdf',
            'file' => 'docx-to-pdf.php',
            'title' => 'DOCX to PDF Converter',
            'hero' => 'Lock in your document layout and share polished PDFs that look the same on every device.',
            'badge' => 'Share-Ready Publishing',
            'cta' => 'Convert DOCX to PDF',
            'from' => 'DOCX',
            'to' => 'PDF',
            'summary' => 'RHOD helps transform Word documents into stable PDFs for sharing, printing, archiving, and sending professional documents without worrying about formatting drift.',
            'long_intro' => [
                'When a document must look consistent across phones, laptops, printers, and email attachments, PDF is the safest format. DOCX to PDF conversion helps preserve page structure, spacing, images, headers, and visual style.',
                'This is useful for resumes, letters, invoices, certificates, reports, and submissions that should not change when opened on another device.',
                'RHOD keeps the process simple for users who want a neat conversion page with clear messaging, a professional presentation, and a straightforward upload flow.'
            ],
            'reasons' => [
                'Keeps formatting consistent after sharing.',
                'Makes documents easier to print or archive.',
                'Creates a professional final version for delivery.'
            ],
            'use_cases' => [
                'Submitting assignments',
                'Sending resumes and cover letters',
                'Archiving business reports'
            ],
            'tips' => [
                'Check page breaks before converting if the document has complex spacing.',
                'Embed fonts where possible for the most accurate appearance.',
                'Use PDF when the file must be read-only.'
            ],
            'faq' => [
                'Does PDF preserve layout? Yes, that is the main advantage of this conversion.',
                'Can it be printed easily? PDFs are usually the best format for printing.',
                'Will hyperlinks stay visible? They often do when the document is well-formed.'
            ],
            'supported' => ['DOCX', 'PDF'],
            'processing' => 'This converter uses a document export workflow so Word content becomes a reliable PDF copy.',
        ],
        'doc-to-pdf' => [
            'slug' => 'doc-to-pdf',
            'file' => 'doc-to-pdf.php',
            'title' => 'DOC to PDF Converter',
            'hero' => 'Bring older Word documents into a modern, dependable PDF format without losing professionalism.',
            'badge' => 'Legacy Word Support',
            'cta' => 'Convert DOC to PDF',
            'from' => 'DOC',
            'to' => 'PDF',
            'summary' => 'Older .doc files still show up in offices, schools, and personal archives. RHOD gives those files a clean route into PDF so they can be shared more easily and kept in a stable, readable format.',
            'long_intro' => [
                'DOC is still common in older storage folders and legacy office systems, but PDF is often the better choice when you want consistency and broad compatibility.',
                'This converter page is written to feel welcoming and practical, giving users a polished place to upload an old Word file and create a tidy PDF copy.',
                'Using PDF also helps reduce layout surprises when recipients open the file on different devices or platforms.'
            ],
            'reasons' => [
                'Turns old Word files into shareable PDFs.',
                'Reduces formatting issues on different devices.',
                'Creates a more polished final file for distribution.'
            ],
            'use_cases' => [
                'Legacy office documents',
                'Archive records',
                'School and admin files'
            ],
            'tips' => [
                'Older DOC files with unusual fonts may need a quick layout check.',
                'Use PDF for safer sharing and printing.',
                'Keep a copy of the original DOC file for future edits.'
            ],
            'faq' => [
                'Why convert DOC to PDF? Because PDF is more universal for viewing and sharing.',
                'Will the file stay readable? That is the main goal of the conversion.',
                'Can this help with old files? Yes, especially for archived documents.'
            ],
            'supported' => ['DOC', 'PDF'],
            'processing' => 'This converter uses a document export path suited for older Word formats that still need modern delivery.',
        ],
        'jpeg-to-jpg' => [
            'slug' => 'jpeg-to-jpg',
            'file' => 'jpeg-to-jpg.php',
            'title' => 'JPEG to JPG Converter',
            'hero' => 'Rename and re-save images cleanly when a project, uploader, or CMS expects the JPG extension.',
            'badge' => 'Image Extension Switch',
            'cta' => 'Convert JPEG to JPG',
            'from' => 'JPEG',
            'to' => 'JPG',
            'summary' => 'JPEG and JPG are the same image family, but many workflows still prefer one extension over the other. RHOD gives users a polished way to standardize image names for websites, galleries, and uploads.',
            'long_intro' => [
                'Some systems display or filter files by extension, and that can make JPEG vs JPG annoying even though the image data itself is the same style of format.',
                'RHOD treats this as a practical housekeeping task: keep the image, normalize the extension, and present a smooth converter page that feels fast and clear.',
                'That matters for designers, marketers, bloggers, and everyday users who want their media library to look consistent.'
            ],
            'reasons' => [
                'Matches strict upload requirements.',
                'Standardizes file naming across a folder.',
                'Avoids extension-based validation problems.'
            ],
            'use_cases' => [
                'Website uploads',
                'Asset library cleanup',
                'Email and shared drive organization'
            ],
            'tips' => [
                'JPEG and JPG contain the same style of compression.',
                'Use JPG when a system insists on three-letter extensions.',
                'Keep the original file if you need to rename it again later.'
            ],
            'faq' => [
                'Is any quality lost? Not when the file is simply re-saved carefully.',
                'Why do both names exist? They are historical extension variants of the same format.',
                'Do image dimensions change? They should stay the same unless resized on purpose.'
            ],
            'supported' => ['JPEG', 'JPG'],
            'processing' => 'This converter re-saves the image with the requested extension while keeping the content intact.',
        ],
        'jpg-to-jpeg' => [
            'slug' => 'jpg-to-jpeg',
            'file' => 'jpg-to-jpeg.php',
            'title' => 'JPG to JPEG Converter',
            'hero' => 'Standardize image files for design systems, uploads, and folders that prefer the longer JPEG extension.',
            'badge' => 'Image Extension Switch',
            'cta' => 'Convert JPG to JPEG',
            'from' => 'JPG',
            'to' => 'JPEG',
            'summary' => 'JPG and JPEG are interchangeable in practice, but some workflows are configured around one naming style. RHOD makes it easy to convert your file naming convention without the friction.',
            'long_intro' => [
                'The JPG to JPEG page is ideal when a content manager, website rule, or media library expects a specific file naming style.',
                'Because the underlying image format is the same family, users mainly need a clean and reliable way to standardize the extension and keep everything organized.',
                'RHOD presents that task in a beautiful layout with clear instructions and a fast, simple upload experience.'
            ],
            'reasons' => [
                'Keeps naming consistent in large folders.',
                'Helps meet extension-specific upload rules.',
                'Makes project assets easier to manage.'
            ],
            'use_cases' => [
                'Design handoffs',
                'Media libraries',
                'Content management systems'
            ],
            'tips' => [
                'The actual image content remains the same class of format.',
                'Use the extension that your target system prefers.',
                'Maintain backups of source assets before bulk changes.'
            ],
            'faq' => [
                'Is JPG different from JPEG? Not in a meaningful modern workflow sense.',
                'Why rename it? Some platforms validate the extension strictly.',
                'Can this help with organization? Yes, especially in shared folders.'
            ],
            'supported' => ['JPG', 'JPEG'],
            'processing' => 'This converter re-saves the file with the alternative JPEG extension in a clean, consistent way.',
        ],
        'png-to-jpg' => [
            'slug' => 'png-to-jpg',
            'file' => 'png-to-jpg.php',
            'title' => 'PNG to JPG Converter',
            'hero' => 'Reduce image weight and simplify sharing when a project does not need transparency.',
            'badge' => 'Web-Friendly Images',
            'cta' => 'Convert PNG to JPG',
            'from' => 'PNG',
            'to' => 'JPG',
            'summary' => 'PNG files are great for transparency and crisp graphics, but JPG is often easier for web pages, email attachments, and lighter delivery. RHOD helps users switch formats with a polished interface.',
            'long_intro' => [
                'PNG to JPG is useful when you want to lower file size or use a format that is widely supported in publishing workflows.',
                'For photos and many social graphics, JPG is often the more convenient choice because it usually balances quality and size very well.',
                'RHOD explains the difference clearly so users understand when PNG is better and when JPG is the smarter target format.'
            ],
            'reasons' => [
                'Can reduce file size for faster sharing.',
                'Works well for photos and general web images.',
                'Avoids the need for transparency when it is not required.'
            ],
            'use_cases' => [
                'Blog images',
                'Email attachments',
                'Photo galleries'
            ],
            'tips' => [
                'PNG transparency is flattened during conversion.',
                'Use PNG again if you need a transparent background later.',
                'For logos with transparency, consider keeping a PNG master copy.'
            ],
            'faq' => [
                'Is JPG always smaller? Often, but not always.',
                'Will transparency remain? No, JPG does not support transparency.',
                'Is it good for photos? Yes, JPG is widely used for photos and web images.'
            ],
            'supported' => ['PNG', 'JPG'],
            'processing' => 'This converter flattens the image onto a white background before saving it as JPG.',
        ],
        'webp-to-png' => [
            'slug' => 'webp-to-png',
            'file' => 'webp-to-png.php',
            'title' => 'WebP to PNG Converter',
            'hero' => 'Turn modern WebP files into reliable PNG images when a system, editor, or workflow needs broader compatibility.',
            'badge' => 'Compatibility First',
            'cta' => 'Convert WebP to PNG',
            'from' => 'WebP',
            'to' => 'PNG',
            'summary' => 'WebP is efficient and modern, but not every tool handles it smoothly. RHOD gives users an easy way to switch to PNG for workflows that value compatibility, editing, and transparency.',
            'long_intro' => [
                'WebP is increasingly common on websites, but some desktop apps, upload systems, and older devices still prefer PNG.',
                'This page helps users bridge that gap by offering a simple, professional conversion experience with a clean upload section and clear guidance.',
                'PNG is often a safe destination when you need lossless handling or broad editor support.'
            ],
            'reasons' => [
                'Improves compatibility with older software.',
                'Keeps image quality high for editing.',
                'Supports transparency when needed.'
            ],
            'use_cases' => [
                'Graphic editing',
                'Content management uploads',
                'Cross-platform sharing'
            ],
            'tips' => [
                'Keep the original WebP if you may need the smaller web version later.',
                'PNG files can be larger than WebP.',
                'Transparency is preserved when the source image supports it.'
            ],
            'faq' => [
                'Why convert to PNG? For compatibility and editing friendliness.',
                'Does PNG support transparency? Yes, it does.',
                'Will the file get bigger? Often, yes, because PNG is lossless.'
            ],
            'supported' => ['WebP', 'PNG'],
            'processing' => 'This converter re-encodes the source WebP into a PNG image suitable for broad compatibility.',
        ],
        'mp4-to-avi' => [
            'slug' => 'mp4-to-avi',
            'file' => 'mp4-to-avi.php',
            'title' => 'MP4 to AVI Converter',
            'hero' => 'Convert video files for systems, editors, and legacy players that still prefer AVI containers.',
            'badge' => 'Video Compatibility Mode',
            'cta' => 'Convert MP4 to AVI',
            'from' => 'MP4',
            'to' => 'AVI',
            'summary' => 'MP4 is the everyday video format for modern devices, while AVI can still be useful for specific workflows and older media tools. RHOD provides a clean route between the two.',
            'long_intro' => [
                'Video conversion often exists because different devices and editors support different containers and codecs. MP4 is modern and compact, but AVI can be helpful for older software or certain editing pipelines.',
                'RHOD makes the page feel professional, explains the reason for the conversion, and keeps the upload flow clear for users who just need a dependable result.',
                'Because video files are often large, this page also encourages practical expectations and simple file management.'
            ],
            'reasons' => [
                'Helps with older editors and playback systems.',
                'Keeps the video usable in legacy workflows.',
                'Gives users a format that some tools still request.'
            ],
            'use_cases' => [
                'Video archive management',
                'Legacy player support',
                'Editing and conversion pipelines'
            ],
            'tips' => [
                'Large videos may take more time to convert.',
                'The output codec choices affect file size and compatibility.',
                'Always keep the original MP4 file for backup.'
            ],
            'faq' => [
                'Is AVI older than MP4? Yes, AVI is the older-style container in common use.',
                'Can the conversion take time? Yes, video conversions are heavier than image conversions.',
                'Should I keep the source file? Absolutely, especially for large media.'
            ],
            'supported' => ['MP4', 'AVI'],
            'processing' => 'This converter uses a video transcode workflow to place MP4 content into an AVI container.',
        ],
    ];
}

function rhod_nav_pages(): array {
    return rhod_pages();
}
