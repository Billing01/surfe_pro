<?php
require_once __DIR__ . '/data.php';

function rhod_base_url(): string {
    $script = $_SERVER['SCRIPT_NAME'] ?? '';
    return rtrim(str_replace('\\', '/', dirname($script)), '/');
}

function rhod_url(string $file): string {
    $base = rhod_base_url();
    return ($base === '' || $base === '.') ? $file : $base . '/' . $file;
}

function rhod_e(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function rhod_ensure_dir(string $path): void {
    if (!is_dir($path)) {
        mkdir($path, 0775, true);
    }
}

function rhod_storage_paths(): array {
    $root = dirname(__DIR__);
    $upload = $root . '/storage/uploads';
    $converted = $root . '/storage/converted';
    rhod_ensure_dir($upload);
    rhod_ensure_dir($converted);
    return [$upload, $converted];
}

function rhod_cleanup_old_files(string $dir, int $maxAgeSeconds = 86400): void {
    foreach (glob($dir . '/*') ?: [] as $file) {
        if (is_file($file) && (time() - filemtime($file)) > $maxAgeSeconds) {
            @unlink($file);
        }
    }
}

function rhod_safe_name(string $name): string {
    $name = preg_replace('/\s+/', '-', $name);
    $name = preg_replace('/[^A-Za-z0-9._-]+/', '-', $name);
    $name = trim($name, '-_.');
    return $name !== '' ? $name : 'file';
}

function rhod_format_bytes(int $bytes): string {
    $units = ['B', 'KB', 'MB', 'GB'];
    $i = 0;
    $size = (float) $bytes;
    while ($size >= 1024 && $i < count($units) - 1) {
        $size /= 1024;
        $i++;
    }
    return rtrim(rtrim(number_format($size, 2), '0'), '.') . ' ' . $units[$i];
}

function rhod_run(string $command, ?string &$output = null, ?int &$exitCode = null): bool {
    $desc = [
        1 => ['pipe', 'w'],
        2 => ['pipe', 'w'],
    ];
    $process = proc_open($command, $desc, $pipes);
    if (!is_resource($process)) {
        $exitCode = 1;
        $output = 'Unable to start process.';
        return false;
    }
    $stdout = stream_get_contents($pipes[1]);
    $stderr = stream_get_contents($pipes[2]);
    fclose($pipes[1]);
    fclose($pipes[2]);
    $exitCode = proc_close($process);
    $output = trim($stdout . "\n" . $stderr);
    return $exitCode === 0;
}

function rhod_detect_extension(string $filename): string {
    return strtolower(pathinfo($filename, PATHINFO_EXTENSION));
}

function rhod_copy_uploaded_file(array $file, string $dir, string $prefix): array {
    if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'message' => 'Please choose a file before starting the conversion.'];
    }
    if (!is_uploaded_file($file['tmp_name'])) {
        return ['ok' => false, 'message' => 'The uploaded file could not be verified.'];
    }

    $original = rhod_safe_name(pathinfo($file['name'], PATHINFO_FILENAME));
    $ext = rhod_detect_extension($file['name']);
    $token = $prefix . '-' . bin2hex(random_bytes(6)) . '-' . $original;
    $target = rtrim($dir, '/') . '/' . $token . ($ext ? '.' . $ext : '');

    if (!move_uploaded_file($file['tmp_name'], $target)) {
        return ['ok' => false, 'message' => 'The file could not be saved on the server.'];
    }

    return ['ok' => true, 'path' => $target, 'ext' => $ext, 'original' => $original, 'token' => $token];
}

function rhod_result_file(string $path, string $downloadName): string {
    $safe = rawurlencode(basename($path));
    $query = rawurlencode($downloadName);
    return rhod_url('download.php') . '?file=' . $safe . '&name=' . $query;
}

function rhod_convert(array $page, array $file): array {
    [$uploadDir, $convertedDir] = rhod_storage_paths();
    rhod_cleanup_old_files($uploadDir, 86400);
    rhod_cleanup_old_files($convertedDir, 86400);

    $copy = rhod_copy_uploaded_file($file, $uploadDir, $page['slug']);
    if (!$copy['ok']) {
        return $copy;
    }

    $input = $copy['path'];
    $base = $copy['token'];
    $target = '';
    $message = '';
    $downloadName = '';
    $slug = $page['slug'];

    try {
        switch ($slug) {
            case 'jpeg-to-jpg':
            case 'jpg-to-jpeg':
                if (!function_exists('imagecreatefromjpeg')) {
                    return ['ok' => false, 'message' => 'The PHP GD extension is required for image conversions.'];
                }
                $img = @imagecreatefromjpeg($input);
                if (!$img) {
                    return ['ok' => false, 'message' => 'The image could not be read.'];
                }
                $targetExt = $slug === 'jpeg-to-jpg' ? 'jpg' : 'jpeg';
                $target = $convertedDir . '/' . $base . '.' . $targetExt;
                imageinterlace($img, true);
                imagejpeg($img, $target, 95);
                imagedestroy($img);
                $message = 'Image converted successfully.';
                $downloadName = $copy['original'] . '.' . $targetExt;
                break;

            case 'png-to-jpg':
                if (!function_exists('imagecreatefrompng')) {
                    return ['ok' => false, 'message' => 'The PHP GD extension is required for image conversions.'];
                }
                $src = @imagecreatefrompng($input);
                if (!$src) {
                    return ['ok' => false, 'message' => 'The PNG image could not be read.'];
                }
                $w = imagesx($src);
                $h = imagesy($src);
                $canvas = imagecreatetruecolor($w, $h);
                $white = imagecolorallocate($canvas, 255, 255, 255);
                imagefilledrectangle($canvas, 0, 0, $w, $h, $white);
                imagecopy($canvas, $src, 0, 0, 0, 0, $w, $h);
                $target = $convertedDir . '/' . $base . '.jpg';
                imagejpeg($canvas, $target, 92);
                imagedestroy($src);
                imagedestroy($canvas);
                $message = 'PNG converted to JPG successfully.';
                $downloadName = $copy['original'] . '.jpg';
                break;

            case 'webp-to-png':
                if (!function_exists('imagecreatefromwebp')) {
                    return ['ok' => false, 'message' => 'Your server does not support WebP in GD.'];
                }
                $src = @imagecreatefromwebp($input);
                if (!$src) {
                    return ['ok' => false, 'message' => 'The WebP image could not be read.'];
                }
                $target = $convertedDir . '/' . $base . '.png';
                imagepng($src, $target, 6);
                imagedestroy($src);
                $message = 'WebP converted to PNG successfully.';
                $downloadName = $copy['original'] . '.png';
                break;

            case 'docx-to-pdf':
            case 'doc-to-pdf':
                $cmd = 'libreoffice --headless --convert-to pdf --outdir ' . escapeshellarg($convertedDir) . ' ' . escapeshellarg($input);
                $out = '';
                $code = 0;
                if (!rhod_run($cmd, $out, $code)) {
                    return ['ok' => false, 'message' => 'Document conversion failed: ' . ($out ?: 'LibreOffice could not finish the job.')];
                }
                $expected = $convertedDir . '/' . pathinfo($input, PATHINFO_FILENAME) . '.pdf';
                if (!file_exists($expected)) {
                    $matches = glob($convertedDir . '/' . pathinfo($input, PATHINFO_FILENAME) . '*.pdf');
                    $expected = $matches[0] ?? '';
                }
                if (!$expected || !file_exists($expected)) {
                    return ['ok' => false, 'message' => 'PDF output was not created.'];
                }
                $target = $expected;
                $message = 'Document converted to PDF successfully.';
                $downloadName = $copy['original'] . '.pdf';
                break;

            case 'pdf-to-docx':
                $txt = $convertedDir . '/' . $base . '.txt';
                $docx = $convertedDir . '/' . $base . '.docx';
                $pdftotext = 'pdftotext ' . escapeshellarg($input) . ' ' . escapeshellarg($txt);
                $out1 = '';
                $code1 = 0;
                if (!rhod_run($pdftotext, $out1, $code1)) {
                    return ['ok' => false, 'message' => 'PDF text extraction failed: ' . ($out1 ?: 'pdftotext could not read the file.')];
                }
                $pandoc = 'pandoc ' . escapeshellarg($txt) . ' -o ' . escapeshellarg($docx);
                $out2 = '';
                $code2 = 0;
                if (!rhod_run($pandoc, $out2, $code2)) {
                    return ['ok' => false, 'message' => 'DOCX generation failed: ' . ($out2 ?: 'pandoc could not create the file.')];
                }
                @unlink($txt);
                if (!file_exists($docx)) {
                    return ['ok' => false, 'message' => 'The DOCX file was not created.'];
                }
                $target = $docx;
                $message = 'PDF converted to DOCX successfully.';
                $downloadName = $copy['original'] . '.docx';
                break;

            case 'mp4-to-avi':
                $target = $convertedDir . '/' . $base . '.avi';
                $cmd = 'ffmpeg -y -i ' . escapeshellarg($input) . ' -c:v mpeg4 -q:v 5 -c:a libmp3lame -q:a 4 ' . escapeshellarg($target);
                $out = '';
                $code = 0;
                if (!rhod_run($cmd, $out, $code)) {
                    return ['ok' => false, 'message' => 'Video conversion failed: ' . ($out ?: 'ffmpeg could not complete the conversion.')];
                }
                if (!file_exists($target)) {
                    return ['ok' => false, 'message' => 'The AVI file was not created.'];
                }
                $message = 'MP4 converted to AVI successfully.';
                $downloadName = $copy['original'] . '.avi';
                break;

            default:
                return ['ok' => false, 'message' => 'This converter is not configured yet.'];
        }
    } catch (Throwable $e) {
        return ['ok' => false, 'message' => 'Something went wrong: ' . $e->getMessage()];
    }

    return [
        'ok' => true,
        'message' => $message,
        'download_path' => $target,
        'download_url' => rhod_result_file($target, $downloadName),
        'download_name' => $downloadName,
        'input_name' => $copy['original'] . '.' . $copy['ext'],
        'size' => file_exists($target) ? filesize($target) : 0,
    ];
}
