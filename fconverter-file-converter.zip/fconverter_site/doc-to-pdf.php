<?php
$slug = 'doc-to-pdf';
require __DIR__ . '/includes/converter-template.php';
