<?php
$base = __DIR__;
$file = $_GET['file'] ?? '';
$name = $_GET['name'] ?? 'download.bin';
$path = $base . '/storage/converted/' . basename($file);

if (!is_file($path)) {
    http_response_code(404);
    echo 'File not found.';
    exit;
}

header('Content-Type: application/octet-stream');
header('Content-Length: ' . filesize($path));
header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9._-]+/', '_', $name) . '"');
readfile($path);
exit;
