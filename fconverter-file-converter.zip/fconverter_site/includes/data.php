<?php
function fconverter_pages(): array {
    return [
        'pdf-to-docx' => [
            'slug' => 'pdf-to-docx',
            'file' => 'pdf-to-docx.php',
            'title' => 'PDF to DOCX Converter',
            'hero' => 'Turn locked PDFs into editable Word documents for work, study, and client edits.',
            'badge' => 'Document Recovery',
            'cta' => 'Convert PDF to DOCX',
            'from' => 'PDF',
            'to' => 'DOCX',
            'summary' => 'Convert PDF files into editable DOCX documents so text, headings, and content can be updated instead of retyped.',
            'long_intro' => [
                'PDF files are excellent for sharing because they preserve layout across devices, but they are not ideal when the goal is editing. A report, memo, or handout can become a lot more useful once it is converted into a Word document that can be changed freely.',
                'Fconverter gives that workflow a polished home. The page is built to feel calm, clear, and trustworthy, so users can upload a file, start the process, and continue their work with a result that is easier to refine, annotate, and reuse.',
                'This converter is especially valuable for students, office teams, and business users who receive files in PDF form but need to make changes quickly without rebuilding the document from scratch.'
            ],
            'reasons' => [
                'Edit text instead of typing everything again.',
                'Reuse tables, notes, and references in Word.',
                'Speed up document cleanup and revision.'
            ],
            'use_cases' => [
                'Reports and business briefs',
                'Assignment notes and handouts',
                'Archived documents that need updates'
            ],
            'tips' => [
                'Selectable-text PDFs usually convert more cleanly than scanned images.',
                'Keep the original PDF for reference and backups.',
                'Large or complex layouts may need light formatting cleanup after conversion.'
            ],
            'faq' => [
                'Why convert PDF to DOCX? Because DOCX gives you a flexible editing workflow.',
                'Can scanned PDFs work? They may convert, but image-based files often need extra cleanup.',
                'Is the converted file editable? Yes, that is the main purpose of this converter.'
            ],
            'supported' => [
                'PDF',
                'DOCX'
            ],
            'processing' => 'This converter extracts text from the PDF and generates a DOCX file that is easier to edit and share.'
        ],
        'docx-to-pdf' => [
            'slug' => 'docx-to-pdf',
            'file' => 'docx-to-pdf.php',
            'title' => 'DOCX to PDF Converter',
            'hero' => 'Lock in a polished layout and share a PDF that looks the same on every device.',
            'badge' => 'Share-Ready Output',
            'cta' => 'Convert DOCX to PDF',
            'from' => 'DOCX',
            'to' => 'PDF',
            'summary' => 'Convert Word documents into stable PDFs for sharing, printing, archiving, and professional delivery.',
            'long_intro' => [
                'DOCX files are great for editing, but the formatting can shift when they are opened on different systems. PDF solves that problem by preserving the appearance of the document so the message stays exactly where it should be.',
                'Fconverter presents that process in a modern interface that feels premium on desktop and mobile. Users can upload a document, run the conversion, and get a result that is ready for sending, printing, or safe storage.',
                'This page is ideal for resumes, contracts, invoices, letters, reports, and any document that should look consistent no matter who opens it.'
            ],
            'reasons' => [
                'Preserve spacing and layout.',
                'Create a professional final copy.',
                'Make the file easier to print or archive.'
            ],
            'use_cases' => [
                'Resumes and cover letters',
                'Certificates and official letters',
                'Invoices and reports'
            ],
            'tips' => [
                'Check page breaks before converting if the document is complex.',
                'Embed fonts where possible for the best result.',
                'Use PDF when the document should be read-only.'
            ],
            'faq' => [
                'Does PDF help with consistency? Yes, that is the core reason people use it.',
                'Will the file print well? Usually yes, because PDF is ideal for print-ready output.',
                'Should I keep the DOCX copy? Yes, keep it for future editing.'
            ],
            'supported' => [
                'DOCX',
                'PDF'
            ],
            'processing' => 'This converter uses a document export workflow to turn the Word document into a dependable PDF copy.'
        ],
        'doc-to-pdf' => [
            'slug' => 'doc-to-pdf',
            'file' => 'doc-to-pdf.php',
            'title' => 'DOC to PDF Converter',
            'hero' => 'Bring older Word files into a modern, shareable PDF format without hassle.',
            'badge' => 'Legacy Document Support',
            'cta' => 'Convert DOC to PDF',
            'from' => 'DOC',
            'to' => 'PDF',
            'summary' => 'Convert older DOC files into PDF so legacy Word documents become easier to share, archive, and print.',
            'long_intro' => [
                'Older DOC files still show up in schools, offices, and archives. They may open in modern software, but converting them to PDF is often the easiest way to keep them neat and consistent for delivery.',
                'Fconverter gives this format a clean landing page with helpful explanation and a focused upload flow. The purpose is simple: preserve the content, stabilize the layout, and make the final file easy to use.',
                'This tool is especially handy when an older file must be shared with people using different devices or office suites.'
            ],
            'reasons' => [
                'Preserve old documents in a modern format.',
                'Make sharing and printing easier.',
                'Reduce compatibility issues across devices.'
            ],
            'use_cases' => [
                'Legacy office archives',
                'School documents and notices',
                'Historical records and handouts'
            ],
            'tips' => [
                'Always review page breaks in old DOC files.',
                'Use the original file rather than a compressed copy.',
                'Keep a backup before converting older material.'
            ],
            'faq' => [
                'Why convert DOC to PDF? To make the file safer and more universal for sharing.',
                'Will the layout stay the same? That is the goal, especially with simple documents.',
                'Is this useful for old files? Yes, it is one of the best use cases.'
            ],
            'supported' => [
                'DOC',
                'PDF'
            ],
            'processing' => 'This converter sends the document through an export path suited to older Word files that still need modern delivery.'
        ],
        'jpeg-to-jpg' => [
            'slug' => 'jpeg-to-jpg',
            'file' => 'jpeg-to-jpg.php',
            'title' => 'JPEG to JPG Converter',
            'hero' => 'Normalize image extensions cleanly when your workflow prefers JPG over JPEG.',
            'badge' => 'Image Extension Switch',
            'cta' => 'Convert JPEG to JPG',
            'from' => 'JPEG',
            'to' => 'JPG',
            'summary' => 'JPEG and JPG are the same family of image format, but some platforms still care about the extension. Fconverter helps standardize it.',
            'long_intro' => [
                'Many systems do not care whether a file ends in JPG or JPEG, but some upload rules, naming conventions, and content tools are strict about the extension they expect. That can create unnecessary friction.',
                'Fconverter treats this as a practical cleanup task. The image remains the image, while the extension is reshaped to fit the platform, folder, or workflow that needs it.',
                'This converter is useful for bloggers, designers, marketers, and everyday users who want their image library to look consistent and professional.'
            ],
            'reasons' => [
                'Matches platform-specific upload rules.',
                'Keeps folders and asset names consistent.',
                'Avoids extension-based validation problems.'
            ],
            'use_cases' => [
                'Website uploads',
                'Media library cleanup',
                'Folder organization'
            ],
            'tips' => [
                'JPEG and JPG are interchangeable in practice.',
                'Keep a backup copy if you manage many assets.',
                'Use the extension your target system prefers.'
            ],
            'faq' => [
                'Is JPEG different from JPG? Not in a meaningful modern workflow sense.',
                'Does this change the picture quality? It should not, when handled properly.',
                'Why rename it at all? Because some systems check the extension strictly.'
            ],
            'supported' => [
                'JPEG',
                'JPG'
            ],
            'processing' => 'This converter re-saves the image using the alternate extension while keeping the image content intact.'
        ],
        'jpg-to-jpeg' => [
            'slug' => 'jpg-to-jpeg',
            'file' => 'jpg-to-jpeg.php',
            'title' => 'JPG to JPEG Converter',
            'hero' => 'Convert JPG files to the longer JPEG extension for naming consistency and platform rules.',
            'badge' => 'Naming Consistency',
            'cta' => 'Convert JPG to JPEG',
            'from' => 'JPG',
            'to' => 'JPEG',
            'summary' => 'Switch JPG files to JPEG when a system, folder rule, or project standard prefers the longer extension.',
            'long_intro' => [
                'JPG and JPEG mean the same thing in modern usage, but teams sometimes still standardize one version over the other. That can matter in asset libraries, upload systems, and organized project folders.',
                'Fconverter offers a visually polished page for that small but common task. The job is simple, but the presentation feels professional, making the whole site feel reliable and easy to navigate.',
                'This tool is ideal when consistency matters more than the actual image data, especially in larger collections of media files.'
            ],
            'reasons' => [
                'Keeps project naming conventions unified.',
                'Helps satisfy extension-specific upload rules.',
                'Makes large image folders easier to manage.'
            ],
            'use_cases' => [
                'Design handoffs',
                'Shared media folders',
                'CMS upload preparation'
            ],
            'tips' => [
                'The image content stays in the JPEG family.',
                'Choose the extension required by your destination system.',
                'Store original assets separately for future edits.'
            ],
            'faq' => [
                'Are JPG and JPEG the same? Yes, for everyday use they are effectively the same format.',
                'Why standardize the extension? Because some workflows are strict about file naming.',
                'Can this help organization? Yes, especially in large shared libraries.'
            ],
            'supported' => [
                'JPG',
                'JPEG'
            ],
            'processing' => 'This converter re-saves the file with the requested JPEG extension in a consistent way.'
        ],
        'png-to-jpg' => [
            'slug' => 'png-to-jpg',
            'file' => 'png-to-jpg.php',
            'title' => 'PNG to JPG Converter',
            'hero' => 'Reduce image weight when transparency is not needed and JPG is the better fit.',
            'badge' => 'Web-Friendly Images',
            'cta' => 'Convert PNG to JPG',
            'from' => 'PNG',
            'to' => 'JPG',
            'summary' => 'Convert PNG images into JPG files for lighter sharing, faster loading, and general-purpose publishing.',
            'long_intro' => [
                'PNG is perfect for transparency and sharp graphics, but JPG is often better for photos and everyday publishing because it usually keeps file sizes more manageable.',
                'Fconverter gives users a clean way to make that switch without confusion. The page explains why the conversion is useful and keeps the process visually calm and simple.',
                'It is especially useful for web content, email attachments, and image galleries where a lightweight file is more practical than a transparent one.'
            ],
            'reasons' => [
                'Often reduces file size for faster sharing.',
                'Works well for photos and general web content.',
                'Removes transparency when it is no longer needed.'
            ],
            'use_cases' => [
                'Blog images',
                'Email attachments',
                'Photo galleries'
            ],
            'tips' => [
                'Transparency is flattened during conversion.',
                'Keep a PNG master if you may need transparency later.',
                'Use JPG when the goal is size and simplicity.'
            ],
            'faq' => [
                'Will transparency stay? No, JPG does not support transparency.',
                'Is JPG smaller? Often yes, especially for photos.',
                'Is it good for web use? Yes, that is one of the most common reasons.'
            ],
            'supported' => [
                'PNG',
                'JPG'
            ],
            'processing' => 'This converter flattens the image onto a background and saves it as JPG for broader use.'
        ],
        'jpg-to-png' => [
            'slug' => 'jpg-to-png',
            'file' => 'jpg-to-png.php',
            'title' => 'JPG to PNG Converter',
            'hero' => 'Upgrade JPG images into PNG when you need a lossless, design-friendly output.',
            'badge' => 'Lossless Image Output',
            'cta' => 'Convert JPG to PNG',
            'from' => 'JPG',
            'to' => 'PNG',
            'summary' => 'Convert JPG files to PNG when a workflow prefers a transparent-friendly, lossless style of image output.',
            'long_intro' => [
                'Some workflows need PNG because it is a friendly format for editing, assets, and support for transparency. While the conversion does not restore lost JPEG detail, it does produce a PNG file that is easier to use in certain pipelines.',
                'Fconverter presents this page with the same polished visual language as the rest of the site, so the user experience stays consistent from one converter to the next.',
                'This converter can be helpful when a design tool, upload rule, or image pipeline expects PNG.'
            ],
            'reasons' => [
                'Matches PNG-only upload rules.',
                'Useful for design and asset workflows.',
                'Creates a more flexible image container.'
            ],
            'use_cases' => [
                'Design systems',
                'Project asset preparation',
                'Website or app uploads'
            ],
            'tips' => [
                'Converting JPG to PNG does not improve lost JPEG detail.',
                'Use a source file with the best possible quality.',
                'Keep both versions when managing important assets.'
            ],
            'faq' => [
                'Does PNG improve quality? It preserves what is there, but it cannot recover JPEG compression loss.',
                'Why use PNG then? Because some workflows need the format, not necessarily a quality boost.',
                'Can it help with editing? Yes, PNG is common in editing pipelines.'
            ],
            'supported' => [
                'JPG',
                'PNG'
            ],
            'processing' => 'This converter reads the JPG and re-encodes it as PNG for compatibility with PNG-based workflows.'
        ],
        'webp-to-png' => [
            'slug' => 'webp-to-png',
            'file' => 'webp-to-png.php',
            'title' => 'WebP to PNG Converter',
            'hero' => 'Move modern WebP images into broad-compatibility PNG files when a tool needs it.',
            'badge' => 'Compatibility First',
            'cta' => 'Convert WebP to PNG',
            'from' => 'WebP',
            'to' => 'PNG',
            'summary' => 'Convert WebP into PNG for better support in older tools, editors, and upload systems.',
            'long_intro' => [
                'WebP is efficient and modern, but not every desktop editor, upload form, or legacy system handles it cleanly. PNG remains one of the safest fallback formats because it is broadly supported.',
                'Fconverter makes that handoff feel polished. The user sees why the conversion matters, what the output format is good for, and how it fits into a practical workflow.',
                'This is a strong choice when you want compatibility, editing convenience, and predictable handling across different devices.'
            ],
            'reasons' => [
                'Improves compatibility with older software.',
                'Keeps a clean format for editing and sharing.',
                'Can preserve transparency when supported.'
            ],
            'use_cases' => [
                'Graphic editing',
                'Content management uploads',
                'Cross-platform sharing'
            ],
            'tips' => [
                'PNG files are often larger than WebP.',
                'Keep the original WebP file for web use.',
                'Transparency is preserved if the source supports it.'
            ],
            'faq' => [
                'Why convert to PNG? Because it is easier for many tools to open and edit.',
                'Does PNG support transparency? Yes, it does.',
                'Will the file become bigger? Often, yes, because PNG is lossless.'
            ],
            'supported' => [
                'WebP',
                'PNG'
            ],
            'processing' => 'This converter re-encodes the source WebP into a PNG image that works well across common tools.'
        ],
        'png-to-webp' => [
            'slug' => 'png-to-webp',
            'file' => 'png-to-webp.php',
            'title' => 'PNG to WebP Converter',
            'hero' => 'Turn PNG graphics into efficient WebP files for better web performance.',
            'badge' => 'Modern Web Delivery',
            'cta' => 'Convert PNG to WebP',
            'from' => 'PNG',
            'to' => 'WebP',
            'summary' => 'Convert PNG images into WebP to reduce size while keeping a modern web-friendly output.',
            'long_intro' => [
                'When a site needs faster loading and a modern image pipeline, WebP is often the better delivery format. PNG is still great for editing, but WebP can be a smart finishing format for web publishing.',
                'Fconverter adds this as a practical extra tool so the platform feels fuller and more genuinely useful, not limited to only a few conversions.',
                'This converter is useful for web teams, creators, and anyone who wants leaner images for browser delivery.'
            ],
            'reasons' => [
                'Helps reduce file size for websites.',
                'Good for modern browser-based delivery.',
                'Useful after design work is complete.'
            ],
            'use_cases' => [
                'Website optimization',
                'Blog and CMS publishing',
                'Modern web asset delivery'
            ],
            'tips' => [
                'Keep PNG masters for editing.',
                'WebP is ideal when the destination supports it.',
                'Transparent PNGs can remain transparent when converted properly.'
            ],
            'faq' => [
                'Why use WebP? It is often smaller for the same visible quality.',
                'Will it work in browsers? Most modern browsers support it well.',
                'Should I keep PNG too? Yes, especially for future edits.'
            ],
            'supported' => [
                'PNG',
                'WebP'
            ],
            'processing' => 'This converter re-encodes PNG into WebP for efficient browser delivery and smaller file sizes.'
        ],
        'webp-to-jpg' => [
            'slug' => 'webp-to-jpg',
            'file' => 'webp-to-jpg.php',
            'title' => 'WebP to JPG Converter',
            'hero' => 'Convert WebP files to JPG when a photo needs the most universally accepted output.',
            'badge' => 'Universal Compatibility',
            'cta' => 'Convert WebP to JPG',
            'from' => 'WebP',
            'to' => 'JPG',
            'summary' => 'Convert WebP images into JPG for maximum compatibility across devices, editors, and upload forms.',
            'long_intro' => [
                'WebP works well online, but JPG remains one of the most universally accepted image formats across tools, devices, and platforms. That makes it a sensible destination when compatibility matters most.',
                'Fconverter keeps the page clean and reassuring, so the user immediately understands the reason for the conversion and the practical result they will get.',
                'This is particularly useful for photos, content libraries, and uploads that must work everywhere without special handling.'
            ],
            'reasons' => [
                'Works on almost every platform.',
                'Useful for photo-oriented content.',
                'A safe fallback for older tools.'
            ],
            'use_cases' => [
                'General image sharing',
                'Email and attachment workflows',
                'Legacy software compatibility'
            ],
            'tips' => [
                'JPG does not support transparency.',
                'Keep original WebP copies if needed for the web.',
                'Use JPG when broad acceptance matters more than transparency.'
            ],
            'faq' => [
                'Why choose JPG? It is the easiest format to open almost everywhere.',
                'Does JPG support transparency? No, transparent areas are flattened.',
                'Can I use it for photos? Yes, that is one of its strongest uses.'
            ],
            'supported' => [
                'WebP',
                'JPG'
            ],
            'processing' => 'This converter re-saves the WebP as JPG so the file opens smoothly in more places.'
        ],
        'mp4-to-avi' => [
            'slug' => 'mp4-to-avi',
            'file' => 'mp4-to-avi.php',
            'title' => 'MP4 to AVI Converter',
            'hero' => 'Move video into AVI when a legacy editor or older player still expects that container.',
            'badge' => 'Video Compatibility',
            'cta' => 'Convert MP4 to AVI',
            'from' => 'MP4',
            'to' => 'AVI',
            'summary' => 'Convert MP4 video files into AVI for older software, archive work, and compatibility-driven workflows.',
            'long_intro' => [
                'Video conversion is often about compatibility. MP4 is modern and efficient, but some older software and specialized workflows still prefer AVI. That is when a conversion tool becomes genuinely useful.',
                'Fconverter presents the task in a clear and premium layout so the user can understand the reason for the conversion before starting it. The page feels organized, not technical or cluttered.',
                'This tool is best for users working with legacy media tools, older systems, or archive tasks that require AVI output.'
            ],
            'reasons' => [
                'Helps with older editors and playback systems.',
                'Keeps legacy video workflows running.',
                'Provides an output format some tools still request.'
            ],
            'use_cases' => [
                'Archive management',
                'Legacy player support',
                'Editing pipelines that prefer AVI'
            ],
            'tips' => [
                'Video conversions take longer than images.',
                'Keep the original MP4 as a backup.',
                'Codec choices affect output size and playback behavior.'
            ],
            'faq' => [
                'Is AVI older than MP4? Yes, AVI is the older-style container.',
                'Can video conversion take time? Yes, especially with longer files.',
                'Should I keep the source file? Absolutely, always keep a backup.'
            ],
            'supported' => [
                'MP4',
                'AVI'
            ],
            'processing' => 'This converter transcodes the MP4 into an AVI container for compatibility-driven workflows.'
        ]
    ];
}

function fconverter_nav_pages(): array {
    return fconverter_pages();
}
