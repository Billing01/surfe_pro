<?php
require_once __DIR__ . '/functions.php';
fconverter_handle_query_state();
$pages = fconverter_nav_pages();
$current = $current ?? '';
$currentFile = $currentFile ?? fconverter_current_page();
$showLeadPopup = !fconverter_seen();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
    <meta name="theme-color" content="#0b1220">
    <title><?= fconverter_e($pageTitle ?? 'Fconverter — Smart File Conversion') ?></title>
    <meta name="description" content="<?= fconverter_e($pageDescription ?? 'Fconverter is a modern PHP platform for converting documents, images, and video formats.') ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= fconverter_e(fconverter_url('assets/css/style.css')) ?>">
</head>
<body>
<div class="site-shell">
    <header class="topbar">
        <a class="brand" href="<?= fconverter_e(fconverter_url('index.php')) ?>">
            <span class="brand-mark">FC</span>
            <span>
                <strong>Fconverter</strong>
                <small>Clean file conversion for modern workflows</small>
            </span>
        </a>

        <button class="menu-toggle" type="button" aria-label="Open menu" data-menu-toggle>☰</button>

        <nav class="nav" data-mobile-nav>
            <a class="<?= $current === '' ? 'active' : '' ?>" href="<?= fconverter_e(fconverter_url('index.php')) ?>">Home</a>
            <?php foreach ($pages as $slug => $meta): ?>
                <a class="<?= $current === $slug ? 'active' : '' ?>" href="<?= fconverter_e(fconverter_url($meta['file'])) ?>"><?= fconverter_e($meta['title']) ?></a>
            <?php endforeach; ?>
        </nav>
    </header>
