<?php
require_once __DIR__ . '/functions.php';
$pages = fconverter_nav_pages();
$page = $pages[$slug] ?? null;
if (!$page) {
    http_response_code(404);
    echo 'Converter not found.';
    exit;
}
$current = $slug;
$currentFile = $page['file'];
$pageTitle = 'Fconverter — ' . $page['title'];
$pageDescription = $page['summary'];
$result = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $result = fconverter_convert($page, $_FILES['source_file'] ?? []);
}
require __DIR__ . '/header.php';
?>
<main>
    <section class="hero hero-converter">
        <div>
            <span class="users-pill">76k+ users trust Fconverter</span>
            <span class="badge"><?= fconverter_e($page['badge']) ?></span>
            <h1><?= fconverter_e($page['hero']) ?></h1>
            <p><?= fconverter_e($page['summary']) ?></p>
            <div class="hero-actions">
                <a class="btn primary" href="#convert-form"><?= fconverter_e($page['cta']) ?></a>
                <a class="btn secondary" href="#why-use">Why this format matters</a>
            </div>
        </div>
        <aside class="hero-side">
            <div class="stat-grid">
                <div class="stat">
                    <strong><?= fconverter_e($page['from']) ?></strong>
                    <span>Source format</span>
                </div>
                <div class="stat">
                    <strong><?= fconverter_e($page['to']) ?></strong>
                    <span>Target format</span>
                </div>
                <div class="stat">
                    <strong>Mobile</strong>
                    <span>Optimized layout</span>
                </div>
                <div class="stat">
                    <strong>Fast</strong>
                    <span>Simple workflow</span>
                </div>
            </div>
            <div class="callout">
                <strong>Built for real work</strong>
                <div class="note"><?= fconverter_e($page['processing']) ?></div>
            </div>
        </aside>
    </section>

    <section class="panel section" id="convert-form">
        <div class="form-wrap">
            <div class="form-box">
                <h2>Upload your file</h2>
                <p class="note">Choose a file, run the converter, and download the result from the same clean page.</p>

                <?php if ($result): ?>
                    <div class="alert <?= !empty($result['ok']) ? 'success' : 'error' ?>">
                        <?= fconverter_e($result['message']) ?>
                        <?php if (!empty($result['ok']) && !empty($result['download_url'])): ?>
                            <div style="margin-top:12px">
                                <a class="btn primary" href="<?= fconverter_e($result['download_url']) ?>">Download converted file</a>
                            </div>
                            <div class="note" style="margin-top:10px">
                                Output file: <?= fconverter_e($result['download_name'] ?? '') ?><?php if (!empty($result['size'])): ?> · Size: <?= fconverter_e(fconverter_format_bytes((int)$result['size'])) ?><?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <form method="post" enctype="multipart/form-data">
                    <input type="file" name="source_file" required>
                    <button class="btn primary" type="submit"><?= fconverter_e($page['cta']) ?></button>
                </form>
                <p class="note">Accepted formats: <?= fconverter_e(implode(', ', $page['supported'])) ?>.</p>
            </div>

            <div class="grid info-grid">
                <div class="content-card">
                    <h3>Why people use this converter</h3>
                    <ul class="list">
                        <?php foreach ($page['reasons'] as $item): ?>
                            <li><?= fconverter_e($item) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="content-card">
                    <h3>Common use cases</h3>
                    <ul class="list">
                        <?php foreach ($page['use_cases'] as $item): ?>
                            <li><?= fconverter_e($item) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <section class="panel section" id="why-use">
        <h2>Helpful guidance</h2>
        <div class="grid cols-3">
            <?php foreach ($page['tips'] as $tip): ?>
                <div class="mini-card">
                    <h3>Tip</h3>
                    <p><?= fconverter_e($tip) ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="panel section">
        <div class="content-card">
            <h3>Why users choose Fconverter</h3>
            <?php foreach ($page['long_intro'] as $paragraph): ?>
                <p><?= fconverter_e($paragraph) ?></p>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="ad-stack section">
        <script src="//static.surfe.pro/js/net.js"></script>

        <ins class="surfe-be" data-sid="421283"></ins>
        <ins class="surfe-be" data-sid="421284"></ins>

        <script>
        (adsurfebe = window.adsurfebe || []).push({});
        (adsurfebe = window.adsurfebe || []).push({});
        </script>
    </section>

    <section class="panel section">
        <h2>Frequently asked questions</h2>
        <div class="grid cols-2">
            <?php foreach ($page['faq'] as $faq): ?>
                <div class="content-card">
                    <h3>Question</h3>
                    <p><?= fconverter_e($faq) ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
</main>
<?php require __DIR__ . '/footer.php'; ?>
