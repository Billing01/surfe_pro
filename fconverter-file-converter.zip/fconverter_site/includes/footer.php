    <footer class="footer">
        <div>
            <strong>Fconverter</strong>
            <p>Professional document, image, and video conversion tools with a polished mobile-first interface.</p>
        </div>
        <div>
            <span>WhatsApp contact</span>
            <a href="https://wa.me/2347012265612" target="_blank" rel="noopener noreferrer">+2347012265612</a>
        </div>
    </footer>
</div>

<?php if ($showLeadPopup): ?>
<div class="modal-backdrop" role="presentation">
    <section class="modal-card" role="dialog" aria-modal="true" aria-labelledby="lead-title">
        <a class="modal-close" aria-label="Dismiss popup" href="<?= fconverter_e(fconverter_url($currentFile . '?dismiss=1')) ?>">×</a>
        <div class="modal-badge">New tools alert</div>
        <h2 id="lead-title">Welcome to Fconverter</h2>
        <p>Please enter your email to receive updates when we add new tools.</p>

        <form class="lead-form" method="post" action="<?= fconverter_e(fconverter_url('subscribe.php')) ?>">
            <input type="email" name="email" placeholder="Enter your email address" required autocomplete="email">
            <input type="hidden" name="return" value="<?= fconverter_e($currentFile) ?>">
            <button class="btn primary" type="submit">Notify me</button>
        </form>

        <div class="modal-actions">
            <a class="text-link" href="<?= fconverter_e(fconverter_url($currentFile . '?dismiss=1')) ?>">No thanks</a>
        </div>
    </section>
</div>
<?php endif; ?>

<script src="<?= fconverter_e(fconverter_url('assets/js/app.js')) ?>"></script>
</body>
</html>
