<?php
$slug = 'jpg-to-png';
require __DIR__ . '/includes/converter-template.php';
