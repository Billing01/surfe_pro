<?php
$slug = 'jpg-to-jpeg';
require __DIR__ . '/includes/converter-template.php';
