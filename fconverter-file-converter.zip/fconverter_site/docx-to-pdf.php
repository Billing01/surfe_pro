<?php
$slug = 'docx-to-pdf';
require __DIR__ . '/includes/converter-template.php';
