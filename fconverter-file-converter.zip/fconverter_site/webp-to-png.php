<?php
$slug = 'webp-to-png';
require __DIR__ . '/includes/converter-template.php';
