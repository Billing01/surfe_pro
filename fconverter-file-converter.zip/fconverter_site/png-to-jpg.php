<?php
$slug = 'png-to-jpg';
require __DIR__ . '/includes/converter-template.php';
