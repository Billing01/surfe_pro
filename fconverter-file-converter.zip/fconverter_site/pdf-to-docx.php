<?php
$slug = 'pdf-to-docx';
require __DIR__ . '/includes/converter-template.php';
