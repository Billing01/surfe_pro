<?php
require_once __DIR__ . '/includes/functions.php';
$current = '';
$currentFile = 'index.php';
$pages = fconverter_nav_pages();
$pageTitle = 'Fconverter — Professional File Conversion Platform';
$pageDescription = 'Fconverter is a modern platform for converting documents, images, and video files with a clean mobile-first experience.';
require __DIR__ . '/includes/header.php';
?>
<main>
    <section class="hero">
        <div>
            <span class="users-pill">76k+ users and growing</span>
            <span class="badge">Beautiful, fast, and organized</span>
            <h1>Convert files with confidence on Fconverter.</h1>
            <p>Fconverter brings the most useful file conversions into one polished place. Whether you need a PDF to DOCX conversion for editing, a DOCX to PDF export for sharing, an image extension change for upload rules, or a video format switch for compatibility, the platform is designed to keep the process simple, professional, and easy to understand.</p>
            <p>Different apps and devices still rely on different formats. That is why a dependable converter matters. A document may need to become a PDF so it prints correctly. A PDF may need to become a Word document so it can be edited. A PNG may need to become a JPG so it loads faster on the web. A WebP file may need to become PNG so it opens in older software. Fconverter exists to make those everyday tasks feel smooth instead of frustrating.</p>
            <div class="hero-actions">
                <a class="btn primary" href="#tools">Explore tools</a>
                <a class="btn secondary" href="#why-converters">Why converters matter</a>
            </div>
            <div class="kpi">
                <span>Mobile optimized</span>
                <span>Clear upload flow</span>
                <span>Document, image & video tools</span>
            </div>
        </div>
        <div class="hero-side">
            <div class="stat-grid">
                <div class="stat">
                    <strong>10</strong>
                    <span>converter pages and growing</span>
                </div>
                <div class="stat">
                    <strong>3</strong>
                    <span>content pillars: docs, images, video</span>
                </div>
                <div class="stat">
                    <strong>24/7</strong>
                    <span>available from any browser</span>
                </div>
                <div class="stat">
                    <strong>Clean</strong>
                    <span>modern UI/UX design</span>
                </div>
            </div>
            <div class="callout">
                <strong>Why people return</strong>
                <div class="note">The site is built to feel welcoming on first visit, useful on repeat visits, and effortless on smaller screens.</div>
            </div>
        </div>
    </section>

    <section class="panel section" id="why-converters">
        <h2>Why file converters matter</h2>
        <div class="grid cols-3">
            <div class="feature-card">
                <h3>Compatibility</h3>
                <p>Different apps and devices accept different formats. Converters help a file open properly in the environment your audience actually uses.</p>
            </div>
            <div class="feature-card">
                <h3>Editing</h3>
                <p>Sometimes the real need is to return a file to a format that can be edited, rearranged, or reused without starting over.</p>
            </div>
            <div class="feature-card">
                <h3>Professional delivery</h3>
                <p>PDFs, standardized images, and the right video container help files look more polished and behave better when shared.</p>
            </div>
        </div>
    </section>

    <section class="panel section">
        <h2>How Fconverter helps</h2>
        <div class="grid cols-2">
            <div class="content-card">
                <h3>Simple uploads</h3>
                <p>Each page keeps the upload flow clean and focused, so users do not have to fight the interface before the actual file work begins.</p>
            </div>
            <div class="content-card">
                <h3>Helpful explanations</h3>
                <p>Every converter page includes practical copy about why the format exists, when to use it, and what kind of result to expect.</p>
            </div>
            <div class="content-card">
                <h3>Responsive design</h3>
                <p>The layout is optimized for mobile first, then expanded beautifully for tablet and desktop screens with balanced spacing and readable typography.</p>
            </div>
            <div class="content-card">
                <h3>Growing toolset</h3>
                <p>The site already covers document, image, and video conversions, with room to add more tools as the platform expands.</p>
            </div>
        </div>
    </section>

    <section class="panel section" id="tools">
        <h2>Converter pages</h2>
        <p class="note">Each converter page is built as its own landing page with a clear purpose, explanation, and upload area.</p>
        <div class="converter-list">
            <?php foreach ($pages as $slug => $meta): ?>
                <article class="converter-card">
                    <div class="pair"><?= fconverter_e($meta['from']) ?> → <?= fconverter_e($meta['to']) ?></div>
                    <h3><?= fconverter_e($meta['title']) ?></h3>
                    <p><?= fconverter_e($meta['summary']) ?></p>
                    <a class="link" href="<?= fconverter_e(fconverter_url($meta['file'])) ?>">Open converter page →</a>
                </article>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="panel section">
        <h2>Who Fconverter is for</h2>
        <div class="grid cols-2">
            <div class="content-card">
                <h3>Students and teachers</h3>
                <p>Great for turning notes, assignments, and handouts into a format that is easier to edit or submit.</p>
            </div>
            <div class="content-card">
                <h3>Businesses and offices</h3>
                <p>Useful for reports, invoices, contracts, and polished documents that need stable formatting.</p>
            </div>
            <div class="content-card">
                <h3>Creators and designers</h3>
                <p>Handy for image standardization, web-ready delivery, and keeping asset libraries tidy.</p>
            </div>
            <div class="content-card">
                <h3>Everyday users</h3>
                <p>Perfect for anyone who just wants files to open, look, and behave properly without friction.</p>
            </div>
        </div>
    </section>

    <section class="panel section">
        <div class="content-card">
            <h3>Built to feel premium on mobile</h3>
            <p>The interface is arranged with large tap targets, stacked sections, rounded cards, and generous spacing so the site remains elegant and easy to use on small screens.</p>
            <p>That means less clutter, faster scanning, and a more trustworthy experience from the moment the page loads.</p>
        </div>
    </section>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
