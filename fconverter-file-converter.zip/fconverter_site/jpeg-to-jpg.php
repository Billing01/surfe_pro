<?php
$slug = 'jpeg-to-jpg';
require __DIR__ . '/includes/converter-template.php';
