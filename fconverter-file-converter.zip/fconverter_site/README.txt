Fconverter file conversion site

Upload to a PHP server with GD, LibreOffice, ffmpeg, pdftotext, and pandoc installed for the best conversion support.

Storage:
- storage/uploads
- storage/converted
- storage/leads/email-leads.txt

Popup:
- The lead popup appears the first time a visitor loads the site.
- Closing it or submitting an email sets the session/cookie flag named "msg".

Main pages:
- index.php
- converter pages listed in the navigation
