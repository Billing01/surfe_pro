<?php
require_once __DIR__ . '/includes/functions.php';

$email = $_POST['email'] ?? '';
$return = $_POST['return'] ?? 'index.php';

$result = fconverter_submit_lead($email);

if (!preg_match('/^[A-Za-z0-9._-]+\.php$/', $return)) {
    $return = 'index.php';
}

if (!$result['ok']) {
    $separator = strpos($return, '?') === false ? '?' : '&';
    header('Location: ' . fconverter_url($return . $separator . 'lead_error=1'));
    exit;
}

header('Location: ' . fconverter_url($return));
exit;
