<?php
$slug = 'png-to-webp';
require __DIR__ . '/includes/converter-template.php';
