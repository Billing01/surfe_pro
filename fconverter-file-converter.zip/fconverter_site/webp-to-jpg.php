<?php
$slug = 'webp-to-jpg';
require __DIR__ . '/includes/converter-template.php';
