<?php
require_once __DIR__ . '/../includes/functions.php';
$tool = rhod_converter_by_slug('csv-to-xlsx');
if (!$tool) {
    http_response_code(404);
    echo 'Converter not found';
    exit;
}
rhod_converter_page($tool);
