<?php
require_once __DIR__ . '/includes/functions.php';
rhod_render_header('FConvert | Modern File Conversion Platform', 'FConvert helps users convert common file formats with a clean, modern, mobile-first experience.');
?>
  <section class="hero">
    <div class="container hero-grid">
      <div>
        <div class="badge"><span class="dot"></span> 76k+ users trust FConvert</div>
        <h1 class="h1">A beautiful way to convert files without friction.</h1>
        <p class="lead">FConvert is built for people who need quick, dependable file conversion in a polished interface. From documents to images and videos, each tool is organized to feel simple, modern, and easy to use on any screen.</p>
        <div class="hero-actions">
          <a class="btn primary" href="#tools">Explore converters</a>
          <a class="btn secondary" href="#why">Why people use it</a>
        </div>
        <div class="stat-row">
          <div class="stat"><strong>40+</strong><span>planned conversion paths</span></div>
          <div class="stat"><strong>Mobile-first</strong><span>comfortable on small screens</span></div>
          <div class="stat"><strong>Fast UI</strong><span>clean, focused, lightweight</span></div>
        </div>
      </div>

      <div class="hero-card">
        <div class="tool-preview">
          <div class="preview-top">
            <div class="preview-title">Conversion workspace</div>
            <div class="badge"><span class="dot"></span> Ready on mobile</div>
          </div>
          <div class="preview-box">
            <div class="preview-file">
              <div class="icon-pill">📁</div>
              <div>
                <strong>Invoice_2026.pdf</strong>
                <small>Preparing PDF → DOCX</small>
              </div>
            </div>
            <div class="progress"><div></div></div>
            <div class="preview-grid">
              <div class="mini-card"><strong>Simple flow</strong><span class="muted">Choose file → convert → download</span></div>
              <div class="mini-card"><strong>Clear structure</strong><span class="muted">Less clutter, more usability</span></div>
            </div>
          </div>
          <div class="preview-box">
            <div class="badge"><span class="dot"></span> Built for real-world file tasks</div>
            <p class="muted" style="margin:14px 0 0;line-height:1.75">The design is intentionally calm, premium, and easy to scan. That matters when users are handling documents, images, or video files under time pressure.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="section" id="tools">
    <div class="container">
      <div class="section-title">
        <div>
          <h2>Popular converters</h2>
          <p>These pages give each conversion route its own dedicated space, making the site easier to navigate and much more trustworthy at a glance.</p>
        </div>
      </div>
      <div class="tools-grid">
        <?php foreach (rhod_converter_data() as $tool) { echo rhod_tool_card($tool); } ?>
      </div>
    </div>
  </section>

  <section class="section" id="why">
    <div class="container">
      <div class="section-title">
        <div>
          <h2>Why file converters still matter</h2>
          <p>Different apps, devices, and platforms still prefer different formats. A modern converter hub removes that friction without making the user think too hard.</p>
        </div>
      </div>

      <div class="content-grid">
        <div class="panel">
          <h3>Documents, images, and videos all behave differently</h3>
          <p>Some formats are excellent for editing, others for sharing, and others for preserving layout. A PDF is convenient for distribution, while DOCX is better for editing. JPG is universally recognized, while PNG can preserve transparency. MP4 works broadly, while AVI may still be required in older software. FConvert gathers those transitions into one elegant place.</p>
        </div>
        <div class="panel">
          <h3>Clarity matters more than clutter</h3>
          <p>Users should not have to dig through busy pages or awkward controls to complete a simple task. A good UI makes the important action obvious, reduces hesitation, and builds trust. That is why the design uses clear spacing, calm contrast, modern cards, and responsive layouts that feel natural on phones.</p>
        </div>
      </div>
    </div>
  </section>

  <section class="section">
    <div class="container">
      <div class="content-grid">
        <div class="panel">
          <h3>What FConvert is built for</h3>
          <ul>
            <li>Students converting assignments and documents.</li>
            <li>Creators preparing assets for web and social use.</li>
            <li>Office workflows that need quick file compatibility fixes.</li>
            <li>People who want a cleaner, more polished conversion site.</li>
          </ul>
        </div>
        <div class="panel">
          <h3>Design goals</h3>
          <ul>
            <li>Premium look with modern glass and gradient styling.</li>
            <li>Responsive mobile layout with comfortable touch targets.</li>
            <li>Strong hierarchy so each section is easy to understand.</li>
            <li>Simple navigation that feels familiar on any device.</li>
          </ul>
        </div>
      </div>
    </div>
  </section>

  <section class="section" id="faq">
    <div class="container">
      <div class="section-title">
        <div>
          <h2>FAQ</h2>
          <p>Answers to the questions people ask most often about conversion tools and the FConvert experience.</p>
        </div>
      </div>
      <div class="faq">
        <div class="faq-item">
          <h4>Is this designed for mobile?</h4>
          <div>Yes. The layout uses a mobile-first structure with responsive cards, large tap areas, and simplified sections for smaller screens.</div>
        </div>
        <div class="faq-item">
          <h4>Why have separate pages for each converter?</h4>
          <div>Dedicated pages make the experience clearer, improve navigation, and help each tool feel focused and easy to share.</div>
        </div>
        <div class="faq-item">
          <h4>Can more converters be added later?</h4>
          <div>Absolutely. The project structure is made so additional pages can be added cleanly without redesigning everything.</div>
        </div>
      </div>
    </div>
  </section>
<?php rhod_render_footer(); ?>
