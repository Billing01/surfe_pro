<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function rhod_site_url(string $path = ''): string {
    return $path;
}

function rhod_has_seen_popup(): bool {
    return !empty($_SESSION['msg']) || !empty($_COOKIE['msg']);
}

function rhod_mark_popup_seen(): void {
    $_SESSION['msg'] = 1;
    setcookie('msg', '1', time() + 60 * 60 * 24 * 365, '/');
}

function rhod_save_email(string $email): bool {
    $email = trim($email);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return false;
    }
    $file = __DIR__ . '/../emails.txt';
    $line = $email . PHP_EOL;
    file_put_contents($file, $line, FILE_APPEND | LOCK_EX);
    return true;
}

function rhod_handle_popup_submission(): array {
    $saved = false;
    $message = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['popup_action'])) {
        $action = $_POST['popup_action'];
        if ($action === 'subscribe') {
            $email = $_POST['popup_email'] ?? '';
            if (rhod_save_email($email)) {
                $saved = true;
                $message = 'Thanks — we will keep you updated.';
                rhod_mark_popup_seen();
            } else {
                $message = 'Please enter a valid email address.';
            }
        } elseif ($action === 'skip') {
            rhod_mark_popup_seen();
            $message = 'No problem — we will not show this again.';
        }
    }
    return [$saved, $message];
}

function rhod_converter_data(): array {
    return [
        [
            'slug' => 'pdf-to-docx',
            'title' => 'PDF to DOCX',
            'from' => 'PDF',
            'to' => 'DOCX',
            'icon' => '📄',
            'desc' => 'Convert locked-looking PDFs into editable Word documents while preserving layout as much as possible.',
        ],
        [
            'slug' => 'docx-to-pdf',
            'title' => 'DOCX to PDF',
            'from' => 'DOCX',
            'to' => 'PDF',
            'icon' => '🪄',
            'desc' => 'Turn polished documents into shareable PDF files for printing, submissions, and archives.',
        ],
        [
            'slug' => 'jpeg-to-jpg',
            'title' => 'JPEG to JPG',
            'from' => 'JPEG',
            'to' => 'JPG',
            'icon' => '🖼️',
            'desc' => 'A simple extension change for compatibility with apps and workflows that expect JPG names.',
        ],
        [
            'slug' => 'jpg-to-jpeg',
            'title' => 'JPG to JPEG',
            'from' => 'JPG',
            'to' => 'JPEG',
            'icon' => '🖼️',
            'desc' => 'Rename image files in the format many platforms and asset managers recognize.',
        ],
        [
            'slug' => 'doc-to-pdf',
            'title' => 'DOC to PDF',
            'from' => 'DOC',
            'to' => 'PDF',
            'icon' => '🧾',
            'desc' => 'Convert older Word documents into neat, portable PDFs for better sharing and printing.',
        ],
        [
            'slug' => 'mp4-to-avi',
            'title' => 'MP4 to AVI',
            'from' => 'MP4',
            'to' => 'AVI',
            'icon' => '🎬',
            'desc' => 'Export video into AVI when you need broader compatibility for legacy editors or devices.',
        ],
        [
            'slug' => 'png-to-webp',
            'title' => 'PNG to WEBP',
            'from' => 'PNG',
            'to' => 'WEBP',
            'icon' => '⚡',
            'desc' => 'Reduce image size and keep quality high for faster sites and lighter uploads.',
        ],
        [
            'slug' => 'webp-to-jpg',
            'title' => 'WEBP to JPG',
            'from' => 'WEBP',
            'to' => 'JPG',
            'icon' => '🌐',
            'desc' => 'Convert modern WebP images into the universal JPG format for easier sharing.',
        ],
        [
            'slug' => 'pdf-to-txt',
            'title' => 'PDF to TXT',
            'from' => 'PDF',
            'to' => 'TXT',
            'icon' => '📝',
            'desc' => 'Extract readable text from PDFs for research, repurposing, or content workflows.',
        ],
        [
            'slug' => 'csv-to-xlsx',
            'title' => 'CSV to XLSX',
            'from' => 'CSV',
            'to' => 'XLSX',
            'icon' => '📊',
            'desc' => 'Open structured data in Excel-friendly format with cleaner table handling.',
        ],
        [
            'slug' => 'json-to-csv',
            'title' => 'JSON to CSV',
            'from' => 'JSON',
            'to' => 'CSV',
            'icon' => '🔁',
            'desc' => 'Convert nested data into spreadsheet-ready rows for reporting and analysis.',
        ],
        [
            'slug' => 'mp4-to-gif',
            'title' => 'MP4 to GIF',
            'from' => 'MP4',
            'to' => 'GIF',
            'icon' => '🎞️',
            'desc' => 'Turn short clips into looping GIFs for social previews, emails, and chats.',
        ],
    ];
}

function rhod_converter_by_slug(string $slug): ?array {
    foreach (rhod_converter_data() as $item) {
        if ($item['slug'] === $slug) return $item;
    }
    return null;
}

function rhod_render_header(string $title, string $description = ''): void {
    [$saved, $message] = rhod_handle_popup_submission();
    $popupMessage = $message;
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
  <title><?php echo htmlspecialchars($title); ?></title>
  <meta name="description" content="<?php echo htmlspecialchars($description); ?>">
  <link rel="stylesheet" href="/assets/css/style.css">
  <script src="/assets/js/app.js" defer></script>
</head>
<body>
<header class="nav">
  <div class="container nav-inner">
    <a class="brand" href="/index.php" aria-label="FConvert home">
      <div class="brand-mark">F</div>
      <span>FConvert</span>
    </a>

    <nav class="nav-links" aria-label="Primary">
      <a href="/index.php#tools">Converters</a>
      <a href="/index.php#why">Why it matters</a>
      <a href="/index.php#faq">FAQ</a>
      <a href="/index.php#contact">Contact</a>
    </nav>

    <div class="nav-cta">
      <a class="btn secondary" href="/index.php#tools">Explore tools</a>
      <button class="menu-btn" type="button" data-menu-btn aria-label="Open menu">☰</button>
    </div>
  </div>
  <div class="container mobile-drawer" data-mobile-drawer>
    <a href="/index.php#tools">Converters</a>
    <a href="/index.php#why">Why it matters</a>
    <a href="/index.php#faq">FAQ</a>
    <a href="/index.php#contact">Contact</a>
  </div>
</header>
<main>
<?php if (!rhod_has_seen_popup()): ?>
<div class="modal-backdrop" data-welcome-modal>
  <div class="modal" role="dialog" aria-modal="true" aria-labelledby="welcome-title">
    <div class="modal-head">
      <div>
        <div class="badge" style="margin-bottom:14px;"><span class="dot"></span> New tools added often</div>
        <h2 class="modal-title" id="welcome-title">Welcome to FConvert</h2>
      </div>
      <button class="close-x" type="button" data-close-modal aria-label="Close popup">✕</button>
    </div>
    <div class="modal-body">
      <p>Enter your email to receive updates whenever we add new conversion tools, smarter workflows, and faster file utilities.</p>
      <?php if (!empty($popupMessage)): ?>
        <div class="badge" style="margin-bottom:12px;"><?php echo htmlspecialchars($popupMessage); ?></div>
      <?php endif; ?>
      <form method="post">
        <label class="sr-only" for="popup_email">Email address</label>
        <input type="email" id="popup_email" name="popup_email" placeholder="Enter your email address" required>
        <div class="modal-actions">
          <button class="btn primary" type="submit" name="popup_action" value="subscribe">Subscribe</button>
          <button class="btn secondary" type="submit" name="popup_action" value="skip">Skip for now</button>
        </div>
        <div class="note">By subscribing, you agree to receive occasional product updates. You can ignore this anytime by closing it or tapping Skip.</div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>
    <?php
}

function rhod_render_footer(): void { ?>
<footer class="footer" id="contact">
  <div class="container footer-inner">
    <div>
      <div class="brand" style="margin-bottom:10px;">
        <div class="brand-mark">F</div>
        <span>FConvert</span>
      </div>
      <div>Modern file conversion, made simple, fast, and friendly for mobile.</div>
    </div>
    <div>
      <strong>Contact</strong><br>
      WhatsApp: <a href="https://wa.me/2347012265612" target="_blank" rel="noopener noreferrer"><?php echo htmlspecialchars('+2347012265612'); ?></a>
    </div>
    <div>© <?php echo date('Y'); ?> FConvert. All rights reserved.</div>
  </div>
</footer>
</main>
</body>
</html>
<?php }function rhod_tool_card(array $item): string {
    $slug = htmlspecialchars($item['slug']);
    $title = htmlspecialchars($item['title']);
    $desc = htmlspecialchars($item['desc']);
    $from = htmlspecialchars($item['from']);
    $to = htmlspecialchars($item['to']);
    $icon = htmlspecialchars($item['icon']);
    return <<<HTML
<a class="tool-card" href="/converters/{$slug}.php">
  <div class="badge"><span class="dot"></span>{$from} → {$to}</div>
  <h3>{$icon} {$title}</h3>
  <p>{$desc}</p>
  <div class="chip-row">
    <span class="chip">Mobile friendly</span>
    <span class="chip">Fast workflow</span>
    <span class="chip">Clean output</span>
  </div>
</a>
HTML;
}

function rhod_converter_page(array $tool): void {
    $title = $tool['title'] . ' | FConvert';
    $desc = $tool['desc'];
    rhod_render_header($title, $desc);
    ?>
<main>
  <section class="converter-page">
    <div class="container">
      <div class="converter-banner">
        <div class="badge"><span class="dot"></span> 76k+ users trust FConvert</div>
        <div class="small-muted">Fast, clean, and mobile-optimized conversion pages for everyday use.</div>
      </div>

      <div class="converter-hero">
        <div class="badge">FConvert • <?php echo htmlspecialchars($tool['from']); ?> to <?php echo htmlspecialchars($tool['to']); ?></div>
        <h1 class="h1" style="margin-top:16px;"><?php echo htmlspecialchars($tool['title']); ?></h1>
        <p class="lead"><?php echo htmlspecialchars($tool['desc']); ?> Designed with a smooth mobile experience, a modern visual system, and a clear conversion flow.</p>
      </div>

      <div class="upload-shell">
        <div class="upload-card">
          <div class="upload-zone">
            <div>
              <div class="icon-pill" style="margin:0 auto 10px;"><?php echo htmlspecialchars($tool['icon']); ?></div>
              <h3>Upload your file</h3>
              <p>Drop a file here or select one from your device. The interface is built to feel comfortable on small screens and crisp on desktop.</p>
              <div class="file-input">
                <input type="file" data-file-name>
              </div>
              <div class="helper" data-file-label>No file selected yet</div>
            </div>
          </div>

          <div class="form-row">
            <select>
              <option>Choose quality</option>
              <option>High quality</option>
              <option>Balanced</option>
              <option>Smallest file size</option>
            </select>
            <select>
              <option>Output format</option>
              <option><?php echo htmlspecialchars($tool['to']); ?></option>
            </select>
          </div>

          <div class="hero-actions" style="margin-top:18px;">
            <button class="btn primary" type="button">Start conversion</button>
            <button class="btn secondary" type="button">Reset</button>
          </div>

          <div class="helper">This page is styled as a premium conversion experience. You can later connect the button to a processing backend or API for real file handling.</div>
        </div>

        <div class="panel">
          <h3>Why this conversion page exists</h3>
          <p>Many people just need a clean way to move between formats without hunting around through confusing tools. Designers need image exports. Students need documents converted for assignment uploads. Office users need PDFs, Word files, and spreadsheets to speak to one another. Video users need legacy compatibility. That is exactly why FConvert keeps each converter page focused, readable, and fast on mobile.</p>
          <div class="steps">
            <div class="step"><div class="step-num">1</div><div><strong>Choose your file</strong><div class="small-muted">Start with a clear upload area that is easy to tap on phones.</div></div></div>
            <div class="step"><div class="step-num">2</div><div><strong>Pick the desired output</strong><div class="small-muted">Every conversion route is shown plainly so the flow feels simple.</div></div></div>
            <div class="step"><div class="step-num">3</div><div><strong>Download the result</strong><div class="small-muted">A better file workflow means less friction and more speed.</div></div></div>
          </div>
        </div>
      </div>

      <div class="section">
        <div class="content-grid">
          <div class="panel">
            <h3>When people use this converter</h3>
            <ul>
              <li>When a file needs to be editable in a different app.</li>
              <li>When upload restrictions require a specific file type.</li>
              <li>When a larger file should be made lighter for sharing.</li>
              <li>When a document needs a more universal format for printing or archiving.</li>
            </ul>
          </div>
          <div class="panel">
            <h3>What makes FConvert feel modern</h3>
            <ul>
              <li>Mobile-first layout and touch-friendly spacing.</li>
              <li>Soft shadows, glass-style cards, and clean typography.</li>
              <li>Focused sections that are easier to scan and use.</li>
              <li>A consistent design language across all conversion pages.</li>
            </ul>
          </div>
        </div>
      </div>

      <div class="section">
        <div class="panel">
          <h3>Frequently asked questions</h3>
          <div class="faq" style="margin-top:14px;">
            <div class="faq-item">
              <h4>Why are these converters useful?</h4>
              <div>They help users move files into the format that works best for editing, sharing, storage, compatibility, or publication.</div>
            </div>
            <div class="faq-item">
              <h4>Can this page be linked to a backend later?</h4>
              <div>Yes. The interface is structured so a processing engine or external service can be connected cleanly later on.</div>
            </div>
          </div>
        </div>
      </div>

      <div class="footer" style="border-top:none;">
        <div class="container" style="padding:0;">
          <div class="small-muted">Download, convert, and keep moving. Built for a polished mobile experience.</div>
        </div>
      </div>
    </div>
  </section>

  <script src="//static.surfe.pro/js/net.js"></script>
  <ins class="surfe-be" data-sid="421283"></ins>
  <ins class="surfe-be" data-sid="421284"></ins>
  <script>
    (adsurfebe = window.adsurfebe || []).push({});
    (adsurfebe = window.adsurfebe || []).push({});
  </script>
<?php
    rhod_render_footer();
}
