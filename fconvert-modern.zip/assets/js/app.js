document.addEventListener('DOMContentLoaded', () => {
  const menuBtn = document.querySelector('[data-menu-btn]');
  const drawer = document.querySelector('[data-mobile-drawer]');
  if (menuBtn && drawer) {
    menuBtn.addEventListener('click', () => drawer.classList.toggle('open'));
  }

  const modal = document.querySelector('[data-welcome-modal]');
  if (modal) {
    const closeButtons = modal.querySelectorAll('[data-close-modal]');
    closeButtons.forEach(btn => btn.addEventListener('click', () => modal.remove()));
    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.remove();
    });
  }

  const fileInput = document.querySelector('[data-file-name]');
  const fileLabel = document.querySelector('[data-file-label]');
  if (fileInput && fileLabel) {
    fileInput.addEventListener('change', () => {
      const f = fileInput.files && fileInput.files[0];
      fileLabel.textContent = f ? f.name : 'No file selected yet';
    });
  }

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!reduceMotion) {
    const cards = document.querySelectorAll('.tool-card, .panel, .upload-card, .stat');
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.transform = 'translateY(0)';
          entry.target.style.opacity = '1';
        }
      });
    }, {threshold: 0.12});
    cards.forEach(card => {
      card.style.transform = 'translateY(14px)';
      card.style.opacity = '.001';
      card.style.transition = 'transform .6s ease, opacity .6s ease';
      observer.observe(card);
    });
  }
});
