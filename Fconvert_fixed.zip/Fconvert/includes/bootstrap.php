<?php
declare(strict_types=1);

session_start();

$siteBasePath = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
if ($siteBasePath === '.' || $siteBasePath === '/') {
    $siteBasePath = '';
}

function fconvert_url(string $path = ''): string {
    global $siteBasePath;
    $path = ltrim($path, '/');
    return $siteBasePath === '' ? '/' . $path : $siteBasePath . '/' . $path;
}

function fconvert_cookie_path(): string {
    global $siteBasePath;
    return $siteBasePath === '' ? '/' : $siteBasePath . '/';
}

$storageDir = __DIR__ . '/../storage';
$leadFile = $storageDir . '/emails.txt';
if (!is_dir($storageDir)) {
    mkdir($storageDir, 0775, true);
}
if (!file_exists($leadFile)) {
    file_put_contents($leadFile, "");
}

function fconvert_sanitize_email(string $email): string {
    $email = trim($email);
    return filter_var($email, FILTER_VALIDATE_EMAIL) ? $email : '';
}

function fconvert_has_seen_popup(): bool {
    return !empty($_SESSION['msg']) || !empty($_COOKIE['msg']);
}

function fconvert_set_popup_seen(): void {
    $_SESSION['msg'] = '1';
    setcookie('msg', '1', time() + 60 * 60 * 24 * 180, fconvert_cookie_path(), '', isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', true);
}

$flash_message = '';
$flash_type = 'info';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['popup_action'])) {
    $action = (string)$_POST['popup_action'];

    if ($action === 'subscribe') {
        $email = fconvert_sanitize_email((string)($_POST['email'] ?? ''));
        if ($email !== '') {
            $line = date('Y-m-d H:i:s') . " | " . $email . PHP_EOL;
            file_put_contents($leadFile, $line, FILE_APPEND | LOCK_EX);
            $flash_message = 'Thank you. Your email has been saved for updates.';
            $flash_type = 'success';
        } else {
            $flash_message = 'Please enter a valid email address.';
            $flash_type = 'error';
        }
        fconvert_set_popup_seen();
    }

    if ($action === 'cancel') {
        fconvert_set_popup_seen();
        $flash_message = 'No problem. You can continue exploring Fconvert.';
        $flash_type = 'info';
    }

    if (isset($_POST['redirect_to'])) {
        $redirect = (string)$_POST['redirect_to'];
        header('Location: ' . $redirect);
        exit;
    }
}

$show_popup = !fconvert_has_seen_popup();
