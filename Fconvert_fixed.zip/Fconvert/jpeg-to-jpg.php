<?php
require_once __DIR__ . '/includes/bootstrap.php';
$tools = require __DIR__ . '/includes/data.php';
$tool = $tools['jpeg-to-jpg'];
$page_title = 'Fconvert | ' . $tool['title'];
$page_description = $tool['description'];
$active_page = $tool['slug'];
$hero_badge = '76k+ users trust Fconvert';
$hero_title = $tool['headline'];
$hero_subtitle = $tool['subtitle'];
include __DIR__ . '/includes/header.php';
?>
<section class="converter-hero">
  <div class="container">
    <div class="converter-banner">
      <div>
        <div class="badge-users">★ 76k+ users</div>
        <h1><?= htmlspecialchars($tool['title']) ?></h1>
        <p><?= htmlspecialchars($tool['description']) ?> This page is written to feel premium, clear, and trustworthy, with the right amount of detail for mobile and desktop users.</p>
      </div>
      <div class="converter-chip">
        <strong><?= htmlspecialchars($tool['from']) ?> → <?= htmlspecialchars($tool['to']) ?></strong>
        <span>Fast format switching</span>
      </div>
    </div>
  </div>
</section>

<section class="section">
  <div class="container content-grid">
    <article class="panel">
      <h2>Why this converter matters</h2>
      <p>People use different file formats for different reasons. Some files need to be editable, some need to be shareable, and some need to be lighter for the web. Fconvert gives you a clean home for those everyday tasks.</p>
      <p>Whether you are working from a phone, a laptop, or a tablet, this page is designed to explain the value of the conversion in a simple, modern way.</p>
      <ul class="list">
        <?php foreach ($tool['benefits'] as $benefit): ?>
        <li><?= htmlspecialchars($benefit) ?></li>
        <?php endforeach; ?>
      </ul>
    </article>

    <aside class="panel">
      <h3>Common use cases</h3>
      <div class="faq">
        <div class="faq-item">
          <h4>School and office documents</h4>
          <p>Share files in a format that is easy to open and print.</p>
        </div>
        <div class="faq-item">
          <h4>Image and media workflows</h4>
          <p>Keep your media organized and compatible with different tools.</p>
        </div>
        <div class="faq-item">
          <h4>Web publishing</h4>
          <p>Use the format that best suits speed, quality, and consistency.</p>
        </div>
      </div>
    </aside>
  </div>
</section>

<section class="section">
  <div class="container upload-grid">
    <div class="upload-card">
      <h3>Upload your file</h3>
      <p>Use this area as the conversion entry point. You can connect the backend conversion engine here later.</p>
      <div class="field">
        <label for="file">Choose a file</label>
        <input type="file" id="file" accept="*/*">
      </div>
      <div class="field">
        <label for="target">Output format</label>
        <select id="target">
          <option><?= htmlspecialchars($tool['to']) ?></option>
          <option>Other supported format</option>
        </select>
      </div>
      <div class="form-actions">
        <button class="cta-btn" type="button">Start conversion</button>
        <button class="secondary-btn" type="button">Preview details</button>
      </div>
      <div class="note-box" style="margin-top:16px;">
        This layout is optimized for mobile devices, with large touch targets, balanced spacing, and a premium dark visual style.
      </div>
    </div>

    <div class="upload-card">
      <h3>What users get here</h3>
      <p>A polished explanation of the conversion flow, strong trust signals, and a clear path to future upgrades.</p>
      <ul class="list">
        <li>Easy-to-read page content for first-time visitors.</li>
        <li>Strong calls to action without clutter.</li>
        <li>Space for real file processing logic later.</li>
      </ul>
      <div class="note-box">
        Popular format conversions help users move faster between offices, devices, clients, and publishing tools. That is why every converter page includes enough content to feel complete and credible.
      </div>
    </div>
  </div>
</section>

<section class="section">
  <div class="container content-grid">
    <div class="panel">
      <h3>Frequently asked questions</h3>
      <div class="faq">
        <div class="faq-item">
          <h4>Why are file converters useful?</h4>
          <p>Because different apps and platforms prefer different formats. Conversion saves time and avoids compatibility problems.</p>
        </div>
        <div class="faq-item">
          <h4>Is this page mobile friendly?</h4>
          <p>Yes. The layout automatically stacks neatly on smaller screens and keeps important actions easy to tap.</p>
        </div>
        <div class="faq-item">
          <h4>Can more converter pages be added?</h4>
          <p>Yes. The structure is reusable, so you can add more tools without redesigning the site.</p>
        </div>
      </div>
    </div>
    <div class="panel">
      <h3>Need another converter?</h3>
      <p>Each page in Fconvert is styled to look like a real product landing page, not just a plain utility screen.</p>
      <div class="form-actions">
        <a class="cta-btn" href="<?= htmlspecialchars(fconvert_url('index.php')) ?>">Back to home</a>
        <a class="secondary-btn" href="https://wa.me/2347012265612" target="_blank" rel="noopener">Contact support</a>
      </div>
    </div>
  </div>
</section>

<?php include __DIR__ . '/includes/popup.php'; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
