<?php
$page_title = 'DOC to PDF';
$page_tagline = 'Turn older Word documents into PDFs that travel well across devices and operating systems.';
$page_intro = 'Legacy DOC files are still common in offices, schools, and archives. Converting them to PDF helps preserve layout and simplifies sharing.';
$page_bullets = ['Legacy support', 'Stable layout', 'Easy distribution'];
$source_label = 'DOC file';
$target_label = 'PDF output';
require __DIR__ . '/converter-template.php';
?>