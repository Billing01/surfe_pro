<?php require __DIR__ . '/config.php'; ?>
<?php if (!isset($page_title)) { $page_title = 'Converter'; } ?>
<?php if (!isset($page_tagline)) { $page_tagline = 'A clean, modern conversion page built for RHOD.'; } ?>
<?php if (!isset($page_intro)) { $page_intro = 'Use this page to guide users through a simple file conversion journey.'; } ?>
<?php if (!isset($page_bullets)) { $page_bullets = ['Fast workflow', 'Clear format guidance', 'Professional presentation']; } ?>
<?php if (!isset($source_label)) { $source_label = 'Source'; } ?>
<?php if (!isset($target_label)) { $target_label = 'Target'; } ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo htmlspecialchars($page_title); ?> — <?php echo $site_name; ?></title>
  <meta name="description" content="<?php echo htmlspecialchars($page_tagline); ?>">
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
  <header class="site-header">
    <div class="container header-wrap">
      <div class="brand">
        <div class="brand-mark">R</div>
        <div><?php echo $site_name; ?></div>
      </div>
      <nav class="nav">
        <a href="index.php">Home</a>
        <a href="index.php#converters">All converters</a>
        <a href="index.php#contact">Contact</a>
      </nav>
    </div>
  </header>

  <main>
    <section class="hero">
      <div class="container converter-grid">
        <article class="hero-card">
          <span class="kicker"><?php echo $top_users; ?> and counting</span>
          <h1><?php echo htmlspecialchars($page_title); ?></h1>
          <p class="lead"><?php echo htmlspecialchars($page_tagline); ?></p>
          <p class="lead"><?php echo htmlspecialchars($page_intro); ?></p>

          <div class="pill-row">
            <?php foreach ($page_bullets as $bullet): ?>
              <span class="pill"><?php echo htmlspecialchars($bullet); ?></span>
            <?php endforeach; ?>
          </div>

          <div class="ads">
            <div class="ad-box">
              <script src="//static.surfe.pro/js/net.js"></script>
              <ins class="surfe-be" data-sid="421283"></ins>
            </div>
            <div class="ad-box">
              <ins class="surfe-be" data-sid="421284"></ins>
            </div>
          </div>
          <script>
          (adsurfebe = window.adsurfebe || []).push({});
          (adsurfebe = window.adsurfebe || []).push({});
          </script>

          <form class="form" method="post" action="#">
            <label>
              <span class="small"><?php echo $source_label; ?> file</span>
              <input class="input" type="file" name="source_file" />
            </label>
            <label>
              <span class="small"><?php echo $target_label; ?> format</span>
              <input class="input" type="text" value="<?php echo htmlspecialchars($page_title); ?>" readonly />
            </label>
            <button class="btn btn-primary" type="button">Prepare conversion</button>
          </form>
          <p class="small">This page is ready for your conversion backend, upload processing, and download logic.</p>
        </article>

        <aside class="converter-card">
          <h2>Why this conversion is useful</h2>
          <p>
            <?php echo htmlspecialchars($page_intro); ?> The goal is to make the transition between formats simple for users who care about speed,
            compatibility, and quality. Some files are easier to edit in one format, while others are better suited for sharing or archiving
            in another. A polished conversion page helps explain that value without confusion.
          </p>
          <ul class="content-list">
            <li><strong>Better compatibility:</strong> Give users the format most likely to open correctly on their device or app.</li>
            <li><strong>Cleaner presentation:</strong> Use PDF when a file should look consistent everywhere.</li>
            <li><strong>Editable output:</strong> Use DOCX when users need to revise text and layout later.</li>
            <li><strong>Smaller or friendlier files:</strong> Switch image or media formats for easier storage and sharing.</li>
          </ul>
        </aside>
      </div>
    </section>

    <section class="section">
      <div class="container">
        <div class="panel">
          <h2>More about this converter</h2>
          <p>
            RHOD is designed to feel reassuring and professional. A visitor landing on this page should instantly understand what the
            converter does, why they might need it, and what to do next. That is why the page includes a clear heading, short explanatory
            sections, a user count badge, and a direct path to conversion.
          </p>
          <div class="grid-3">
            <div class="feature">
              <h3>Reliable format switching</h3>
              <p>Help users move from one file type to another without breaking their workflow.</p>
            </div>
            <div class="feature">
              <h3>Clean user journey</h3>
              <p>Keep the steps clear so visitors can upload, convert, and download without distraction.</p>
            </div>
            <div class="feature">
              <h3>Future-ready layout</h3>
              <p>The structure is easy to expand later with actual file handling and conversion logic.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="section">
      <div class="container">
        <div class="panel">
          <h2>Frequently asked questions</h2>
          <div class="faq-grid">
            <div class="faq-item">
              <h3>Why do users convert files?</h3>
              <p>To make them editable, shareable, smaller, more compatible, or better suited for a specific platform.</p>
            </div>
            <div class="faq-item">
              <h3>Can this page support more formats?</h3>
              <p>Yes. The same design can be duplicated for many other conversion combinations as your platform grows.</p>
            </div>
            <div class="faq-item">
              <h3>Is this page mobile-friendly?</h3>
              <p>Yes. The layout responds neatly on phones, tablets, and desktop screens.</p>
            </div>
            <div class="faq-item">
              <h3>Can the backend be added later?</h3>
              <p>Yes. You can connect file validation, upload handling, and conversion tools whenever you are ready.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="section">
      <div class="container">
        <div class="cta">
          <div>
            <h2 style="margin-bottom:8px;">Need a file converted with RHOD?</h2>
            <p class="lead" style="margin:0;">Use the contact line below to connect with the platform team.</p>
          </div>
          <a class="btn btn-primary" href="<?php echo $whatsapp_link; ?>">WhatsApp <?php echo $whatsapp; ?></a>
        </div>
      </div>
    </section>
  </main>

  <footer class="site-footer" id="contact">
    <div class="container footer-wrap">
      <div>
        <strong><?php echo $site_name; ?></strong><br>
        Converter page built for a polished user experience.
      </div>
      <div>
        Contact on WhatsApp:
        <a class="footer-link" href="<?php echo $whatsapp_link; ?>"><?php echo $whatsapp; ?></a>
      </div>
    </div>
  </footer>
</body>
</html>