<?php
$site_name = 'RHOD';
$whatsapp = '+2347012265612';
$whatsapp_link = 'https://wa.me/2347012265612';
$top_users = '76k+ users';

$converters = [
    'pdf-to-docx.php' => ['PDF to DOCX', 'Convert PDF documents into editable DOCX files.'],
    'docx-to-pdf.php' => ['DOCX to PDF', 'Turn Word files into polished PDFs.'],
    'jpeg-to-jpg.php' => ['JPEG to JPG', 'Rename or convert JPEG images to JPG format.'],
    'jpg-to-jpeg.php' => ['JPG to JPEG', 'Switch JPG images to the JPEG extension.'],
    'doc-to-pdf.php' => ['DOC to PDF', 'Convert legacy Word documents into PDF.'],
    'mp4-to-avi.php' => ['MP4 to AVI', 'Reformat videos for broader compatibility.'],
    'png-to-jpg.php' => ['PNG to JPG', 'Reduce file size with JPG output.'],
    'webp-to-png.php' => ['WebP to PNG', 'Get transparent-friendly PNG images from WebP.'],
    'mp3-to-wav.php' => ['MP3 to WAV', 'Convert compressed audio into WAV format.'],
    'txt-to-pdf.php' => ['TXT to PDF', 'Transform plain text into shareable PDF documents.'],
];
?>