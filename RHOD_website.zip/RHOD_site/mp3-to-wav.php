<?php
$page_title = 'MP3 to WAV';
$page_tagline = 'Convert compressed audio into WAV for editing, archiving, or production workflows.';
$page_intro = 'WAV is often preferred in audio tools because it preserves a more original-sounding workflow compared with compressed formats like MP3.';
$page_bullets = ['Audio editing', 'Production-ready', 'High-quality output'];
$source_label = 'MP3 file';
$target_label = 'WAV output';
require __DIR__ . '/converter-template.php';
?>