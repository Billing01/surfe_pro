<?php require __DIR__ . '/config.php'; ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo $site_name; ?> — File Converter Platform</title>
  <meta name="description" content="RHOD helps users convert documents, images, videos and audio into the formats they need, quickly and professionally.">
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
  <header class="site-header">
    <div class="container header-wrap">
      <div class="brand">
        <div class="brand-mark">R</div>
        <div><?php echo $site_name; ?></div>
      </div>
      <nav class="nav">
        <a href="#converters">Converters</a>
        <a href="#why">Why RHOD</a>
        <a href="#how">How it works</a>
        <a href="#contact">Contact</a>
      </nav>
    </div>
  </header>

  <main>
    <section class="hero">
      <div class="container hero-grid">
        <article class="hero-card">
          <span class="kicker">Simple. Fast. Professional.</span>
          <h1>Convert files with RHOD.</h1>
          <p class="lead">
            RHOD is a modern file conversion platform built for people who work with documents, images, audio, and video every day.
            Whether you need to turn a PDF into an editable Word file, shrink an image for sharing, or reformat a video for compatibility,
            RHOD gives you a clean path from one format to another.
          </p>
          <p class="lead">
            File conversion matters because the right format saves time, protects quality, and helps your work open correctly on different
            devices, apps, and operating systems. A designer may need PNG instead of WebP. A student may need DOCX instead of PDF.
            A business owner may need PDF for clean sharing, while a video editor may need AVI for older workflows.
            RHOD brings these everyday needs together in one organized place.
          </p>
          <div class="hero-actions">
            <a class="btn btn-primary" href="#converters">Browse converters</a>
            <a class="btn btn-secondary" href="#why">See why it matters</a>
          </div>
        </article>

        <aside class="hero-side">
          <div class="stat">
            <strong>76k+</strong>
            <span>users trust RHOD for simple file format switching.</span>
          </div>
          <div class="stat">
            <strong>10+</strong>
            <span>popular converters ready to explore from the homepage.</span>
          </div>
          <div class="stat">
            <strong>24/7</strong>
            <span>access to a polished conversion experience on any device.</span>
          </div>
        </aside>
      </div>
    </section>

    <section class="section" id="why">
      <div class="container">
        <div class="panel">
          <h2>Why these converters are needed</h2>
          <p>
            Different file formats exist for different reasons. Some are made for editing, some for sharing, some for compatibility, and
            some for preserving quality. A file that looks perfect in one app may not open properly in another. That is why a file conversion
            platform becomes useful: it helps people move content into the format that best fits the task in front of them.
          </p>
          <div class="grid-3">
            <div class="feature">
              <h3>Documents that open everywhere</h3>
              <p>
                PDF to DOCX and DOCX to PDF conversions are essential for students, professionals, and teams who need editable documents
                and finished, share-ready copies.
              </p>
            </div>
            <div class="feature">
              <h3>Images for the right workflow</h3>
              <p>
                JPEG, JPG, PNG, and WebP all serve different purposes. RHOD helps you choose the format that keeps images practical,
                lightweight, and easy to use.
              </p>
            </div>
            <div class="feature">
              <h3>Media for compatibility</h3>
              <p>
                Video and audio formats can affect playback, editing, upload size, and device support. Converting between MP4, AVI,
                MP3, WAV, and more keeps projects moving smoothly.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="section" id="converters">
      <div class="container">
        <div class="panel">
          <h2>Popular converter pages</h2>
          <p>Open the converter that matches your task. Each page is built to be clear, welcoming, and easy to expand later.</p>
          <div class="grid-3">
            <?php foreach ($converters as $file => $info): ?>
              <a class="feature" href="<?php echo htmlspecialchars($file); ?>">
                <h3><?php echo htmlspecialchars($info[0]); ?></h3>
                <p><?php echo htmlspecialchars($info[1]); ?></p>
              </a>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </section>

    <section class="section" id="how">
      <div class="container">
        <div class="panel">
          <h2>How RHOD is designed to help</h2>
          <div class="grid-3">
            <div class="feature">
              <h3>1. Pick a format</h3>
              <p>Select the converter that matches the source file and destination format you need.</p>
            </div>
            <div class="feature">
              <h3>2. Upload your file</h3>
              <p>Add the file you want to change, then continue through the conversion flow on the specific page.</p>
            </div>
            <div class="feature">
              <h3>3. Get the output</h3>
              <p>Download a ready-to-use file in the target format and continue your work without friction.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="section">
      <div class="container">
        <div class="cta">
          <div>
            <h2 style="margin-bottom:8px;">Built for clarity and trust</h2>
            <p class="lead" style="margin:0;">
              RHOD keeps the experience simple so visitors can quickly understand what each converter does and why it matters.
            </p>
          </div>
          <a class="btn btn-primary" href="#contact">Contact RHOD</a>
        </div>
      </div>
    </section>
  </main>

  <footer class="site-footer" id="contact">
    <div class="container footer-wrap">
      <div>
        <strong><?php echo $site_name; ?></strong><br>
        File conversion platform for documents, images, audio, and video.
      </div>
      <div>
        Contact on WhatsApp:
        <a class="footer-link" href="<?php echo $whatsapp_link; ?>"><?php echo $whatsapp; ?></a>
      </div>
    </div>
  </footer>
</body>
</html>