<?php
$page_title = 'PDF to DOCX';
$page_tagline = 'Turn PDFs into editable Word documents while keeping the experience clean and easy to understand.';
$page_intro = 'This converter is ideal for people who need to reuse content from a PDF in a document editor, update wording, or continue working on a file they received from someone else.';
$page_bullets = ['Editable output', 'Business-friendly', 'Great for study notes'];
$source_label = 'PDF file';
$target_label = 'DOCX output';
require __DIR__ . '/converter-template.php';
?>