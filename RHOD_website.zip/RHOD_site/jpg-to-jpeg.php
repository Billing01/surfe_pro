<?php
$page_title = 'JPG to JPEG';
$page_tagline = 'Rename or convert JPG images into the JPEG extension for consistent file management.';
$page_intro = 'This converter helps users align image names with platform requirements, content organization systems, or preferred file handling practices.';
$page_bullets = ['Simple conversion', 'Clean file naming', 'Easy organization'];
$source_label = 'JPG file';
$target_label = 'JPEG output';
require __DIR__ . '/converter-template.php';
?>