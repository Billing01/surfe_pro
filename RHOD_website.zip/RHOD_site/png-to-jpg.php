<?php
$page_title = 'PNG to JPG';
$page_tagline = 'Convert PNG images to JPG when smaller files and broad compatibility are more important.';
$page_intro = 'PNG is excellent for sharp graphics and transparency, while JPG is helpful when users want smaller image sizes for sharing or publishing.';
$page_bullets = ['Smaller images', 'Web-friendly', 'Fast sharing'];
$source_label = 'PNG file';
$target_label = 'JPG output';
require __DIR__ . '/converter-template.php';
?>