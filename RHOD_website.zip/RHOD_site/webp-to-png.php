<?php
$page_title = 'WebP to PNG';
$page_tagline = 'Move WebP images into PNG for workflows that need wider support or easier editing.';
$page_intro = 'WebP is efficient for the web, but PNG remains a dependable choice when users need a familiar image format for design or content work.';
$page_bullets = ['Wider support', 'Editing-friendly', 'Design workflows'];
$source_label = 'WebP file';
$target_label = 'PNG output';
require __DIR__ . '/converter-template.php';
?>