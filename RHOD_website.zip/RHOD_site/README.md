# RHOD

A professional PHP file-converter website starter.

## Files
- `index.php` — homepage
- `converter-template.php` — reusable layout for converter pages
- `config.php` — shared settings and converter list
- `assets/style.css` — site styling
- converter pages such as `pdf-to-docx.php`, `docx-to-pdf.php`, and more

## Notes
This is a front-end website scaffold. You can connect real upload and conversion logic later.