<?php
$page_title = 'TXT to PDF';
$page_tagline = 'Transform plain text into a polished PDF that is easier to read and share.';
$page_intro = 'Plain text files are simple and lightweight, but PDF is better when you want cleaner presentation, safer sharing, and consistent formatting.';
$page_bullets = ['Clean presentation', 'Easy sharing', 'Consistent layout'];
$source_label = 'TXT file';
$target_label = 'PDF output';
require __DIR__ . '/converter-template.php';
?>