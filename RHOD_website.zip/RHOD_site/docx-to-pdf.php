<?php
$page_title = 'DOCX to PDF';
$page_tagline = 'Convert Word documents into polished PDFs that are easy to share, print, and preserve.';
$page_intro = 'This page serves users who want a final, consistent version of a document that looks the same on every device and is easier to distribute professionally.';
$page_bullets = ['Print-ready', 'Universal sharing', 'Professional finish'];
$source_label = 'DOCX file';
$target_label = 'PDF output';
require __DIR__ . '/converter-template.php';
?>