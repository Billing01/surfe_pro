<?php
$page_title = 'MP4 to AVI';
$page_tagline = 'Reformat video files for workflows and devices that still rely on AVI compatibility.';
$page_intro = 'This converter is useful for users working with older editing tools, media libraries, or playback environments where AVI remains a preferred format.';
$page_bullets = ['Video compatibility', 'Workflow flexibility', 'Classic format support'];
$source_label = 'MP4 file';
$target_label = 'AVI output';
require __DIR__ . '/converter-template.php';
?>