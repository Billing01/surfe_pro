<?php
$page_title = 'JPEG to JPG';
$page_tagline = 'A simple image format switch for users who want JPG output from JPEG files.';
$page_intro = 'JPEG and JPG are widely interchangeable, so this page is useful for organizing image libraries, meeting upload rules, or matching required file naming conventions.';
$page_bullets = ['Image naming', 'Upload compatibility', 'Lightweight workflow'];
$source_label = 'JPEG file';
$target_label = 'JPG output';
require __DIR__ . '/converter-template.php';
?>